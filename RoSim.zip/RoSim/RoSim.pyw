# Doble clic para abrir RoSim sin consola (requiere haber ejecutado INSTALAR.bat)
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rosim.app import main

if __name__ == "__main__":
    main()
