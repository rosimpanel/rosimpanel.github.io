param([switch]$SoloAcceso)
# RoSim - instalador automatico
# Instala Python (si falta), las librerias, el driver ViGEmBus y crea el acceso directo.
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Host.UI.RawUI.WindowTitle = "RoSim - Instalador"

function Paso($n, $t) { Write-Host ""; Write-Host "  [$n/4] $t" -ForegroundColor Cyan }
function Ok($t)  { Write-Host "        OK  $t" -ForegroundColor Green }
function Mal($t) { Write-Host "        !!  $t" -ForegroundColor Yellow }

Write-Host ""
Write-Host "  ==========  RoSim - instalador automatico  ==========" -ForegroundColor DarkYellow

if ($Here -like "*\Temp\*" -or $Here -like "*.zip*") {
    Write-Host ""
    Write-Host "  Estas abriendo RoSim desde dentro del .zip." -ForegroundColor Yellow
    Write-Host "  Haz clic derecho en RoSim.zip > Extraer todo, y abre INSTALAR.bat desde la carpeta extraida." -ForegroundColor Yellow
    Read-Host "  Pulsa Intro para salir"; exit 1
}

# ------------------------------------------------------------------ Python
function Find-Python {
    foreach ($c in @("py", "python")) {
        $cmd = Get-Command $c -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source -notlike "*WindowsApps*") {
            $v = & $c -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
            if ($v -and [version]$v -ge [version]"3.10") {
                return (& $c -c "import sys; print(sys.executable)" 2>$null)
            }
        }
    }
    foreach ($d in @("$env:LOCALAPPDATA\Programs\Python", "$env:ProgramFiles")) {
        $p = Get-ChildItem "$d\Python3*\python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1
        if ($p) { return $p.FullName }
    }
    return $null
}

if ($SoloAcceso) {
    $py = Find-Python
    if (-not $py) { Mal "Primero ejecuta INSTALAR.bat"; Read-Host "Pulsa Intro para salir"; exit 1 }
} else {
Paso 1 "Python"
$py = Find-Python
if ($py) {
    Ok "Python encontrado: $py"
} else {
    Write-Host "        Instalando Python 3.12 (puede tardar un par de minutos)..."
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Null
        $py = Find-Python
    }
    if (-not $py) {
        $exe = Join-Path $env:TEMP "python-3.12.10-amd64.exe"
        try {
            Invoke-WebRequest "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe" -OutFile $exe
            Start-Process $exe -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=1" -Wait
        } catch { Mal "No se pudo descargar Python: $_" }
        $py = Find-Python
    }
    if ($py) { Ok "Python instalado: $py" }
    else {
        Mal "No se pudo instalar Python. Instalalo desde python.org y vuelve a abrir INSTALAR.bat."
        Read-Host "Pulsa Intro para salir"; exit 1
    }
}

# ------------------------------------------------------------------ librerias
Paso 2 "Librerias (pygame-ce, vgamepad)"
& $py -m pip install --upgrade pip --quiet --disable-pip-version-check 2>$null
& $py -m pip install -r (Join-Path $Here "requirements.txt") --quiet --disable-pip-version-check
if ($LASTEXITCODE -eq 0) { Ok "Librerias instaladas" } else { Mal "pip dio un error (mira el mensaje de arriba)" }

# ------------------------------------------------------------------ ViGEmBus
Paso 3 "Driver del mando virtual (ViGEmBus)"
function Has-ViGEm { return [bool](Get-Service -Name "ViGEmBus" -ErrorAction SilentlyContinue) }
if (Has-ViGEm) {
    Ok "ViGEmBus ya estaba instalado"
} else {
    Write-Host "        Instalando ViGEmBus. Windows te pedira permiso de administrador: pulsa Si."
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        winget install -e --id ViGEm.ViGEmBus --silent --accept-package-agreements --accept-source-agreements | Out-Null
    }
    if (-not (Has-ViGEm)) {
        # el instalador viene dentro de vgamepad
        $vg = & $py -c "import os, importlib.util as u; s=u.find_spec('vgamepad'); print(os.path.dirname(s.origin) if s else '')" 2>$null
        $msi = $null
        if ($vg) { $msi = Get-ChildItem $vg -Recurse -Filter "ViGEmBus*x64*.msi" -ErrorAction SilentlyContinue | Select-Object -First 1 }
        if ($msi) {
            Start-Process msiexec.exe -ArgumentList "/i `"$($msi.FullName)`" /qb /norestart" -Verb RunAs -Wait
        }
    }
    if (Has-ViGEm) { Ok "ViGEmBus instalado" }
    else { Mal "No se pudo instalar ViGEmBus. RoSim funcionara con teclado y raton; para el volante instalalo desde github.com/nefarius/ViGEmBus/releases" }
}

}

# ------------------------------------------------------------------ acceso directo
Paso 4 "Acceso directo en el escritorio"
$pyw = Join-Path (Split-Path $py) "pythonw.exe"
if (-not (Test-Path $pyw)) { $pyw = $py }
$script = Join-Path $Here "RoSim.pyw"
$icon = Join-Path $Here "assets\rosim.ico"
$made = $false
foreach ($dir in @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("Programs"))) {
    if (-not $dir) { continue }
    try {
        $w = New-Object -ComObject WScript.Shell
        $s = $w.CreateShortcut((Join-Path $dir "RoSim.lnk"))
        $s.TargetPath = $pyw
        $s.Arguments = '"' + $script + '"'
        $s.WorkingDirectory = $Here
        $s.IconLocation = "$icon,0"
        $s.Description = "RoSim - volantes y joysticks para Roblox"
        $s.Save()
        if (Test-Path (Join-Path $dir "RoSim.lnk")) { $made = $true; Ok "Creado en $dir" }
    } catch { Mal "No se pudo crear en ${dir}: $_" }
}
if (-not $made) {
    $res = & $py -c "import sys; sys.path.insert(0, r'$Here'); from rosim.system import create_shortcuts; print(create_shortcuts())"
    Write-Host "        $res"
}

Write-Host ""
Write-Host "  Todo listo. Abre RoSim desde el icono del escritorio." -ForegroundColor Green
Write-Host ""
$r = Read-Host "  Quieres abrir RoSim ahora? (S/n)"
if ($r -notmatch "^[nN]") {
    $pyw = Join-Path (Split-Path $py) "pythonw.exe"
    if (-not (Test-Path $pyw)) { $pyw = $py }
    Start-Process $pyw -ArgumentList "`"$(Join-Path $Here 'RoSim.pyw')`"" -WorkingDirectory $Here
}
