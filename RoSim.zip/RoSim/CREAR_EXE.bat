@echo off
chcp 65001 >nul
where py >/dev/null 2>/dev/null && (set PY=py) || (set PY=python)
%PY% -m pip install pyinstaller
cd /d "%~dp0"
%PY% -m PyInstaller --noconfirm --onefile --windowed --name RoSim --icon assets\rosim.ico --add-data "assets;assets" --collect-all vgamepad --collect-all pygame RoSim.pyw
echo.
echo  El .exe esta en la carpeta dist\
pause
