"""
RoSim - utilidades del sistema: accesos directos, actualizaciones y reinicio.
No importa pygame (lo usa también INSTALAR.bat).
"""
import os
import re
import sys
import json
import shutil
import zipfile
import tempfile
import subprocess

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VERSION_FILE = os.path.join(APP_DIR, "VERSION")
FROZEN = getattr(sys, "frozen", False)


def current_version():
    try:
        with open(VERSION_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return "1.0"


def vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "0")[:4]) or (0,)


def newer(a, b):
    """¿a es más nueva que b?"""
    return vtuple(a) > vtuple(b)


# ------------------------------------------------------------------ accesos
def _pythonw():
    exe = sys.executable
    d = os.path.dirname(exe)
    for name in ("pythonw.exe", "pyw.exe"):
        p = os.path.join(d, name)
        if os.path.exists(p):
            return p
    return exe


def _known_folder(guid_hex_le, fallback):
    """Ruta real de una carpeta de Windows (funciona aunque el escritorio esté en OneDrive)."""
    try:
        import ctypes
        guid = (ctypes.c_byte * 16).from_buffer_copy(bytes.fromhex(guid_hex_le))
        path = ctypes.c_wchar_p()
        if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(path)) == 0:
            p = path.value
            ctypes.windll.ole32.CoTaskMemFree(path)
            if p and os.path.isdir(p):
                return p
    except Exception:
        pass
    return fallback


def desktop_dir():
    # FOLDERID_Desktop {B4BFCC3A-DB2C-424C-B029-7FE99A87C641}
    return _known_folder("3accbfb42cdb4c42b0297fe99a87c641",
                         os.path.join(os.path.expanduser("~"), "Desktop"))


def programs_dir():
    # FOLDERID_Programs {A77F5D77-2E2B-44C3-A6A2-ABA601054A51}
    return _known_folder("775d7fa72b2ec344a6a2aba601054a51",
                         os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs"))


def _make_lnk(lnk, target, args, workdir, icon):
    q = lambda v: v.replace("'", "''")
    cmd = ("$w = New-Object -ComObject WScript.Shell; "
           "$s = $w.CreateShortcut('%s'); $s.TargetPath = '%s'; $s.Arguments = '%s'; "
           "$s.WorkingDirectory = '%s'; $s.IconLocation = '%s,0'; "
           "$s.Description = 'RoSim - volantes y joysticks para Roblox'; $s.Save()"
           % (q(lnk), q(target), q(args), q(workdir), q(icon)))
    subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
                   capture_output=True, text=True, timeout=40,
                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return os.path.exists(lnk)


def _make_url(path, script, icon):
    """Plan B sin PowerShell: acceso directo .url que abre RoSim.pyw con su icono."""
    url = "file:///" + script.replace("\\", "/")
    with open(path, "w", encoding="utf-8") as f:
        f.write("[InternetShortcut]\nURL=%s\nIconFile=%s\nIconIndex=0\n" % (url, icon))
    return os.path.exists(path)


def create_shortcuts(desktop=True, start_menu=True):
    """Crea el acceso directo de RoSim en el escritorio (y en el menú Inicio). Devuelve un texto."""
    if sys.platform != "win32":
        return "Los accesos directos solo se crean en Windows."
    low = APP_DIR.lower()
    if "\\temp\\" in low or ".zip" in low:
        return "Primero descomprime RoSim en una carpeta (por ejemplo Documentos) y ábrelo desde allí."
    script = os.path.join(APP_DIR, "RoSim.pyw")
    if FROZEN:
        target, args = sys.executable, ""
    else:
        target, args = _pythonw(), '"%s"' % script
    icon = os.path.join(APP_DIR, "assets", "rosim.ico")
    dirs = []
    if desktop:
        dirs.append(desktop_dir())
    if start_menu:
        dirs.append(programs_dir())
    made, errors = [], []
    for d in dirs:
        lnk = os.path.join(d, "RoSim.lnk")
        try:
            ok = _make_lnk(lnk, target, args, APP_DIR, icon)
        except Exception as e:
            ok = False
            errors.append(str(e))
        if not ok and not FROZEN:
            try:
                ok = _make_url(os.path.join(d, "RoSim.url"), script, icon)
            except Exception as e:
                errors.append(str(e))
        if ok:
            made.append(d)
    if not made:
        return "No se pudo crear el acceso directo. " + (errors[0][:120] if errors else "")
    if desktop and made[0] == dirs[0]:
        return "Acceso directo creado en el escritorio (%s)" % dirs[0]
    return "Acceso directo creado en: " + ", ".join(made)


# ------------------------------------------------------------ actualizaciones
def zip_version(path):
    """Versión que trae un RoSim.zip, o None si no es un zip de RoSim."""
    try:
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            ver = [n for n in names if n.replace("\\", "/").split("/")[-1] == "VERSION"
                   and n.count("/") <= 1]
            if not any(n.endswith("rosim/app.py") for n in names):
                return None
            if ver:
                return z.read(ver[0]).decode("utf-8", "ignore").strip()
            return "1.0"
    except Exception:
        return None


def downloads_dir():
    if sys.platform == "win32":
        try:
            import ctypes
            from ctypes import wintypes
            # GUID {374DE290-123F-4565-9164-39C4925E467B} en bytes little-endian
            guid = (ctypes.c_byte * 16).from_buffer_copy(
                bytes.fromhex("90e24d373f126545916439c4925e467b"))
            path = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(path)) == 0:
                p = path.value
                ctypes.windll.ole32.CoTaskMemFree(path)
                return p
        except Exception:
            pass
    return os.path.join(os.path.expanduser("~"), "Downloads")


def find_update_zips():
    """Busca RoSim*.zip en Descargas y Escritorio. Devuelve [(versión, ruta)] de más nueva a más vieja."""
    found = []
    dirs = [downloads_dir(), os.path.join(os.path.expanduser("~"), "Desktop")]
    for d in dirs:
        try:
            for f in os.listdir(d):
                if f.lower().startswith("rosim") and f.lower().endswith(".zip"):
                    p = os.path.join(d, f)
                    v = zip_version(p)
                    if v:
                        found.append((v, p))
        except Exception:
            pass
    found.sort(key=lambda t: (vtuple(t[0]), os.path.getmtime(t[1])), reverse=True)
    return found


def install_zip(path):
    """Copia los archivos del zip encima de esta instalación. La config (en %APPDATA%) no se toca."""
    if FROZEN:
        raise RuntimeError("La versión .exe no se puede actualizar sola: descarga el nuevo .exe.")
    tmp = tempfile.mkdtemp(prefix="rosim_upd_")
    try:
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():   # protección contra rutas raras dentro del zip
                if n.startswith("/") or ".." in n.replace("\\", "/").split("/"):
                    raise RuntimeError("El zip contiene rutas no válidas.")
            z.extractall(tmp)
        root = tmp
        entries = os.listdir(tmp)
        if len(entries) == 1 and os.path.isdir(os.path.join(tmp, entries[0])):
            root = os.path.join(tmp, entries[0])
        if not os.path.exists(os.path.join(root, "rosim", "app.py")):
            raise RuntimeError("Ese zip no es de RoSim.")
        for base, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            rel = os.path.relpath(base, root)
            dst = os.path.join(APP_DIR, rel) if rel != "." else APP_DIR
            os.makedirs(dst, exist_ok=True)
            for f in files:
                shutil.copy2(os.path.join(base, f), os.path.join(dst, f))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def check_online(url, timeout=6):
    """Lee un version.json con {"version": "1.2", "zip": "https://...", "notas": "..."}."""
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "RoSim/" + current_version()})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def download(url, timeout=60):
    import urllib.request
    fd, path = tempfile.mkstemp(prefix="RoSim_", suffix=".zip")
    os.close(fd)
    req = urllib.request.Request(url, headers={"User-Agent": "RoSim/" + current_version()})
    with urllib.request.urlopen(req, timeout=timeout) as r, open(path, "wb") as f:
        shutil.copyfileobj(r, f)
    return path


def pick_zip():
    """Abre el selector de archivos de Windows para elegir un .zip."""
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        p = filedialog.askopenfilename(title="Elige el RoSim.zip nuevo", initialdir=downloads_dir(),
                                       filetypes=[("RoSim", "*.zip")])
        root.destroy()
        return p or None
    except Exception:
        return None


def beep(freq=880, ms=150, delay=0.0):
    """Pitido sin bloquear (se oye aunque Roblox esté delante)."""
    if sys.platform != "win32":
        return
    import threading, time as _t

    def run():
        try:
            if delay:
                _t.sleep(delay)
            import winsound
            winsound.Beep(int(freq), int(ms))
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()


def restart():
    script = os.path.join(APP_DIR, "RoSim.pyw")
    exe = sys.executable if FROZEN else _pythonw()
    args = [exe] if FROZEN else [exe, script]
    subprocess.Popen(args, cwd=APP_DIR, close_fds=True)
