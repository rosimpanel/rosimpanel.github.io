"""
RoSim - Control Hub para Roblox
Volantes (Logitech G29/G920/G923/G27/G PRO y cualquier otro), sidestick Airbus
Thrustmaster TCA, palanca de gases TCA Quadrant y cualquier joystick.
"""
import os
import sys
import json
import math
import time
import copy
import threading

os.environ.setdefault("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1")  # leer el volante con Roblox delante
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

from . import winio  # antes de pygame: activa DPI-aware
import pygame

from . import core
from .core import TYPE_LABELS
from .ui import (UI, BG, PANEL, PANEL2, LINE, TEXT, MUTED, DIM, ACCENT, ACCENT2,
                 GOOD, WARN, BAD)
from .padout import VirtualPad, PadState, PAD_BUTTONS
from .ffb import SDLHaptics
from . import system

APP = "RoSim"
VERSION = system.current_version()
W, H = 1240, 740
UI_EVENTS = (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEWHEEL, pygame.KEYDOWN,
             getattr(pygame, "TEXTINPUT", -1))

MODE_OPTS = [("none", "Sin asignar"), ("steer", "Dirección (volante)"),
             ("pedal", "Pedal / gatillo"), ("stick", "Eje de mando (stick)"),
             ("mouse_x", "Ratón X (sigue al stick)"), ("mouse_y", "Ratón Y (sigue al stick)"),
             ("servo", "Palanca de gases → teclas"), ("keys", "Eje → 2 teclas")]
STEER_OUT = [("LSX", "Stick izq. del mando"), ("TRACK", "Seguimiento (el juego gira solo)"),
             ("KEYS", "Teclas (A/D) por pulsos")]
PEDAL_OUT = [("RT", "Gatillo RT (acelerar)"), ("LT", "Gatillo LT (frenar)"),
             ("LSY+", "Stick izq. ↑"), ("LSY-", "Stick izq. ↓"),
             ("KEY", "Tecla"), ("NONE", "Nada (solo ver)")]
STICK_OUT = [("LSX", "Stick izq. X"), ("LSY", "Stick izq. Y"), ("RSX", "Stick der. X"),
             ("RSY", "Stick der. Y"), ("RT", "Gatillo RT"), ("LT", "Gatillo LT")]
EXTRA_OPTS = ([("", "—")] + [("pad:" + b, "Mando " + b) for b in PAD_BUTTONS] +
              [("act:toggle_output", "Salida ON/OFF"), ("act:toggle_mouse", "Ratón ON/OFF"),
               ("act:center_mouse", "Centro ratón = aquí"), ("act:resync", "Resincronizar gases")])

ROLES = {
    "wheel": [("steer", "Dirección", "Gira el volante a la DERECHA"),
              ("throttle", "Acelerador", "Pisa el ACELERADOR a fondo"),
              ("brake", "Freno", "Pisa el FRENO a fondo"),
              ("clutch", "Embrague", "Pisa el EMBRAGUE a fondo")],
    "stick": [("x", "Eje X (alabeo)", "Mueve el stick a la DERECHA"),
              ("y", "Eje Y (cabeceo)", "Empuja el stick hacia DELANTE"),
              ("twist", "Giro (timón)", "Gira el stick a la DERECHA")],
    "throttle": [("lever", "Palanca de gases", "Lleva la palanca de RALENTÍ a TOPE"),
                 ("lever2", "2ª palanca", "Lleva la 2ª palanca de ABAJO a ARRIBA")],
}


def asset(name):
    """Ruta a assets/ tanto ejecutando el .py como desde el .exe de PyInstaller."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(base, "assets", name)


def config_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, APP)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "config.json")


def key_name(e):
    k = e.key
    if pygame.K_a <= k <= pygame.K_z:
        return chr(k).upper()
    if pygame.K_0 <= k <= pygame.K_9:
        return chr(k)
    for i in range(1, 13):
        if k == getattr(pygame, "K_F%d" % i):
            return "F%d" % i
    for i in range(10):
        kk = getattr(pygame, "K_KP%d" % i, None) or getattr(pygame, "K_KP_%d" % i, None)
        if k == kk:
            return "NUM%d" % i
    table = {
        pygame.K_SPACE: "SPACE", pygame.K_RETURN: "ENTER", pygame.K_TAB: "TAB",
        pygame.K_BACKSPACE: "BACKSPACE", pygame.K_LSHIFT: "LSHIFT", pygame.K_RSHIFT: "RSHIFT",
        pygame.K_LCTRL: "LCTRL", pygame.K_RCTRL: "RCTRL", pygame.K_LALT: "LALT",
        pygame.K_RALT: "RALT", pygame.K_UP: "UP", pygame.K_DOWN: "DOWN",
        pygame.K_LEFT: "LEFT", pygame.K_RIGHT: "RIGHT", pygame.K_INSERT: "INSERT",
        pygame.K_HOME: "HOME", pygame.K_END: "END", pygame.K_PAGEUP: "PAGEUP",
        pygame.K_PAGEDOWN: "PAGEDOWN", pygame.K_CAPSLOCK: "CAPSLOCK",
        pygame.K_MINUS: "MINUS", pygame.K_PLUS: "PLUS", pygame.K_COMMA: "COMMA",
        pygame.K_PERIOD: "PERIOD", pygame.K_KP_PLUS: "NUM+", pygame.K_KP_MINUS: "NUM-",
        pygame.K_KP_MULTIPLY: "NUM*", pygame.K_KP_DIVIDE: "NUM/", pygame.K_KP_ENTER: "NUMENTER",
    }
    return table.get(k)


# ===========================================================================
class Device:
    def __init__(self, js, store):
        self.js = js
        self.iid = js.get_instance_id()
        self.name = js.get_name() or "Dispositivo"
        try:
            self.guid = js.get_guid()
        except Exception:
            self.guid = ""
        self.n_axes = js.get_numaxes()
        self.n_buttons = js.get_numbuttons()
        self.n_hats = js.get_numhats()
        self.info = core.classify(self.name, self.guid, self.n_axes, self.n_buttons)
        self.key = "%s|%s" % (self.name, self.guid)
        saved = store.get(self.key)
        base = core.default_device_config(self.info, self.n_axes, self.n_buttons)
        self.cfg = core.merge_defaults(saved, base) if saved else base
        for i in range(self.n_axes):
            a = self.cfg["axes"].get(str(i))
            self.cfg["axes"][str(i)] = core.merge_defaults(a, core.default_axis()) if a else core.default_axis()
        store[self.key] = self.cfg
        self.axes = [0.0] * self.n_axes
        self.btn = [False] * self.n_buttons
        self.hats = [(0, 0)] * self.n_hats
        self.live = {}
        self.servos = {}
        self.trackers = {}
        self.boost = {}
        self.at_lock = {}
        self.rest = {}
        self.prev_pressed = set()
        self.ffb = None

    @property
    def type(self):
        return self.cfg.get("type", self.info["type"])

    def read(self):
        js = self.js
        for i in range(self.n_axes):
            self.axes[i] = js.get_axis(i)
            if i not in self.rest:
                self.rest[i] = self.axes[i]
        for i in range(self.n_buttons):
            self.btn[i] = bool(js.get_button(i))
        for i in range(self.n_hats):
            self.hats[i] = js.get_hat(i)

    def button_ids(self):
        ids = ["b%d" % i for i in range(self.n_buttons)]
        for h in range(self.n_hats):
            ids += ["h%du" % h, "h%dd" % h, "h%dl" % h, "h%dr" % h]
        return ids

    def pressed(self, bid):
        if bid[0] == "b":
            i = int(bid[1:])
            return i < len(self.btn) and self.btn[i]
        h, d = int(bid[1:-1]), bid[-1]
        if h >= len(self.hats):
            return False
        x, y = self.hats[h]
        return {"u": y > 0, "d": y < 0, "l": x < 0, "r": x > 0}[d]

    def button_label(self, bid):
        if bid[0] == "b":
            return "Botón %d" % (int(bid[1:]) + 1)
        return "Cruceta %s" % {"u": "↑", "d": "↓", "l": "←", "r": "→"}[bid[-1]]

    def axes_with(self, mode):
        return [int(k) for k, a in self.cfg["axes"].items() if a["mode"] == mode and int(k) < self.n_axes]

    def close(self):
        if self.ffb:
            self.ffb.close()
            self.ffb = None


# ===========================================================================
class App:
    def __init__(self):
        pygame.init()
        pygame.joystick.init()
        pygame.display.set_caption("RoSim — Volantes, sidesticks y gases para Roblox")
        self.screen = pygame.display.set_mode((W, H))
        self._set_icon()
        self.ui = UI(self.screen)
        self.clock = pygame.time.Clock()

        self.cfg_file = config_path()
        self.store = {"global": dict(core.DEFAULT_GLOBAL), "devices": {}}
        self._load()
        self.g = self.store["global"]

        self.known_keys = set(self.store["devices"].keys())
        self.devices = {}       # instance_id -> Device
        self.order = []
        self.sel = None
        self.view = "device"    # device | settings | help
        self.tab = "live"
        self.scroll = {"axes": 0, "buttons": 0, "settings": 0}
        self.content_h = {}

        self.kb = winio.KeyBoard()
        self.pad = VirtualPad()
        self.haptics = SDLHaptics()
        self.follower = core.MouseFollower()
        self.rel_acc = [0.0, 0.0]

        self.wiz = None
        self.sync = None        # asistente "sincronizar con el volante del juego"
        self.cal = None         # pantalla "calibrar topes" (línea naranja, sin juego)
        self.gcal = None        # pantalla "calibrar con el juego" (punto a punto)
        self.toast_msg, self.toast_until = "", 0
        self.roblox_fg = False
        self.allowed = False
        self.next_fg_check = 0
        self.last_save_check = 0
        self.last_saved = json.dumps(self.store, sort_keys=True)
        self.test_rumble_until = 0
        self.center_capture_at = 0
        self.last_draw = 0
        self.last_t = time.perf_counter()
        self.pending = []
        self.cam_req = None
        self.cam_sent = 0.0
        self.cam_rmb_until = 0.0
        self.upd_found = []
        self.upd_msg = ""
        self.upd_done = False
        self.restart_after = False
        self.quit_now = False
        self.scan_updates()
        self.online = None          # {"version", "zip", "notas"} si hay una versión nueva en la web
        self.online_checked = False
        threading.Thread(target=self._bg_check, daemon=True).start()
        self.next_online_check = time.time() + 1800
        if self.logo_err:
            self.toast(self.logo_err, 8)

    # ----------------------------------------------------------- config
    def _load(self):
        try:
            with open(self.cfg_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.store["global"] = core.merge_defaults(data.get("global"), core.DEFAULT_GLOBAL)
            self.store["devices"] = data.get("devices", {})
            ver = data.get("global", {}).get("cfg_version", 1)
            if ver < 2:
                self.store["global"]["mouse_invert_y"] = False
            if ver < 3:   # la 1.1 podía asignar mal los ejes del sidestick: volver a X=0, Y=1
                for d in self.store["devices"].values():
                    if d.get("type") == "stick":
                        for k, a in d.get("axes", {}).items():
                            if a.get("mode") in ("mouse_x", "mouse_y", "servo"):
                                d["axes"][k] = core.default_axis()
                        if "0" in d.get("axes", {}):
                            d["axes"]["0"] = core.make_axis("mouse_x")
                        if "1" in d.get("axes", {}):
                            d["axes"]["1"] = core.make_axis("mouse_y")
            if any(old in self.store["global"].get("update_url", "")
                   for old in ("saile1200.github.io", "rosimapp.github.io")):
                self.store["global"]["update_url"] = core.DEFAULT_GLOBAL["update_url"]
            if not self.store["global"].get("update_url"):
                self.store["global"]["update_url"] = core.DEFAULT_GLOBAL["update_url"]
            self.store["global"]["cfg_version"] = 4
        except Exception:
            pass

    def save(self, force=False):
        s = json.dumps(self.store, sort_keys=True)
        if s != self.last_saved or force:
            try:
                with open(self.cfg_file, "w", encoding="utf-8") as f:
                    json.dump(self.store, f, indent=1, ensure_ascii=False)
                self.last_saved = s
            except Exception as e:
                self.toast("No se pudo guardar: %s" % e)

    def toast(self, msg, secs=3.0):
        self.toast_msg = msg
        self.toast_until = time.time() + secs

    def _set_icon(self):
        self.logo = None
        self.logo_err = ""
        try:
            pygame.display.set_icon(pygame.image.load(asset("logo_64.png")))
            self.logo = pygame.transform.smoothscale(pygame.image.load(asset("logo_256.png")).convert_alpha(), (44, 44))
        except Exception as e:
            self.logo_err = "No se encontró el logo (%s). Vuelve a descomprimir RoSim entero." % e
            s = pygame.Surface((32, 32), pygame.SRCALPHA)
            pygame.draw.circle(s, ACCENT, (16, 16), 14, 4)
            pygame.draw.line(s, ACCENT, (4, 18), (28, 18), 4)
            pygame.draw.line(s, ACCENT, (16, 18), (16, 30), 4)
            pygame.display.set_icon(s)

    # ---------------------------------------------------------- devices
    def add_device(self, index):
        try:
            js = pygame.joystick.Joystick(index)
            js.init()
        except Exception:
            return
        iid = js.get_instance_id()
        if iid in self.devices:
            return
        dev = Device(js, self.store["devices"])
        dev.ffb = self.haptics.open(iid)
        self.devices[iid] = dev
        self.order.append(iid)
        if self.sel is None or (self.devices.get(self.sel) and
                                self.devices[self.sel].type == "gamepad" and dev.type != "gamepad"):
            self.sel = iid
        self.toast("Conectado: %s" % dev.info["model"])

    def remove_device(self, iid):
        dev = self.devices.pop(iid, None)
        if dev:
            dev.close()
            self.order.remove(iid)
            self.toast("Desconectado: %s" % dev.name)
            if self.sel == iid:
                self.sel = self.order[0] if self.order else None

    def rescan(self):
        for iid in list(self.devices):
            self.remove_device(iid)
        pygame.joystick.quit()
        pygame.joystick.init()   # vuelve a generar JOYDEVICEADDED

    # ---------------------------------------------------------- output
    def compute(self, now, dt):
        """Lee todo, calcula salidas. Devuelve (teclas, estado_mando, usa_mando, ratón)."""
        keys = set()
        self.cam_req = None
        st = PadState()
        uses_pad = False
        mouse = {}
        g = self.g

        for iid in self.order:
            dev = self.devices[iid]
            dev.read()
            if not dev.cfg["enabled"]:
                continue
            for k, ax in dev.cfg["axes"].items():
                i = int(k)
                if i >= dev.n_axes:
                    continue
                raw = dev.axes[i]
                m = ax["mode"]
                live = {"raw": raw}
                if m == "steer":
                    deg, plain, out = core.steer_values(raw, ax)
                    sy = self.sync
                    gc = self.gcal
                    if gc and gc["dev"] == dev.iid and gc["axis"] == i:
                        out = self.gcal_output()
                    elif sy and sy["dev"] == dev.iid and sy["axis"] == i and sy["kind"] == "track":
                        out = self.sync_output(now, dt, ax)
                    elif sy and sy["dev"] == dev.iid and sy["axis"] == i and sy["phase"] == "dzadj":
                        out = float(ax["antidz"])      # buscando la zona muerta del juego con la cruceta
                    elif sy and sy["dev"] == dev.iid and sy["axis"] == i and sy["phase"] in ("intro", "wait"):
                        out = 0.0
                    elif ax["out"] == "TRACK":
                        tr = dev.trackers.setdefault(i, core.Tracker())
                        lock = max(1.0, float(ax["game_range"])) / 2.0
                        out = float(tr.update(deg / lock, dt, now, ax["t_full"], ax["t_ret"], ax["track_tol"]))
                        live["game_est"] = tr.est * lock
                    elif float(ax.get("boost", 0.0)) > 0 and dt > 0:
                        # respuesta rápida: mientras giras, adelanta la señal para que el juego llegue antes
                        ps, vel = dev.boost.get(i, (out, 0.0))
                        vraw = (out - ps) / dt
                        vel += (vraw - vel) * min(1.0, dt / 0.06)
                        dev.boost[i] = (out, vel)
                        if out != 0.0:
                            out = core.clamp(out + float(ax["boost"]) * vel * 0.2, -1.0, 1.0)
                    live.update(deg=deg, plain=plain, out=out)
                    if ax.get("cam_follow"):
                        f = core.clamp(deg / max(10.0, float(ax["cam_full_deg"])), -1.0, 1.0)
                        f = math.copysign(abs(f) ** max(0.3, float(ax["cam_curve"])), f)
                        cam = f * float(ax["cam_px"]) * (-1 if ax.get("cam_invert") else 1)
                        self.cam_req = (cam, ax)
                    if ax.get("synced") and ax.get("lock_beep", True) and not sy:
                        lock = float(ax["game_range"]) / 2.0
                        at_lock = abs(deg) >= lock - 2
                        if at_lock and not dev.at_lock.get(i):
                            system.beep(1175, 140)
                        if abs(deg) < lock - 15 or at_lock:
                            dev.at_lock[i] = at_lock
                    if ax["out"] == "KEYS":
                        if core.pwm_on(abs(out), now, ax["pwm_ms"]):
                            kk = ax["key_pos"] if out > 0 else ax["key_neg"]
                            if kk:
                                keys.add(kk)
                    else:
                        st.lx = out
                        uses_pad = True
                elif m == "pedal":
                    v, out = core.pedal_value(raw, ax)
                    live.update(v=v, out=out)
                    o = ax["out"]
                    if o == "RT":
                        st.rt = max(st.rt, out); uses_pad = True
                    elif o == "LT":
                        st.lt = max(st.lt, out); uses_pad = True
                    elif o == "LSY+":
                        st.ly += out; uses_pad = True
                    elif o == "LSY-":
                        st.ly -= out; uses_pad = True
                    elif o == "KEY" and ax["key"]:
                        on = core.pwm_on(out, now, ax["pwm_ms"]) if ax["pwm"] else out >= ax["threshold"]
                        if on:
                            keys.add(ax["key"])
                elif m == "stick":
                    out = core.signed_value(raw, ax)
                    live.update(out=out)
                    o = ax["out"]
                    uses_pad = True
                    if o == "LSX": st.lx = out
                    elif o == "LSY": st.ly = -out
                    elif o == "RSX": st.rx = out
                    elif o == "RSY": st.ry = -out
                    elif o == "RT": st.rt = (out + 1) / 2
                    elif o == "LT": st.lt = (out + 1) / 2
                elif m in ("mouse_x", "mouse_y"):
                    out = core.signed_value(raw, ax)
                    live.update(out=out)
                    prev = mouse.get(m, 0.0)
                    mouse[m] = out if abs(out) > abs(prev) else prev
                elif m == "servo":
                    v, target = core.pedal_value(raw, ax)
                    sv = dev.servos.setdefault(i, core.Servo())
                    d = sv.update(target, dt, now, ax["full_time"], ax["tol"])
                    live.update(v=target, est=sv.est, dir=d)
                    if d > 0 and ax["key_pos"]:
                        keys.add(ax["key_pos"])
                    elif d < 0 and ax["key_neg"]:
                        keys.add(ax["key_neg"])
                elif m == "keys":
                    out = core.signed_value(raw, ax)
                    live.update(out=out)
                    a = abs(out)
                    on = core.pwm_on(a, now, ax["pwm_ms"]) if ax["pwm"] else a >= ax["threshold"]
                    if on:
                        kk = ax["key_pos"] if out > 0 else ax["key_neg"]
                        if kk:
                            keys.add(kk)
                dev.live[i] = live

            # botones
            if self.gcal and self.gcal["dev"] == dev.iid:
                now_p = {b for b in dev.button_ids() if dev.pressed(b)}
                self.gcal_buttons(dev, now_p, now)
                dev.prev_pressed = now_p
                continue
            if self.sync and self.sync["dev"] == dev.iid:
                now_p = {b for b in dev.button_ids() if dev.pressed(b)}
                adj_btn = {b for b in now_p if b.endswith("l") or b.endswith("r")} if self.sync["kind"] == "normal" else set()
                left = any(b.endswith("l") for b in adj_btn)
                right = any(b.endswith("r") for b in adj_btn)
                self.sync["adj"] = (1 if right else 0) - (1 if left else 0)
                if (now_p - adj_btn) - dev.prev_pressed:
                    self.sync_mark(dev, now)
                dev.prev_pressed = now_p
                continue
            pressed_now = set()
            for bid, bind in dev.cfg["buttons"].items():
                if not dev.pressed(bid):
                    continue
                pressed_now.add(bid)
                if bind.get("key"):
                    keys.add(bind["key"])
                ex = bind.get("extra", "")
                if ex.startswith("pad:"):
                    st.buttons.add(ex[4:])
                    uses_pad = True
                elif ex.startswith("act:") and bid not in dev.prev_pressed:
                    self.do_action(ex[4:])
            dev.prev_pressed = pressed_now

        st.ly = core.clamp(st.ly, -1, 1)
        return keys, st, uses_pad, mouse

    def do_action(self, act):
        g = self.g
        if act == "toggle_output":
            g["output_on"] = not g["output_on"]
            self.toast("Salida " + ("ACTIVADA" if g["output_on"] else "DESACTIVADA"))
        elif act == "toggle_mouse":
            g["mouse_enabled"] = not g["mouse_enabled"]
            self.follower.reset()
            self.toast("Control del ratón " + ("ON" if g["mouse_enabled"] else "OFF"))
        elif act == "center_mouse":
            self.set_mouse_center_here()
        elif act == "resync":
            self.resync_all()

    EASY_STEPS = [
        ("x", "Mueve el stick a la DERECHA y mantenlo"),
        ("y", "Empuja el stick hacia ARRIBA (delante) y mantenlo"),
        ("speed", "Palanca de velocidad: de MÍNIMO a MÁXIMO (si no tiene, espera)"),
    ]

    # ------------------------------------------------- sincronizar volante
    SYNC_FRAC = 0.5      # en el paso 2 el juego va a la mitad de su tope
    SYNC_RAMP = 10.0     # s para subir de 0 a 60 % buscando la zona muerta del juego

    def start_sync(self, dev):
        steer = dev.axes_with("steer")
        if not steer:
            self.toast("Primero asigna la dirección (Detectar dirección).", 5)
            return
        ax = dev.cfg["axes"][str(steer[0])]
        if ax["out"] == "KEYS":
            self.toast("Cambia la salida de la dirección a «Stick izq.» o «Seguimiento» para sincronizar.", 6)
            return
        self.sync = {"dev": dev.iid, "axis": steer[0], "phase": "intro", "t0": 0.0,
                     "val": 0.0, "dz": None, "kind": "track" if ax["out"] == "TRACK" else "normal"}
        dev.prev_pressed = {b for b in dev.button_ids() if dev.pressed(b)}

    # ------------------------------------------------- calibrar volante
    CAL_STEP = 90.0      # grados entre líneas naranjas
    CAL_TOL = 5.0        # grados para "tocar" la línea

    def start_cal(self, dev):
        steer = dev.axes_with("steer")
        if not steer:
            self.toast("Primero detecta la dirección (Detectar dirección).", 5)
            return
        dev.read()
        i = steer[0]
        self.cal = {"dev": dev.iid, "axis": i, "phase": "center", "target": 0.0, "touch_t": 0.0,
                    "still_t": time.time(), "last_raw": dev.axes[i], "center": dev.axes[i],
                    "left": None, "right": None, "hits": 0}
        self.view = "device"

    def cal_deg(self, dev, raw):
        """Grados para dibujar (con el centro provisional de la calibración)."""
        ax = dev.cfg["axes"][str(self.cal["axis"])]
        x = raw - self.cal["center"]
        if ax.get("invert"):
            x = -x
        return x * float(ax["hw_range"]) / 2.0

    def cal_tick(self, now):
        c = self.cal
        dev = self.devices.get(c["dev"])
        if not dev:
            self.cal = None
            return
        raw = dev.axes[c["axis"]]
        if abs(raw - c["last_raw"]) > 0.002:
            c["still_t"] = now
            c["last_raw"] = raw
        still = now - c["still_t"]
        ph = c["phase"]
        if ph == "center":
            c["center"] = raw if still < 0.2 else c["center"]
            if still > 1.5:                       # volante recto y quieto 1,5 s
                c["center"] = raw
                c["phase"], c["target"], c["touch_t"] = "left", -self.CAL_STEP, 0.0
                system.beep(880, 150)
            return
        deg = self.cal_deg(dev, raw)
        if ph in ("left", "right"):
            sign = -1 if ph == "left" else 1
            touching = abs(deg - c["target"]) <= self.CAL_TOL or sign * deg > sign * c["target"]
            if touching:
                if not c["touch_t"]:
                    c["touch_t"] = now
                elif now - c["touch_t"] > 0.25:   # tocada: la línea avanza
                    c["hits"] += 1
                    c["target"] += sign * self.CAL_STEP
                    c["touch_t"] = 0.0
                    system.beep(1175, 90)
            else:
                c["touch_t"] = 0.0
            # final: el volante no gira más (quieto lejos del centro, o al máximo del eje)
            at_end = sign * deg > 45 and (still > 1.2 or (abs(raw) > 0.995 and still > 0.4))
            if at_end:
                c[ph] = raw
                system.beep(660, 120)
                system.beep(990, 200, delay=0.15)
                if ph == "left":
                    c["phase"], c["target"], c["touch_t"] = "right", self.CAL_STEP, 0.0
                else:
                    c["phase"], c["target"], c["touch_t"] = "back", 0.0, 0.0
            return
        if ph == "back":
            if abs(deg) <= self.CAL_TOL and still > 0.6:
                self.finish_cal(dev, raw)

    def finish_cal(self, dev, raw_center):
        c = self.cal
        ax = dev.cfg["axes"][str(c["axis"])]
        lo, hi, ctr = c["left"], c["right"], (c["center"] + raw_center) / 2.0
        if ax.get("invert"):                      # con eje invertido "izquierda" es el valor alto
            lo, hi = min(lo, hi), max(lo, hi)
        lo, hi = min(lo, hi), max(lo, hi)
        self.cal = None
        if not (lo < ctr < hi) or hi - lo < 0.2:
            self.toast("La calibración no salió bien. Repite y gira hasta el tope de cada lado.", 7)
            return
        ax["center"] = round(ctr, 5)
        ax["cal_left"] = round(lo, 5)
        ax["cal_right"] = round(hi, 5)
        ax["map_full"] = True                     # tu tope = tope del juego
        ax.pop("table", None)
        ax["game_range"] = float(ax["hw_range"])
        ax["out"] = "LSX"
        ax["deadzone"] = 0.0
        ax["gamma"] = 1.0
        ax["synced"] = True
        dev.trackers.pop(c["axis"], None)
        system.beep(1320, 300)
        self.toast("Volante calibrado (OK): recto = centro y tu tope = tope del juego.", 7)

    def draw_cal(self, area):
        ui = self.ui
        c = self.cal
        dev = self.devices[c["dev"]]
        ui.panel(area)
        raw = dev.axes[c["axis"]]
        deg = self.cal_deg(dev, raw) if c["phase"] != "center" else 0.0
        x0 = area.x + 28
        ui.text("CALIBRAR VOLANTE", (x0, area.y + 22), 13, MUTED, True)
        texts = {
            "center": ("Pon el volante RECTO y suéltalo", "Se queda como centro cuando esté quieto 1,5 s."),
            "left": ("Gira a la IZQUIERDA hasta tocar la línea naranja",
                     "Cada vez que la tocas avanza. Sigue hasta que tu volante no gire más y espera."),
            "right": ("Ahora a la DERECHA hasta tocar la línea naranja",
                      "Igual que antes: sigue hasta el tope de tu volante y espera."),
            "back": ("Vuelve al CENTRO", "Lleva el volante a la línea de arriba y suéltalo."),
        }
        t1, t2 = texts[c["phase"]]
        ui.text(t1, (x0, area.y + 48), 26, TEXT, True)
        ui.text(t2, (x0, area.y + 84), 15, MUTED)
        # pasos
        order = ["center", "left", "right", "back"]
        names = ["Centro", "Izquierda", "Derecha", "Centro"]
        sx = x0
        for n, nm in enumerate(names):
            cur = order.index(c["phase"])
            col = GOOD if n < cur else (ACCENT if n == cur else PANEL2)
            rr = pygame.Rect(sx, area.y + 114, 120, 28)
            ui.rect(rr, col, 14)
            ui.text(nm, rr.center, 13, BG if n <= cur else MUTED, True, "center")
            sx += 128
        # volante
        cx, cy, rad = area.centerx, area.y + 160 + (area.h - 220) // 2, min(200, (area.h - 230) // 2)
        scr = self.screen
        ang = math.radians(deg)

        def rot(px, py, a=ang):
            ca, sa = math.cos(a), math.sin(a)
            return (cx + px * ca - py * sa, cy + px * sa + py * ca)
        pygame.draw.circle(scr, (34, 37, 46), (cx, cy), rad + 26)
        # línea naranja objetivo (en el aro, a su ángulo)
        if c["phase"] != "center" or True:
            ta = math.radians(c["target"])
            touching = c["touch_t"] > 0
            colt = GOOD if touching else ACCENT
            p1 = (cx + (rad - 30) * math.sin(ta), cy - (rad - 30) * math.cos(ta))
            p2 = (cx + (rad + 34) * math.sin(ta), cy - (rad + 34) * math.cos(ta))
            pygame.draw.line(scr, colt, p1, p2, 9)
        pygame.draw.circle(scr, (58, 62, 76), (cx, cy), rad, 22)
        for sxp, syp in ((-rad + 14, 8), (rad - 14, 8), (0, rad - 14)):
            pygame.draw.line(scr, (72, 77, 94), rot(0, 8), rot(sxp, syp), 18)
        pygame.draw.circle(scr, (30, 32, 40), (cx, cy), 40)
        mk = [rot(-8, -rad - 13), rot(8, -rad - 13), rot(8, -rad + 13), rot(-8, -rad + 13)]
        pygame.draw.polygon(scr, ACCENT2, mk)
        ui.text("%+.0f°" % deg, (cx, cy), 30, TEXT, True, "center")
        info = "objetivo %+.0f°" % c["target"]
        if c["left"] is not None:
            info += "   ·   tope izq. guardado"
        ui.text(info, (cx, cy + rad + 40), 15, ACCENT, True, "midtop")
        if ui.button("cal_cancel", pygame.Rect(area.right - 190, area.bottom - 58, 160, 40), "Cancelar"):
            self.cal = None

    # ------------------------------------------- calibrar con el juego
    # Tú pones TU volante en una marca (30°, 60°, 90°...) y con la cruceta mueves el volante
    # DEL JUEGO hasta que quede igual. Así no hay que adivinar nada: cada punto es real.
    GCAL_MARKS = [20, 45, 90, 135, 180, 270, 360, 450, 540, 630, 720]

    def start_gcal(self, dev):
        steer = dev.axes_with("steer")
        if not steer:
            self.toast("Primero detecta la dirección (Detectar dirección).", 5)
            return
        ax = dev.cfg["axes"][str(steer[0])]
        hw2 = float(ax["hw_range"]) / 2.0
        marks = [m for m in self.GCAL_MARKS if m < hw2 - 5] + [hw2]
        self.gcal = {"dev": dev.iid, "axis": steer[0], "phase": "intro", "idx": 0, "pts": [],
                     "t0": 0.0, "out": 0.0, "adj": 0, "adj_t": 0.0, "marks": marks,
                     "last_press": 0.0, "at_mark": False}
        self.view = "device"

    def gcal_go(self):
        g = self.gcal
        dev = self.devices.get(g["dev"])
        if not dev:
            self.gcal = None
            return
        self.calibrate_center(dev, quiet=True)
        ax = dev.cfg["axes"][str(g["axis"])]
        ax["out"] = "LSX"
        ax["map_full"] = False
        g["phase"] = "wait"
        g["t0"] = time.time()

    def gcal_output(self):
        g = self.gcal
        return float(g["out"]) if g["phase"] in ("dz", "mark") else 0.0

    def gcal_deg(self, dev):
        g = self.gcal
        ax = dev.cfg["axes"][str(g["axis"])]
        raw = dev.axes[g["axis"]] - float(ax.get("center", 0.0))
        if ax.get("invert"):
            raw = -raw
        return raw * float(ax["hw_range"]) / 2.0

    def gcal_guess(self):
        """Salida inicial para la marca siguiente (para que solo tengas que afinar)."""
        g = self.gcal
        pts = g["pts"]
        m = g["marks"][g["idx"]]
        if len(pts) >= 2:
            (d0, o0), (d1, o1) = pts[-2], pts[-1]
            return core.clamp(o1 + (o1 - o0) / max(1e-6, d1 - d0) * (m - d1), 0.0, 1.0)
        if pts:
            d1, o1 = pts[-1]
            return core.clamp(o1 + 0.1, 0.0, 1.0)
        return core.clamp(g["dz"] + 0.05, 0.0, 1.0)

    def gcal_tick(self, now):
        g = self.gcal
        dev = self.devices.get(g["dev"])
        if not dev:
            self.gcal = None
            return
        if g["phase"] == "wait" and now - g["t0"] > 3.0 and self.allowed:
            g["phase"] = "dz"
            g["out"] = 0.0
            system.beep(880, 180)
        if g["phase"] in ("dz", "mark") and g["adj"] and self.allowed:
            held = now - g["adj_t"]
            rate = 0.06 if held < 0.6 else (0.18 if held < 1.6 else 0.4)   # mantener = más rápido
            dt = min(0.05, now - g.get("last_adj", now))
            g["out"] = core.clamp(g["out"] + g["adj"] * rate * dt, 0.0, 1.0)
            if now - g.get("tick", 0) > 0.25:
                g["tick"] = now
                system.beep(1500 if g["adj"] > 0 else 1000, 30)
        g["last_adj"] = now
        if g["phase"] == "mark":
            near = abs(self.gcal_deg(dev) - g["marks"][g["idx"]]) <= 3.0
            if near and not g["at_mark"]:
                system.beep(1175, 70)
            g["at_mark"] = near

    def gcal_buttons(self, dev, now_p, now):
        g = self.gcal
        left = any(b.endswith("l") and b.startswith("h") for b in now_p)
        right = any(b.endswith("r") and b.startswith("h") for b in now_p)
        adj = (1 if right else 0) - (1 if left else 0)
        if adj != g["adj"]:
            g["adj"] = adj
            g["adj_t"] = now
        others = {b for b in now_p if not (b.startswith("h") and b[-1] in "lr")}
        if others - dev.prev_pressed:
            self.gcal_mark(dev, now)

    def gcal_mark(self, dev, now):
        g = self.gcal
        double = now - g["last_press"] < 0.6
        g["last_press"] = now
        if g["phase"] == "dz":
            g["dz"] = g["out"]
            g["phase"] = "mark"
            g["out"] = self.gcal_guess()
            system.beep(660, 120)
            system.beep(990, 200, delay=0.15)
            return
        if g["phase"] != "mark":
            return
        if double and g["pts"]:            # doble pulsación = terminar (he llegado a mi tope)
            self.finish_gcal(dev)
            return
        deg = abs(self.gcal_deg(dev))
        if deg < 5:
            self.toast("Gira tu volante hasta la línea naranja antes de pulsar.", 4)
            return
        if g["pts"] and deg <= g["pts"][-1][0] + 2:
            self.toast("Gira más que en el paso anterior (o pulsa dos veces para terminar).", 4)
            return
        g["pts"].append((deg, g["out"]))
        system.beep(1175, 90)
        if g["idx"] >= len(g["marks"]) - 1:
            self.finish_gcal(dev)
            return
        g["idx"] += 1
        g["out"] = self.gcal_guess()

    def finish_gcal(self, dev, end_by_wheel=False):
        g = self.gcal
        ax = dev.cfg["axes"][str(g["axis"])]
        self.gcal = None
        pts = sorted(g["pts"])
        if len(pts) < 2:
            self.toast("Hacen falta al menos 2 marcas. Repite la calibración.", 7)
            return
        cdz = float(ax.get("center_deg", 1.0))
        dz = float(g.get("dz", 0.0))
        table = [[round(cdz, 2), round(dz, 4)]]
        for d, o in pts:
            if d > table[-1][0] + 0.5 and o > table[-1][1]:
                table.append([round(d, 2), round(o, 4)])
        ax["table"] = table
        ax["antidz"] = 0.0
        ax["deadzone"] = 0.0
        ax["gamma"] = 1.0
        ax["synced"] = True
        ax["game_range"] = float(round(2 * table[-1][0]))
        system.beep(1320, 300)
        self.toast("Calibrado 1:1 con el juego (OK): %d puntos hasta %.0f°. Más allá el juego no gira más."
                   % (len(table), table[-1][0]), 9)

    def draw_gcal(self, area):
        ui = self.ui
        g = self.gcal
        dev = self.devices[g["dev"]]
        ui.panel(area)
        x0 = area.x + 28
        ui.text("CALIBRAR CON EL JUEGO", (x0, area.y + 22), 13, MUTED, True)
        ph = g["phase"]
        if ph == "intro":
            lines = ["1. Súbete al vehículo en Roblox. Deja tu volante RECTO y pulsa EMPEZAR. Vuelve a Roblox.",
                     "2. Pitido: deja tu volante recto. Mantén → en la cruceta: el volante del juego girará",
                     "    poco a poco. En cuanto EMPIECE a moverse, pulsa un botón (← para volver).",
                     "3. Doble pitido: gira TU volante a la línea naranja (pitido corto al llegar).",
                     "    Con ← → de la cruceta mueve el volante DEL JUEGO hasta que quede igual que el tuyo.",
                     "    Pulsa un botón. Se repite con marcas más grandes.",
                     "4. Cuando tu volante no llegue a la siguiente marca, pulsa un botón DOS veces seguidas.",
                     "    El juego no girará más que tu volante."]
            ui.text("El juego girará exactamente lo mismo que tu volante", (x0, area.y + 48), 26, TEXT, True)
            y = area.y + 98
            for ln in lines:
                ui.text(ln, (x0, y), 15, TEXT if ln[0].isdigit() else MUTED)
                y += 25
            ui.text("Mantener ← o → más tiempo = más rápido.  El force feedback se apaga durante la calibración.",
                    (x0, y + 10), 14, ACCENT2)
            if ui.button("gcal_go", pygame.Rect(x0, area.bottom - 70, 240, 46), "EMPEZAR", color=ACCENT,
                         bold=True, size=18):
                self.gcal_go()
        else:
            deg = self.gcal_deg(dev)
            if ph == "wait":
                title = "Vuelve a Roblox… (pitido a los 3 s)"
            elif ph == "dz":
                title = "Volante RECTO · mantén → hasta que el del juego EMPIECE a moverse · pulsa un botón"
            else:
                title = "Pon tu volante en la línea naranja (%d°) · iguala el del juego con ← → · pulsa un botón" \
                        % g["marks"][g["idx"]]
            ui.text(ui.fit(title, area.w - 56, 19, True), (x0, area.y + 48), 19, TEXT, True)
            if ph == "wait" and not self.allowed:
                ui.text("Esperando a que Roblox esté delante…", (x0, area.y + 80), 15, WARN)
            elif ph in ("dz", "mark"):
                ui.text("Enviando al juego: %d%%%s" % (round(g["out"] * 100), "   ◀ ajustando ▶" if g["adj"] else ""),
                        (x0, area.y + 80), 15, ACCENT, True)
            cx, cy = area.centerx, area.y + 140 + (area.h - 200) // 2
            rad = min(190, (area.h - 230) // 2)
            scr = self.screen
            pygame.draw.circle(scr, (34, 37, 46), (cx, cy), rad + 26)
            for d, o in g["pts"]:            # marcas ya hechas
                a = math.radians(d)
                pygame.draw.line(scr, GOOD, (cx + (rad - 26) * math.sin(a), cy - (rad - 26) * math.cos(a)),
                                 (cx + (rad + 30) * math.sin(a), cy - (rad + 30) * math.cos(a)), 4)
            if ph == "mark":                 # línea naranja: dónde tienes que poner TU volante
                m = math.radians(g["marks"][g["idx"]])
                col = GOOD if g["at_mark"] else ACCENT
                pygame.draw.line(scr, col, (cx + (rad - 32) * math.sin(m), cy - (rad - 32) * math.cos(m)),
                                 (cx + (rad + 40) * math.sin(m), cy - (rad + 40) * math.cos(m)), 10)
            pygame.draw.circle(scr, (58, 62, 76), (cx, cy), rad, 22)
            ang = math.radians(deg)

            def rot(px, py):
                ca, sa = math.cos(ang), math.sin(ang)
                return (cx + px * ca - py * sa, cy + px * sa + py * ca)
            for sxp, syp in ((-rad + 14, 8), (rad - 14, 8), (0, rad - 14)):
                pygame.draw.line(scr, (72, 77, 94), rot(0, 8), rot(sxp, syp), 18)
            pygame.draw.polygon(scr, ACCENT2, [rot(-8, -rad - 13), rot(8, -rad - 13), rot(8, -rad + 13), rot(-8, -rad + 13)])
            pygame.draw.circle(scr, (30, 32, 40), (cx, cy), 40)
            ui.text("%+.0f°" % deg, (cx, cy), 30, TEXT, True, "center")
            if ph == "mark":
                ui.text("Marca %d de %d   ·   la marca azul es tu volante" % (g["idx"] + 1, len(g["marks"])),
                        (cx, cy + rad + 40), 14, MUTED, anchor="midtop")
                if g["pts"] and ui.button("gcal_finish", pygame.Rect(area.x + 28, area.bottom - 58, 280, 40),
                                          "Terminar aquí (es mi tope)"):
                    self.finish_gcal(dev)
                    return
        if self.gcal and ui.button("gcal_cancel", pygame.Rect(area.right - 190, area.bottom - 58, 160, 40), "Cancelar"):
            self.gcal = None

    # ------------------------------------------------ calibraciones guardadas
    CALIB_KEYS = ("center", "cal_left", "cal_right", "map_full", "table", "antidz", "deadzone", "gamma",
                  "game_range", "hw_range", "center_deg", "out", "invert", "boost", "t_full", "t_ret",
                  "synced", "cam_follow", "cam_px", "cam_full_deg", "cam_curve", "cam_smooth", "cam_rmb",
                  "cam_invert", "lock_beep", "game_lock")

    def profiles(self):
        return self.store.setdefault("profiles", {})

    def save_profile(self, dev, name):
        name = (name or "").strip()[:40]
        if not name:
            self.toast("Escribe un nombre para la calibración.", 4)
            return
        steer = dev.axes_with("steer")
        if not steer:
            self.toast("No hay eje de dirección que guardar.", 4)
            return
        ax = dev.cfg["axes"][str(steer[0])]
        data = {k: copy.deepcopy(ax[k]) for k in self.CALIB_KEYS if k in ax}
        data["_saved"] = time.strftime("%d/%m/%Y %H:%M")
        data["_device"] = dev.info["model"]
        self.profiles()[name] = data
        self.save(force=True)
        self.toast("Calibración «%s» guardada (OK)" % name, 5)

    def load_profile(self, dev, name):
        data = self.profiles().get(name)
        steer = dev.axes_with("steer")
        if not data or not steer:
            return
        ax = dev.cfg["axes"][str(steer[0])]
        for k in self.CALIB_KEYS:
            if k in data:
                ax[k] = copy.deepcopy(data[k])
            elif k in ("table", "cal_left", "cal_right"):
                ax.pop(k, None)
        dev.trackers.pop(steer[0], None)
        dev.boost.pop(steer[0], None)
        self.toast("Calibración «%s» cargada (OK)" % name, 5)

    def draw_calibs(self, dev, c):
        ui = self.ui
        a = pygame.Rect(c.x, c.y, (c.w - 12) // 2, c.h)
        b = pygame.Rect(a.right + 12, c.y, c.w - a.w - 12, c.h)
        ui.panel(a)
        ui.panel(b)
        steer = dev.axes_with("steer")
        x, w, y = a.x + 20, a.w - 40, a.y + 18
        ui.text("CALIBRACIÓN ACTUAL", (x, y), 12, MUTED, True)
        y += 26
        busy = self.wiz is not None or self.sync is not None or self.cal is not None or self.gcal is not None
        if not steer:
            ui.text("Primero detecta la dirección (pestaña En vivo).", (x, y), 15, WARN)
            return
        ax = dev.cfg["axes"][str(steer[0])]
        if ax.get("map_full"):
            st, col = "Tu tope = tope del juego", GOOD
        elif ax.get("table"):
            st, col = "1:1 con el juego (por marcas)", GOOD
        else:
            st, col = "Sin calibrar", WARN
        ui.text(st, (x, y), 18, col, True)
        y += 34
        if ui.button("cb_cal", pygame.Rect(x, y, w, 42), "CALIBRAR VOLANTE (tu tope = tope del juego)",
                     color=ACCENT, bold=True, enabled=not busy):
            self.start_cal(dev)
        y += 52
        if ui.button("cb_match", pygame.Rect(x, y, w, 38), "AJUSTAR GRADOS CON EL JUEGO (paso 2)",
                     color=(0, 92, 120), bold=True, enabled=not busy):
            self.start_match(dev)
        y += 48
        if ui.button("cb_gcal", pygame.Rect(x, y, w, 34), "Calibrar con el juego por marcas (avanzado)",
                     enabled=not busy):
            self.start_gcal(dev)
        y += 56
        ui.text("RESPUESTA DEL VOLANTE EN EL JUEGO", (x, y), 12, MUTED, True)
        y += 24
        ax["boost"] = ui.slider("cb_boost", pygame.Rect(x, y, w, 40), float(ax.get("boost", 0.0)), 0.0, 1.0,
                                "Respuesta rápida (si el juego va lento)", "{:.0%}", 0.05)
        y += 50
        for ln in ("Adelanta la señal mientras giras para que el volante del",
                   "juego llegue antes. Súbela poco a poco: si se pasa, baja.",
                   "En Croydon sube también «steering speed» en sus ajustes."):
            ui.text(ln, (x, y), 13, MUTED)
            y += 19
        y += 14
        ax["antidz"] = ui.slider("cb_adz", pygame.Rect(x, y, w, 40), float(ax["antidz"]), 0.0, 0.6,
                                 "Anti-zona muerta (0% si el juego no tiene)", "{:.0%}", 0.01)

        # guardadas
        x, w, y = b.x + 20, b.w - 40, b.y + 18
        ui.text("CALIBRACIONES GUARDADAS", (x, y), 12, MUTED, True)
        y += 26
        ui.text("Nombre:", (x, y + 16), 14, MUTED, anchor="midleft")
        self.profile_name = ui.textfield("cb_name", pygame.Rect(x + 70, y, w - 190, 32),
                                         getattr(self, "profile_name", ""), "p. ej. Croydon bus")
        if ui.button("cb_save", pygame.Rect(x + w - 110, y, 110, 32), "Guardar", color=ACCENT, bold=True):
            self.save_profile(dev, self.profile_name)
            self.profile_name = ""
        y += 46
        profs = self.profiles()
        if not profs:
            ui.text("Aún no hay calibraciones guardadas.", (x, y + 6), 14, DIM)
            ui.text("Calibra para un juego, ponle nombre y pulsa Guardar.", (x, y + 28), 13, DIM)
        for name in sorted(profs, key=lambda n: n.lower()):
            if y > b.bottom - 50:
                break
            p = profs[name]
            row = pygame.Rect(x, y, w, 50)
            ui.rect(row, PANEL2, 10)
            ui.text(ui.fit(name, w - 230, 15, True), (x + 12, y + 8), 15, TEXT, True)
            kind = "tope = tope" if p.get("map_full") else ("1:1 marcas" if p.get("table") else "manual")
            ui.text("%s · %s" % (kind, p.get("_saved", "")), (x + 12, y + 29), 12, MUTED)
            if ui.button("cb_load_" + name, pygame.Rect(row.right - 206, y + 9, 110, 32), "Cargar",
                         color=(0, 92, 120), bold=True):
                self.load_profile(dev, name)
            if ui.button("cb_del_" + name, pygame.Rect(row.right - 88, y + 9, 78, 32), "Borrar"):
                if self.confirm_del == name:
                    profs.pop(name, None)
                    self.confirm_del = None
                    self.toast("Calibración «%s» borrada" % name, 4)
                else:
                    self.confirm_del = name
                    self.toast("Pulsa Borrar otra vez para confirmar", 3)
            y += 58

    confirm_del = None

    def calibrate_center(self, dev, quiet=False):
        dev.read()
        for i in dev.axes_with("steer"):
            dev.cfg["axes"][str(i)]["center"] = round(dev.axes[i], 5)
            dev.trackers.pop(i, None)
        if not quiet:
            self.toast("Centro calibrado (OK): así queda tu volante recto = 0°.", 5)

    def start_match(self, dev):
        steer = dev.axes_with("steer")
        if not steer:
            self.toast("Primero detecta la dirección.", 5)
            return
        ax = dev.cfg["axes"][str(steer[0])]
        if not ax.get("map_full"):
            self.toast("Primero pulsa CALIBRAR VOLANTE (paso 1).", 6)
            return
        if ax["out"] == "TRACK":
            ax["out"] = "LSX"
        self.start_sync(dev)
        if self.sync:
            self.sync["kind"] = "normal"

    def sync_go(self):
        dev = self.devices.get(self.sync["dev"])
        if dev:                       # el volante está recto al empezar: es el centro
            self.calibrate_center(dev, quiet=True)
            ax = dev.cfg["axes"][str(self.sync["axis"])]
            self.sync["on_full"] = bool(ax.get("map_full")) and self.sync["kind"] == "normal"
            if self.sync["on_full"]:
                # ya calibrado (topes): solo falta saber cuántos grados tiene el volante del juego
                if not ax.get("game_lock"):
                    ax["game_lock"] = float(ax["hw_range"])
            else:
                ax["map_full"] = False            # la sincronización avanzada usa el tope del juego
            ax.pop("table", None)
            if self.sync["kind"] == "normal":
                ax["out"] = "LSX"
                ax["antidz"] = 0.0          # se ajusta en el paso 1 subiendo con →
                ax["deadzone"] = 0.0
                ax["gamma"] = 1.0
                if ax["game_range"] < ax["hw_range"] * 0.5:
                    ax["game_range"] = float(ax["hw_range"])
        self.sync["phase"] = "wait"
        self.sync["t0"] = time.time()

    def sync_output(self, now, dt=0.0, ax=None):
        sy = self.sync
        ph = sy["phase"]
        if sy["kind"] == "track":
            if ph == "full":
                return 1.0
            if ph == "half":
                tr = sy["tracker"]
                return float(tr.update(0.5, dt, now, sy["t_full"], sy["t_ret"], 0.02))
            return 0.0
        if ph == "dz":
            v = min(0.6, (now - sy["t0"]) / self.SYNC_RAMP * 0.6)
            sy["val"] = v
            if now - sy["t0"] > self.SYNC_RAMP + 5:      # nadie pulsó: el juego no tiene zona muerta visible
                self.sync_next_lock(now, None)
            return v
        if ph == "lock":   # mitad del recorrido del juego (alcanzable aunque el juego gire más que tu volante)
            dz = sy["dz"] or 0.0
            return dz + self.SYNC_FRAC * (1.0 - dz)
        return 0.0

    def sync_tick(self, now):
        sy = self.sync
        if sy["phase"] == "wait" and now - sy["t0"] > 3.0 and self.allowed:
            sy["phase"] = "full" if sy["kind"] == "track" else "dzadj"
            sy["t0"] = now
            system.beep(880, 180)
        if sy["kind"] == "normal" and sy["phase"] in ("dzadj", "ratio") and sy.get("adj") and self.allowed:
            dev = self.devices.get(sy["dev"])
            if dev:
                ax = dev.cfg["axes"][str(sy["axis"])]
                dt = min(0.05, now - sy.get("last_adj", now))
                if sy["phase"] == "dzadj":      # → = el juego empieza a moverse antes
                    ax["antidz"] = round(core.clamp(ax["antidz"] + sy["adj"] * 0.12 * dt, 0.0, 0.6), 4)
                else:                            # → = el volante del juego gira MÁS
                    key = "game_lock" if sy.get("on_full") else "game_range"
                    ax[key] = float(core.clamp(ax[key] * (1 - sy["adj"] * 0.45 * dt), 60, 7200))
                if now - sy.get("last_tick", 0) > 0.3:
                    sy["last_tick"] = now
                    system.beep(1500 if sy["adj"] > 0 else 1000, 35)
        sy["last_adj"] = now
        if sy["phase"] == "full" and now - sy["t0"] > 20:
            self.sync = None
            self.toast("Sincronización cancelada (no pulsaste ningún botón).", 6)
        elif sy["phase"] == "ret" and now - sy["t0"] > 12:      # no vuelve solo al centro
            self.sync_to_half(now, 0.0, est=1.0)
        elif sy["phase"] == "half" and now - sy["t0"] > 60:
            self.sync = None
            self.toast("Sincronización cancelada (no pulsaste ningún botón).", 6)
        elif sy["phase"] == "lock" and now - sy["t0"] > 45:
            self.sync = None
            self.toast("Sincronización cancelada (no pulsaste ningún botón).", 6)
        if self.sync and sy["phase"] in ("dz", "lock", "full", "ret", "half", "dzadj", "ratio") and not self.allowed:
            sy["paused"] = True   # Roblox no está delante: se queda esperando

    def sync_next_lock(self, now, dz):
        sy = self.sync
        sy["dz"] = dz
        sy["phase"] = "lock"
        sy["t0"] = now
        system.beep(660, 120)
        system.beep(990, 220, delay=0.15)

    def sync_to_half(self, now, t_ret, est):
        sy = self.sync
        sy["t_ret"] = t_ret
        sy["tracker"] = core.Tracker(est=est)
        sy["phase"] = "half"
        sy["t0"] = now
        system.beep(660, 120)
        system.beep(990, 220, delay=0.15)

    def sync_mark(self, dev, now):
        sy = self.sync
        if sy["kind"] == "normal":
            ax = dev.cfg["axes"][str(sy["axis"])]
            if sy["phase"] == "dzadj":
                sy["phase"] = "ratio"
                sy["t0"] = now
                system.beep(660, 120)
                system.beep(990, 220, delay=0.15)
            elif sy["phase"] == "ratio":
                self.sync = None
                ax["synced"] = True
                system.beep(1320, 300)
                if sy.get("on_full"):
                    ax["game_range"] = float(min(ax["hw_range"], ax["game_lock"]))
                    self.toast("Ajustado (OK): el juego gira lo mismo que tú y se para en tu tope (%.0f°)."
                               % (ax["game_range"] / 2), 8)
                else:
                    self.toast("Sincronizado (OK): tope del juego %.0f° por lado, zona muerta %d%%"
                               % (ax["game_range"] / 2, round(ax["antidz"] * 100)), 8)
            return
        if sy["kind"] == "track":
            if sy["phase"] == "full":
                sy["t_full"] = max(0.1, now - sy["t0"] - 0.15)     # menos el tiempo de reacción
                sy["phase"] = "ret"
                sy["t0"] = now
                system.beep(660, 180)
            elif sy["phase"] == "ret":
                self.sync_to_half(now, max(0.1, now - sy["t0"] - 0.15), est=0.0)
            elif sy["phase"] == "half":
                i = sy["axis"]
                ax = dev.cfg["axes"][str(i)]
                deg = abs(dev.live.get(i, {}).get("deg", 0.0))
                self.sync = None
                system.beep(1320, 300)
                if deg < 10:
                    self.toast("Giraste muy poco (%.0f°). Repite y deja tu volante igual que el del juego." % deg, 7)
                    return
                ax["out"] = "TRACK"
                ax["game_range"] = float(round(2 * deg / 0.5))
                ax["t_full"] = round(sy["t_full"], 2)
                ax["t_ret"] = round(sy["t_ret"], 2)
                ax["antidz"] = 0.0
                ax["deadzone"] = 0.0
                ax["gamma"] = 1.0
                ax["synced"] = True
                dev.trackers.pop(i, None)
                self.toast("Modo seguimiento listo (OK): tope del juego %.0f° por lado, %.1f s hasta el tope%s"
                           % (ax["game_range"] / 2, ax["t_full"],
                              "" if ax["t_ret"] else ", no vuelve solo al centro"), 9)
            return
        if sy["phase"] == "dz":
            dz = max(0.0, sy["val"] - 0.015)        # restar el tiempo de reacción
            self.sync_next_lock(now, dz)
        elif sy["phase"] == "lock":
            i = sy["axis"]
            ax = dev.cfg["axes"][str(i)]
            deg = abs(dev.live.get(i, {}).get("deg", 0.0))
            self.sync = None
            system.beep(1320, 300)
            if deg < 10:
                self.toast("Giraste muy poco (%.0f°). Repite y deja tu volante igual que el del juego." % deg, 7)
                return
            ax["game_range"] = float(round(2 * deg / self.SYNC_FRAC))   # sin límite: 1:1 aunque el juego gire más
            if sy["dz"] is not None:
                ax["antidz"] = round(sy["dz"], 3)
            ax["deadzone"] = 0.0
            ax["gamma"] = 1.0
            ax["synced"] = True
            extra = ""
            if ax["game_range"] > ax["hw_range"] + 5:
                extra = " · tu volante llega hasta el %d%% del juego" % round(100 * ax["hw_range"] / ax["game_range"])
            self.toast("Sincronizado (OK): 1° tuyo = 1° del juego (tope del juego %.0f° por lado)%s"
                       % (ax["game_range"] / 2, extra), 9)

    def draw_sync(self):
        ui = self.ui
        sy = self.sync
        dev = self.devices.get(sy["dev"])
        if not dev:
            self.sync = None
            return
        s = pygame.Surface((W, H), pygame.SRCALPHA)
        s.fill((0, 0, 0, 170))
        self.screen.blit(s, (0, 0))
        r = pygame.Rect(0, 0, 760, 470)
        r.center = (W // 2 + 120, H // 2)
        ui.panel(r, PANEL, 16, ACCENT)
        x, y, w = r.x + 32, r.y + 26, r.w - 64
        ui.text("SINCRONIZAR CON EL VOLANTE DEL JUEGO", (x, y), 13, MUTED, True)
        y += 30
        ph = sy["phase"]
        if sy["kind"] == "track":
            steps = [
                ("Súbete a un coche en Roblox y quédate parado. Deja TU volante en el centro.", "intro"),
                ("Pulsa EMPEZAR y vuelve a Roblox. A los 3 s suena un pitido.", "wait"),
                ("El volante del juego gira a la derecha. Cuando llegue al TOPE, pulsa cualquier botón de tu volante.", "full"),
                ("RoSim lo suelta. Cuando el volante del juego vuelva al CENTRO, pulsa un botón (si no vuelve, espera).", "ret"),
                ("Doble pitido: el volante del juego se queda a MITAD. Gira tu volante hasta dejarlo igual y pulsa un botón.", "half"),
            ]
            order = ["intro", "wait", "full", "ret", "half"]
            return self._draw_sync_steps(r, x, y, w, steps, order, ph, sy, dev)
        steps = [
            ("Súbete al vehículo en Roblox. Deja TU volante RECTO (será el centro).", "intro"),
            ("Pulsa EMPEZAR y vuelve a Roblox. A los 3 s suena un pitido.", "wait"),
            ("Deja tu volante recto. Mantén → en la cruceta: el volante del juego se irá girando poco a poco. Suelta en cuanto EMPIECE a moverse (← para volver atrás) y pulsa cualquier botón.", "dzadj"),
            ("Doble pitido: gira tu volante unos 90°. Si el del juego gira MENOS que el tuyo, mantén →; si gira MÁS, mantén ←. Cuando estén iguales, pulsa un botón.", "ratio"),
        ]
        order = ["intro", "wait", "dzadj", "ratio"]
        return self._draw_sync_steps(r, x, y, w, steps, order, ph, sy, dev)

    def _draw_sync_steps(self, r, x, y, w, steps, order, ph, sy, dev):
        ui = self.ui
        cur = order.index(ph)
        for n, (txt, key) in enumerate(steps):
            done, active = n < cur, n == cur
            col = GOOD if done else (TEXT if active else DIM)
            pygame.draw.circle(self.screen, ACCENT if active else (GOOD if done else PANEL2), (x + 14, y + 14), 14)
            ui.text("OK" if done else str(n + 1), (x + 14, y + 14), 12 if done else 15, BG if (active or done) else MUTED, True, "center")
            words, line, ly = txt.split(" "), "", y + 4
            for wd in words:
                t = (line + " " + wd).strip()
                if ui.text_w(t, 16, active) > w - 50:
                    ui.text(line, (x + 44, ly), 16, col, active)
                    ly += 22
                    line = wd
                else:
                    line = t
            ui.text(line, (x + 44, ly), 16, col, active)
            y = ly + 34
        y = r.bottom - 112
        if ph == "dz":
            ui.text("Enviando al juego: %d%%" % round(sy["val"] * 100), (x, y), 15, TEXT, True)
            ui.bar_h(pygame.Rect(x, y + 26, w, 10), sy["val"] / 0.6, ACCENT)
        elif ph in ("lock", "half"):
            deg = dev.live.get(sy["axis"], {}).get("deg", 0.0)
            ui.text("Tu volante: %+.0f°" % deg, (x, y), 22, TEXT, True)
        elif ph in ("dzadj", "ratio"):
            lv = dev.live.get(sy["axis"], {})
            axc = dev.cfg["axes"][str(sy["axis"])]
            ui.text("Tu volante: %+.0f°   ·   enviando %+d%%" % (lv.get("deg", 0.0), round(lv.get("out", 0.0) * 100)),
                    (x, y), 20, TEXT, True)
            val = ("zona muerta %d%%" % round(axc["antidz"] * 100) if ph == "dzadj"
                   else "volante del juego: %.0f° por lado" % (
                       (axc.get("game_lock") or axc["hw_range"]) / 2 if sy.get("on_full") else axc["game_range"] / 2))
            ui.text(val + ("   ◀ ajustando ▶" if sy.get("adj") else ""), (x, y + 30), 15, ACCENT, True)
        elif ph in ("full", "ret"):
            ui.text("Contando: %.1f s" % (time.time() - sy["t0"]), (x, y), 22, TEXT, True)
        elif ph == "wait":
            ui.text("Esperando a que Roblox esté delante…" if not self.allowed else "Preparado…", (x, y), 15, WARN)
        if sy.get("paused") and not self.allowed and ph in ("dz", "lock"):
            ui.text("Pausado: vuelve a la ventana de Roblox.", (x, y + 44), 14, WARN)
        by = r.bottom - 62
        if ph == "intro":
            if ui.button("sync_go", pygame.Rect(x, by, 220, 42), "EMPEZAR", color=ACCENT, bold=True, size=17):
                self.sync_go()
            if ui.button("sync_beep", pygame.Rect(r.right - 32 - 160, by - 52, 160, 38), "Probar pitido"):
                system.beep(880, 250)
            other = "normal" if sy["kind"] == "track" else "track"
            lab = ("Mi juego SÍ sigue a mi volante" if other == "normal"
                   else "El volante del juego sigue girando solo")
            if ui.button("sync_kind", pygame.Rect(x + 232, by, 300, 42), lab, color=(0, 92, 120), size=14):
                sy["kind"] = other
                ax = dev.cfg["axes"][str(sy["axis"])]
                ax["out"] = "TRACK" if other == "track" else "LSX"
                dev.trackers.pop(sy["axis"], None)
        if ui.button("sync_cancel", pygame.Rect(r.right - 32 - 160, by, 160, 42), "Cancelar"):
            self.sync = None

    def detect_pedals(self, dev):
        """3 pasos seguidos: acelerador, freno, embrague. Nunca asigna el mismo eje dos veces."""
        axes = dev.cfg["axes"]
        for k, a in axes.items():
            if a["mode"] == "pedal":
                axes[k] = core.default_axis()
        self.start_wizard(dev, "throttle", "Pisa el ACELERADOR a fondo y mantenlo")
        self.wiz["chain"] = [("brake", "Ahora pisa el FRENO a fondo y mantenlo"),
                             ("clutch", "Pisa el EMBRAGUE a fondo (si no tienes, espera)")]
        self.wiz["used"] = dev.axes_with("steer")
        self.wiz["step"] = "Paso 1 de 3"

    def easy_mouse(self, dev, quiet=False):
        """Asistente en 3 pasos: detecta X, Y y la palanca de velocidad moviéndolos."""
        for k in dev.cfg["axes"]:
            dev.cfg["axes"][k] = core.default_axis()
        dev.servos.clear()
        self.g["mouse_enabled"] = True
        self.g["mouse_invert_y"] = False
        self.follower.reset()
        role, text = self.EASY_STEPS[0]
        self.start_wizard(dev, role, text)
        self.wiz["chain"] = [r for r in self.EASY_STEPS[1:]]
        self.wiz["used"] = []
        self.wiz["step"] = "Paso 1 de 3"

    # ---------------------------------------------------------- updates
    def scan_updates(self):
        try:
            self.upd_found = [(v, p) for v, p in system.find_update_zips() if system.newer(v, VERSION)]
        except Exception:
            self.upd_found = []

    def install_update(self, path):
        self.kb.release_all()
        self.pad.neutral()
        try:
            v = system.zip_version(path)
            if not v:
                self.upd_msg = "Ese archivo no es un RoSim.zip válido."
                return
            system.install_zip(path)
            self.upd_done = True
            self.upd_msg = "Versión %s instalada. Reinicia RoSim para usarla." % v
            self.toast("Actualización instalada (OK)")
        except Exception as e:
            self.upd_msg = "No se pudo actualizar: %s" % e

    def _bg_check(self):
        url = self.g.get("update_url", "")
        if not url:
            return
        try:
            info = system.check_online(url)
            if system.newer(str(info.get("version", "")), VERSION) and info.get("zip"):
                self.online = info
        except Exception:
            pass
        self.online_checked = True

    def check_online(self):
        url = self.g.get("update_url", "")
        if not url:
            self.upd_msg = "No hay dirección de actualizaciones configurada."
            return
        try:
            info = system.check_online(url)
            v = str(info.get("version", ""))
            if v and system.newer(v, VERSION) and info.get("zip"):
                self.online = info
                self.upd_msg = ""
            else:
                self.online = None
                self.upd_msg = "Ya tienes la última versión (%s)." % VERSION
        except Exception as e:
            self.upd_msg = "No se pudo conectar con la web de RoSim: %s" % e

    def install_online(self):
        info = self.online
        self.upd_msg = "Descargando la versión %s…" % info["version"]
        self.ui.begin([])
        self.draw()
        try:
            path = system.download(info["zip"])
        except Exception as e:
            self.upd_msg = "No se pudo descargar: %s" % e
            return
        self.install_update(path)
        if self.upd_done:
            self.online = None
            self.restart_after = True     # se reinicia sola con la versión nueva
            self.quit_now = True

    def camera_follow(self, keys, dt):
        """Gira la cámara del juego moviendo el ratón según el volante (opcional)."""
        if self.cam_req is None:
            target, ax = 0.0, None
            if abs(self.cam_sent) < 0.5:
                self.cam_sent = 0.0
                return
        else:
            target, ax = self.cam_req
        sm = core.clamp(float(ax["cam_smooth"]) if ax else 0.3, 0.0, 0.95)
        k = 1.0 - (sm ** (dt * 60.0)) if sm > 0 else 1.0
        want = self.cam_sent + (target - self.cam_sent) * k
        dx = int(round(want - self.cam_sent))
        if dx:
            if ax is not None and ax.get("cam_rmb"):
                keys.add("MOUSE2")
                self.cam_rmb_until = time.time() + 0.25
            winio.mouse_move_rel(dx, 0)
            self.cam_sent += dx
        elif time.time() < self.cam_rmb_until and ax is not None and ax.get("cam_rmb"):
            keys.add("MOUSE2")

    def resync_all(self):
        now = time.time()
        for dev in self.devices.values():
            for i in dev.axes_with("servo"):
                ax = dev.cfg["axes"][str(i)]
                dev.servos.setdefault(i, core.Servo()).resync(now, ax["full_time"])
        self.toast("Resincronizando: bajando gases del juego a ralentí…")

    def set_mouse_center_here(self):
        x, y = winio.cursor_pos()
        sw, sh = winio.screen_size()
        self.g["mouse_cx"] = core.clamp(x / sw, 0, 1)
        self.g["mouse_cy"] = core.clamp(y / sh, 0, 1)
        self.follower.reset()
        self.toast("Centro del ratón fijado en (%d, %d)" % (x, y))

    def output(self, keys, st, uses_pad, mouse, dt):
        g = self.g
        self.allowed = g["output_on"] and (not g["only_roblox"] or self.roblox_fg)
        if self.ui.capture or self.cal:   # no mandar nada mientras asignas una tecla o calibras
            self.allowed = False
        if not self.allowed:
            self.kb.release_all()
            self.pad.neutral()
            self.follower.reset()
            self.cam_sent = 0.0        # el juego no ha recibido nada mientras no estaba delante
            return
        self.camera_follow(keys, dt)
        self.kb.sync(keys)
        if uses_pad:
            self.pad.send(st)
        if g["mouse_enabled"] and mouse:
            sx = mouse.get("mouse_x", 0.0)
            sy = mouse.get("mouse_y", 0.0)
            if g["mouse_invert_y"]:
                sy = -sy
            sx = core.shape_signed(sx, g["mouse_deadzone"], g["mouse_gamma"])
            sy = core.shape_signed(sy, g["mouse_deadzone"], g["mouse_gamma"])
            if g["mouse_mode"] == "abs":
                sw, sh = winio.screen_size()
                p = self.follower.update(sx, sy, g, sw, sh, dt)
                if p:
                    winio.mouse_move_abs(*p)
            else:
                self.rel_acc[0] += sx * g["mouse_speed"] * dt
                self.rel_acc[1] += sy * g["mouse_speed"] * dt
                dx, dy = int(self.rel_acc[0]), int(self.rel_acc[1])
                if dx or dy:
                    self.rel_acc[0] -= dx
                    self.rel_acc[1] -= dy
                    winio.mouse_move_rel(dx, dy)

    def update_ffb(self, now):
        rumble = self.pad.rumble
        if now < self.test_rumble_until:
            rumble = 1.0
        for dev in self.devices.values():
            if dev.ffb:
                cfg = dict(dev.cfg["ffb"])
                if not dev.cfg["enabled"] or self.gcal or self.cal:
                    cfg["enabled"] = False      # sin muelle: tu volante se queda donde lo dejas
                dev.ffb.apply(cfg, rumble)

    # ---------------------------------------------------------- wizard
    def start_wizard(self, dev, role, text, axis=None):
        dev.read()
        self.wiz = {"dev": dev.iid, "role": role, "text": text, "axis": axis,
                    "t0": time.time(), "dur": 3.5 if role != "cal" else 5.0,
                    "snap": list(dev.axes), "ext": list(dev.axes),
                    "mn": list(dev.axes), "mx": list(dev.axes)}

    def run_wizard(self):
        w = self.wiz
        dev = self.devices.get(w["dev"])
        if not dev:
            self.wiz = None
            return
        for i, v in enumerate(dev.axes):
            if abs(v - w["snap"][i]) > abs(w["ext"][i] - w["snap"][i]):
                w["ext"][i] = v
            w["mn"][i] = min(w["mn"][i], v)
            w["mx"][i] = max(w["mx"][i], v)
        if time.time() - w["t0"] < w["dur"]:
            return
        self.wiz = None
        axes = dev.cfg["axes"]
        role = w["role"]

        if role == "cal":
            i = w["axis"]
            ax = axes[str(i)]
            if w["mx"][i] - w["mn"][i] < 0.2:
                self.toast("No se movió el eje %d. Prueba otra vez." % i)
                return
            if ax["mode"] == "servo":
                ax["lo"], ax["hi"] = w["snap"][i], w["ext"][i]
            else:
                ax["lo"], ax["hi"] = w["snap"][i], w["ext"][i]
            self.toast("Eje %d calibrado (OK)" % i)
            return

        excl = set(dev.axes_with("steer")) if role in ("throttle", "brake", "clutch") else set()
        excl |= set(w.get("used", []))
        chain = w.get("chain")
        best, bestd = None, 0.0
        for i in range(dev.n_axes):
            if i in excl:
                continue
            d = abs(w["ext"][i] - w["snap"][i])
            if d > bestd:
                best, bestd = i, d
        if best is None or bestd < 0.25:
            if role == "clutch" and chain is not None:     # sin embrague: listo igualmente
                self.toast("Pedales listos (OK). Acelerador y freno asignados.", 5)
                return
            if role == "speed":   # el stick no tiene palanca de velocidad: no pasa nada
                self.toast("Listo (OK). Mueve el stick: el cursor lo sigue dentro de Roblox.", 5)
                return
            self.toast("No detecté movimiento. Pulsa otra vez y mueve el stick más.", 5)
            return
        snap, ext = w["snap"][best], w["ext"][best]
        positive = ext > snap
        old = axes[str(best)]

        def clear(pred):
            for k, a in axes.items():
                if k != str(best) and pred(a):
                    axes[k] = core.default_axis()

        rng = dev.info.get("range", 900)
        if role == "steer":
            clear(lambda a: a["mode"] == "steer")
            na = core.make_axis("steer", out=old.get("out") if old["mode"] == "steer" else "LSX",
                                hw_range=old.get("hw_range", rng) if old["mode"] == "steer" else rng,
                                game_range=old.get("game_range", min(rng, 540)) if old["mode"] == "steer" else min(rng, 540),
                                antidz=old.get("antidz", 0.2) if old["mode"] == "steer" else 0.2,
                                key_neg="A", key_pos="D", invert=not positive)
        elif role in ("throttle", "brake", "clutch"):
            out = {"throttle": "RT", "brake": "LT", "clutch": "NONE"}[role]
            key = {"throttle": "W", "brake": "S", "clutch": ""}[role]
            if out != "NONE":
                clear(lambda a: a["mode"] == "pedal" and a["out"] == out)
            na = core.make_axis("pedal", out=out, key=key, lo=snap, hi=ext)
        elif role == "x":
            clear(lambda a: a["mode"] == "mouse_x")
            na = core.make_axis("mouse_x", invert=not positive)
        elif role == "y":
            clear(lambda a: a["mode"] == "mouse_y")
            na = core.make_axis("mouse_y", invert=positive)  # delante debe dar negativo
        elif role == "twist":
            na = core.make_axis("keys", invert=not positive, deadzone=0.08, pwm=True)
        elif role == "speed":
            na = core.make_axis("servo", key_pos="W", key_neg="S", lo=snap, hi=ext)
        elif role in ("lever", "lever2"):
            k_up, k_dn = ("W", "S") if role == "lever" else ("", "")
            na = core.make_axis("servo", key_pos=k_up, key_neg=k_dn, lo=snap, hi=ext)
        else:
            return
        axes[str(best)] = na
        dev.servos.pop(best, None)
        if chain is not None:
            used = w.get("used", []) + [best]
            if chain:
                (nrole, ntext), rest = chain[0], chain[1:]
                self.start_wizard(dev, nrole, ntext)
                self.wiz.update(chain=rest, used=used, step="Paso %d de 3" % (4 - len(chain)))
                self.toast("Eje %d detectado (OK)" % best)
            elif role == "clutch":
                self.toast("Pedales listos (OK). Pisa el acelerador: la barra verde debe subir.", 6)
            else:
                self.toast("Listo (OK). Mueve el stick: el cursor lo sigue dentro de Roblox.", 5)
            return
        self.toast("Asignado: eje %d → %s (OK)" % (best, dict((r[0], r[1]) for rr in ROLES.values() for r in rr).get(role, role)))

    # ============================================================ DRAW
    def draw(self):
        ui = self.ui
        self.screen.fill(BG)
        self.draw_header()
        self.draw_sidebar()
        area = pygame.Rect(262, 76, W - 274, H - 88)
        dev = self.devices.get(self.sel)
        if self.view == "settings":
            self.draw_settings(area)
        elif self.view == "help":
            self.draw_help(area)
        elif self.view == "update":
            self.draw_update(area)
        elif self.cal and self.devices.get(self.cal["dev"]):
            self.draw_cal(area)
        elif self.gcal and self.devices.get(self.gcal["dev"]):
            self.draw_gcal(area)
        elif not dev:
            self.draw_empty(area)
        else:
            self.draw_device(dev, area)
        if self.wiz:
            self.draw_wizard()
        if self.sync:
            self.draw_sync()
        if time.time() < self.toast_until:
            w = ui.text_w(self.toast_msg, 15) + 36
            r = pygame.Rect(0, 0, w, 38)
            r.midbottom = (262 + (W - 262) // 2, H - 14)
            ui.panel(r, (38, 42, 54), 10, ACCENT)
            ui.text(self.toast_msg, r.center, 15, TEXT, anchor="center")
        pygame.display.flip()

    def pill(self, x, y, label, color):
        ui = self.ui
        w = ui.text_w(label, 13) + 30
        r = pygame.Rect(x - w, y, w, 28)
        ui.rect(r, PANEL2, 14)
        pygame.draw.circle(self.screen, color, (r.x + 13, r.centery), 5)
        ui.text(label, (r.x + 23, r.centery), 13, TEXT, anchor="midleft")
        return r.x - 8

    def draw_header(self):
        ui = self.ui
        lx = 16
        if self.logo:
            self.screen.blit(self.logo, (16, 11))
            lx = 70
        ui.text("Ro", (lx, 10), 28, ACCENT, True)
        ui.text("Sim", (lx + ui.text_w("Ro", 28, True), 10), 28, TEXT, True)
        ui.text("CONTROL HUB · ROBLOX · v" + VERSION, (lx + 2, 44), 11, MUTED)
        g = self.g
        # interruptor principal
        r = pygame.Rect(W - 200, 16, 186, 40)
        on = g["output_on"]
        if ui.button("master", r, "SALIDA ACTIVA" if on else "SALIDA PAUSADA",
                     color=(ACCENT if on else PANEL2), bold=True):
            g["output_on"] = not on
        x = W - 212
        if self.online:
            lab = "Nueva versión %s · ACTUALIZAR" % self.online["version"]
            bw = ui.text_w(lab, 13, True) + 28
            br = pygame.Rect(x - bw, 20, bw, 32)
            if ui.button("hdr_upd", br, lab, color=GOOD, fg=BG, size=13, bold=True):
                self.view = "update"
            x = br.x - 8
        if g["only_roblox"]:
            x = self.pill(x, 22, "Roblox delante" if self.roblox_fg else "Esperando a Roblox",
                          GOOD if self.roblox_fg else WARN)
        if self.pad.pad is not None:
            x = self.pill(x, 22, "Mando virtual OK", GOOD)
        elif self.pad.available:
            x = self.pill(x, 22, "Mando virtual en espera", MUTED)
        else:
            x = self.pill(x, 22, "Sin ViGEmBus (solo teclas/ratón)", BAD)
        if any(self.devices[i].axes_with("mouse_x") or self.devices[i].axes_with("mouse_y")
               for i in self.order if self.devices[i].cfg["enabled"]):
            x = self.pill(x, 22, "Ratón ON" if g["mouse_enabled"] else "Ratón OFF",
                          ACCENT2 if g["mouse_enabled"] else MUTED)
        pygame.draw.line(self.screen, LINE, (0, 66), (W, 66))

    def type_color(self, t):
        return {"wheel": ACCENT, "stick": ACCENT2, "throttle": (180, 120, 255),
                "gamepad": MUTED}.get(t, (200, 200, 120))

    def draw_sidebar(self):
        ui = self.ui
        y = 78
        ui.text("DISPOSITIVOS", (16, y), 12, MUTED, True)
        y += 22
        if not self.order:
            ui.text("Conecta un volante,", (16, y), 14, DIM)
            ui.text("joystick o palanca…", (16, y + 20), 14, DIM)
        for iid in self.order:
            dev = self.devices[iid]
            r = pygame.Rect(10, y, 240, 66)
            sel = (iid == self.sel and self.view == "device")
            hov = ui.hit(r)
            ui.rect(r, PANEL2 if sel else (PANEL if hov else BG), 10)
            if sel:
                pygame.draw.rect(self.screen, self.type_color(dev.type),
                                 pygame.Rect(10, y + 10, 4, 46), border_radius=2)
            col = self.type_color(dev.type)
            pygame.draw.circle(self.screen, col, (34, y + 24), 10, 3)
            ui.text(ui.fit(dev.info["model"], 168, 15, True), (54, y + 10), 15,
                    TEXT if dev.cfg["enabled"] else DIM, True)
            sub = TYPE_LABELS.get(dev.type, "")
            if dev.ffb:
                sub += " · FFB"
            ui.text(sub, (54, y + 32), 12, col if dev.cfg["enabled"] else DIM)
            ui.text("%d ejes · %d botones" % (dev.n_axes, dev.n_buttons), (54, y + 47), 11, DIM)
            # activar / desactivar
            tr = pygame.Rect(196, y + 38, 50, 24)
            new = ui.toggle("en%d" % iid, tr, dev.cfg["enabled"], None, col)
            if new != dev.cfg["enabled"]:
                dev.cfg["enabled"] = new
            elif hov and ui.clicked and not ui.hit(tr):
                self.sel = iid
                self.view = "device"
            y += 72
            if y > H - 236:
                break
        by = H - 168
        if ui.button("rescan", pygame.Rect(10, by, 240, 34), "Buscar dispositivos"):
            self.rescan()
        newv = (self.online or {}).get("version") or (self.upd_found[0][0] if self.upd_found else None)
        lab = "Actualizar · nueva v%s" % newv if newv else "Actualizar y acceso directo"
        col = ACCENT if newv else PANEL2
        if self.view == "update":
            col = (60, 44, 40)
        if ui.button("update", pygame.Rect(10, by + 120, 240, 34), lab, color=col, bold=bool(newv)):
            self.view = "update"
            self.scan_updates()
        if ui.button("settings", pygame.Rect(10, by + 40, 240, 34), "Ajustes y ratón",
                     color=(PANEL2 if self.view != "settings" else (60, 44, 40))):
            self.view = "settings"
        if ui.button("help", pygame.Rect(10, by + 80, 240, 34), "Ayuda",
                     color=(PANEL2 if self.view != "help" else (60, 44, 40))):
            self.view = "help"
        pygame.draw.line(self.screen, LINE, (258, 66), (258, H))

    def draw_empty(self, area):
        ui = self.ui
        ui.panel(area)
        ui.text("No hay dispositivos", (area.centerx, area.centery - 30), 28, TEXT, True, "center")
        ui.text("Conecta tu volante, sidestick o palanca de gases por USB.", (area.centerx, area.centery + 10),
                16, MUTED, anchor="center")
        ui.text("Se detectan solos (también si los conectas con RoSim abierto).",
                (area.centerx, area.centery + 34), 16, MUTED, anchor="center")

    # ------------------------------------------------------------ device
    def draw_device(self, dev, area):
        ui = self.ui
        tabs = [("live", "En vivo"), ("axes", "Ejes"), ("buttons", "Botones y teclas")]
        if dev.type == "wheel":
            tabs.append(("calibs", "Calibraciones"))
        if dev.ffb:
            tabs.append(("ffb", "Force Feedback"))
        if self.tab not in [t[0] for t in tabs]:
            self.tab = "live"
        x = area.x
        for tid, label in tabs:
            w = ui.text_w(label, 15, True) + 34
            if ui.tab("tab" + tid, pygame.Rect(x, area.y, w, 36), label, self.tab == tid):
                self.tab = tid
                ui.capture = None
            x += w + 6
        # tipo de dispositivo (por si la autodetección falla)
        r = pygame.Rect(area.right - 270, area.y + 2, 270, 32)
        types = [(t, "Tipo: " + l) for t, l in TYPE_LABELS.items()]
        nt = ui.cycle("dtype", r, types, dev.type)
        if nt != dev.type:
            dev.cfg["type"] = nt
        content = pygame.Rect(area.x, area.y + 46, area.w, area.h - 46)
        if not dev.cfg["enabled"]:
            ui.text("Este dispositivo está DESACTIVADO (actívalo en la lista de la izquierda).",
                    (content.x, content.bottom - 18), 14, WARN)
            content.h -= 26
        if self.tab == "live":
            self.draw_live(dev, content)
        elif self.tab == "axes":
            self.draw_axes(dev, content)
        elif self.tab == "buttons":
            self.draw_buttons(dev, content)
        elif self.tab == "ffb":
            self.draw_ffb(dev, content)
        elif self.tab == "calibs":
            self.draw_calibs(dev, content)

    # ------------------------------------------------------------ live
    def draw_live(self, dev, c):
        t = dev.type
        right = pygame.Rect(c.right - 300, c.y, 300, c.h)
        main = pygame.Rect(c.x, c.y, c.w - 312, c.h)
        if t == "wheel":
            self.live_wheel(dev, main)
        elif t == "stick":
            self.live_stick(dev, main)
        elif t == "throttle":
            self.live_throttle(dev, main)
        else:
            self.live_generic(dev, main)
        self.live_side(dev, right)

    def live_wheel(self, dev, r):
        ui = self.ui
        a = pygame.Rect(r.x, r.y, 410, r.h)
        b = pygame.Rect(r.x + 422, r.y, r.w - 422, r.h)
        ui.panel(a)
        ui.panel(b)
        steer = dev.axes_with("steer")
        cx, cy, rad = a.centerx, a.y + 175, 132
        deg = out = plain = 0.0
        ax = None
        if steer:
            i = steer[0]
            ax = dev.cfg["axes"][str(i)]
            lv = dev.live.get(i, {})
            deg, plain, out = lv.get("deg", 0.0), lv.get("plain", 0.0), lv.get("out", 0.0)
        # volante
        ang = math.radians(deg)
        scr = self.screen
        pygame.draw.circle(scr, (34, 37, 46), (cx, cy), rad + 10)
        pygame.draw.circle(scr, (58, 62, 76), (cx, cy), rad, 20)

        def rot(px, py):
            ca, sa = math.cos(ang), math.sin(ang)
            return (cx + px * ca - py * sa, cy + px * sa + py * ca)
        for sx, sy in ((-rad + 12, 6), (rad - 12, 6), (0, rad - 12)):
            pygame.draw.line(scr, (72, 77, 94), rot(0, 6), rot(sx, sy), 16)
        pygame.draw.circle(scr, (30, 32, 40), (cx, cy), 34)
        pygame.draw.circle(scr, ACCENT, (int(rot(0, 6)[0]), int(rot(0, 6)[1])), 12, 3)
        pygame.draw.polygon(scr, ACCENT, [rot(-7, -rad - 10), rot(7, -rad - 10), rot(7, -rad + 10), rot(-7, -rad + 10)])
        if not steer:
            ui.text("Sin eje de dirección asignado", (cx, cy + rad + 30), 15, WARN, anchor="center")
            ui.text("Usa el Asistente → «Dirección»", (cx, cy + rad + 52), 14, MUTED, anchor="center")
            return
        y = cy + rad + 22
        ui.text("%+.1f°" % deg, (cx, y), 46, TEXT, True, "midtop")
        gl = ax.get("game_lock") if ax.get("map_full") else ax["game_range"]
        ui.text("Tu volante: %d°  ·  volante del juego: %s" % (ax["hw_range"], ("%d°" % gl) if gl else "sin ajustar"),
                (cx, y + 58), 13, MUTED, anchor="midtop")
        br = pygame.Rect(a.x + 24, y + 86, a.w - 48, 12)
        ui.bar_h(br, out, ACCENT, signed=True)
        ui.bar_h(pygame.Rect(br.x, br.bottom + 6, br.w, 6), plain, DIM, signed=True)
        if ax.get("map_full") and ax.get("game_lock"):
            ui.text("1:1 con el juego · se para en tu tope", (cx, br.bottom + 44), 13, GOOD, True, "midtop")
        elif ax.get("map_full"):
            ui.text("Falta: AJUSTAR GRADOS CON EL JUEGO", (cx, br.bottom + 44), 13, WARN, True, "midtop")
        elif ax.get("table"):
            ui.text("Calibrado con el juego (1:1)", (cx, br.bottom + 44), 13, GOOD, True, "midtop")
        else:
            ui.text("Sin calibrar → pulsa CALIBRAR VOLANTE", (cx, br.bottom + 44), 13, WARN, True, "midtop")
        if ax["out"] == "TRACK":
            ge = dev.live.get(i, {}).get("game_est", 0.0)
            ui.text("Volante del juego ≈ %+.0f°  (seguimiento)" % ge, (br.x, br.bottom + 18), 14, TEXT, True)
        else:
            ui.text("Salida a Roblox: %+d%%" % round(out * 100), (br.x, br.bottom + 18), 14, TEXT, True)
        ui.text("anti-zona muerta %d%%" % round(ax["antidz"] * 100), (br.right, br.bottom + 18), 13, MUTED,
                anchor="topright")

        # pedales
        ui.text("PEDALES", (b.x + 18, b.y + 14), 12, MUTED, True)
        peds = dev.axes_with("pedal")
        loose = [i for i in range(dev.n_axes) if dev.cfg["axes"][str(i)]["mode"] == "none"
                 and abs(dev.axes[i] - dev.rest.get(i, dev.axes[i])) > 0.3]
        if loose:
            ui.text("El eje %d se mueve pero no está asignado → «Detectar pedales»" % loose[0],
                    (b.x + 18, b.bottom - 24), 13, WARN)
        if not any(dev.cfg["axes"][str(i)]["out"] == "RT" for i in peds):
            ui.text("Sin acelerador", (b.right - 18, b.y + 14), 12, BAD, True, "topright")
        if not peds:
            ui.text("Sin pedales asignados.", (b.x + 18, b.y + 44), 15, WARN)
            ui.text("Pulsa «Detectar pedales (3 pasos)».", (b.x + 18, b.y + 66), 14, MUTED)
            return
        names = {"RT": ("Acelerador", GOOD), "LT": ("Freno", BAD), "NONE": ("Embrague", ACCENT2),
                 "KEY": ("Pedal (tecla)", WARN), "LSY+": ("Pedal ↑", GOOD), "LSY-": ("Pedal ↓", BAD)}
        n = len(peds)
        bw = min(70, (b.w - 36 - (n - 1) * 18) // max(1, n))
        x = b.x + 18 + max(0, (b.w - 36 - n * bw - (n - 1) * 18) // 2)
        for i in peds:
            p = dev.cfg["axes"][str(i)]
            lv = dev.live.get(i, {})
            nm, col = names.get(p["out"], ("Pedal", TEXT))
            bar = pygame.Rect(x, b.y + 70, bw, b.h - 170)
            ui.bar_v(bar, lv.get("out", 0.0), col)
            raw_h = int(lv.get("v", 0.0) * bar.h)
            pygame.draw.line(self.screen, TEXT, (bar.x - 4, bar.bottom - raw_h), (bar.x, bar.bottom - raw_h), 2)
            ui.text("%d%%" % round(lv.get("out", 0.0) * 100), (bar.centerx, b.y + 42), 22, TEXT, True, "midtop")
            ui.text(nm, (bar.centerx, bar.bottom + 12), 14, col, True, "midtop")
            ui.text("eje %d" % i, (bar.centerx, bar.bottom + 32), 12, DIM, anchor="midtop")
            if p["out"] == "KEY" and p["key"]:
                ui.text(winio.pretty(p["key"]), (bar.centerx, bar.bottom + 48), 12, WARN, anchor="midtop")
            x += bw + 18

    def live_stick(self, dev, r):
        ui = self.ui
        a = pygame.Rect(r.x, r.y, (r.w - 12) // 2, r.h)
        b = pygame.Rect(a.right + 12, r.y, r.w - a.w - 12, r.h)
        ui.panel(a)
        ui.panel(b)
        ui.text("SIDESTICK", (a.x + 18, a.y + 14), 12, MUTED, True)
        mx, my = dev.axes_with("mouse_x"), dev.axes_with("mouse_y")
        sx = dev.live.get(mx[0], {}).get("out", 0.0) if mx else (dev.axes[0] if dev.n_axes > 0 else 0)
        sy = dev.live.get(my[0], {}).get("out", 0.0) if my else (dev.axes[1] if dev.n_axes > 1 else 0)
        size = min(a.w - 60, a.h - 120 - 26 * min(dev.n_axes, 6))
        sq = pygame.Rect(0, 0, size, size)
        sq.center = (a.centerx, a.y + 40 + size // 2)
        ui.rect(sq, PANEL2, 12)
        pygame.draw.line(self.screen, LINE, (sq.centerx, sq.y + 8), (sq.centerx, sq.bottom - 8))
        pygame.draw.line(self.screen, LINE, (sq.x + 8, sq.centery), (sq.right - 8, sq.centery))
        pygame.draw.circle(self.screen, LINE, sq.center, size // 2 - 8, 1)
        px = sq.centerx + sx * (size / 2 - 14)
        py = sq.centery + sy * (size / 2 - 14)
        pygame.draw.circle(self.screen, ACCENT2, (int(px), int(py)), 13)
        pygame.draw.circle(self.screen, TEXT, (int(px), int(py)), 13, 2)
        ui.text("X %+.0f%%   Y %+.0f%%" % (sx * 100, sy * 100), (a.centerx, sq.bottom + 12), 18, TEXT, True, "midtop")
        # ejes en crudo: así se ve qué eje se mueve de verdad
        y = sq.bottom + 44
        names = {"mouse_x": "Ratón X", "mouse_y": "Ratón Y", "servo": "Velocidad (W/S)", "keys": "Teclas",
                 "none": "Sin asignar", "stick": "Mando", "pedal": "Pedal", "steer": "Dirección"}
        for i in range(min(dev.n_axes, 6)):
            m = dev.cfg["axes"][str(i)]["mode"]
            col = ACCENT2 if m in ("mouse_x", "mouse_y") else (180, 120, 255) if m == "servo" else DIM
            ui.text("Eje %d" % i, (a.x + 20, y), 13, MUTED)
            ui.bar_h(pygame.Rect(a.x + 70, y + 4, a.w - 230, 9), dev.axes[i], col, True)
            ui.text(names.get(m, m), (a.right - 20, y), 13, col if m != "none" else DIM, anchor="topright")
            y += 26
        # pantalla con el cursor
        g = self.g
        ui.text("CURSOR EN EL JUEGO", (b.x + 18, b.y + 14), 12, MUTED, True)
        stxt, scol = self.mouse_status(dev)
        ui.text(ui.fit(stxt, b.w - 40, 13, True), (b.right - 18, b.y + 14), 13, scol, True, "topright")
        sw, sh = winio.screen_size()
        scw = b.w - 40
        sch = int(scw * sh / max(1, sw))
        scr = pygame.Rect(b.x + 20, b.y + 44, scw, sch)
        ui.rect(scr, (10, 11, 14), 6)
        ui.rect(scr, LINE, 6, 1)
        ccx = scr.x + g["mouse_cx"] * scw
        ccy = scr.y + g["mouse_cy"] * sch
        er = pygame.Rect(0, 0, 2 * g["mouse_rx"] * scw, 2 * g["mouse_ry"] * sch)
        er.center = (int(ccx), int(ccy))
        pygame.draw.ellipse(self.screen, (40, 70, 86), er, 1)
        pygame.draw.line(self.screen, DIM, (ccx - 6, ccy), (ccx + 6, ccy))
        pygame.draw.line(self.screen, DIM, (ccx, ccy - 6), (ccx, ccy + 6))
        ssy = -sy if g["mouse_invert_y"] else sy
        tx = ccx + core.clamp(sx, -1, 1) * g["mouse_rx"] * scw
        ty = ccy + core.clamp(ssy, -1, 1) * g["mouse_ry"] * sch
        pygame.draw.circle(self.screen, ACCENT2 if g["mouse_enabled"] else DIM, (int(tx), int(ty)), 6)
        y = scr.bottom + 16
        mode = "El ratón SIGUE al stick (absoluto)" if g["mouse_mode"] == "abs" else "Modo velocidad (relativo)"
        ui.text(mode, (b.x + 20, y), 14, TEXT, True)
        ui.text("Stick en neutro = cursor en el centro → el avión va recto.", (b.x + 20, y + 22), 13, MUTED)
        y += 52
        r1 = pygame.Rect(b.x + 20, y, b.w - 40, 30)
        g["mouse_enabled"] = ui.toggle("m_en_live", r1, g["mouse_enabled"], "Controlar el ratón con el stick", ACCENT2)
        y += 38
        g["mouse_invert_y"] = ui.toggle("m_inv_live", pygame.Rect(b.x + 20, y, b.w - 40, 30),
                                        g["mouse_invert_y"], "Estilo avión (tirar = morro arriba)", ACCENT2)
        y += 44
        if ui.button("m_more", pygame.Rect(b.x + 20, y, b.w - 40, 32), "Más ajustes del ratón (radio, centro…)"):
            self.view = "settings"

    def mouse_status(self, dev):
        g = self.g
        if not (dev.axes_with("mouse_x") or dev.axes_with("mouse_y")):
            return "Sin ejes → pulsa RATÓN FÁCIL", BAD
        if not dev.cfg["enabled"]:
            return "Dispositivo desactivado", WARN
        if not g["mouse_enabled"]:
            return "Ratón OFF", WARN
        if not g["output_on"]:
            return "Salida pausada", WARN
        if g["only_roblox"] and not self.roblox_fg:
            return "Solo se mueve con Roblox delante", WARN
        return "Moviendo el cursor", GOOD

    def live_throttle(self, dev, r):
        ui = self.ui
        ui.panel(r)
        ui.text("PALANCAS", (r.x + 18, r.y + 14), 12, MUTED, True)
        servos = dev.axes_with("servo")
        others = [i for i in range(dev.n_axes) if i not in servos]
        x = r.x + 30
        bh = r.h - 150
        for i in servos:
            ax = dev.cfg["axes"][str(i)]
            lv = dev.live.get(i, {})
            lev = pygame.Rect(x, r.y + 70, 54, bh)
            est = pygame.Rect(x + 64, r.y + 70, 22, bh)
            ui.bar_v(lev, lv.get("v", 0.0), (180, 120, 255))
            ui.bar_v(est, lv.get("est", 0.0), DIM)
            ui.text("%d%%" % round(lv.get("v", 0) * 100), (lev.centerx, r.y + 40), 22, TEXT, True, "midtop")
            ui.text("juego≈%d%%" % round(lv.get("est", 0) * 100), (est.centerx + 4, lev.bottom + 10), 12, MUTED, anchor="midtop")
            d = lv.get("dir", 0)
            k = ax["key_pos"] if d > 0 else ax["key_neg"] if d < 0 else ""
            txt = ("▲ " if d > 0 else "▼ " if d < 0 else "● ") + (winio.pretty(k) if k else "")
            ui.text(txt, (lev.centerx, lev.bottom + 28), 15, GOOD if d else DIM, True, "midtop")
            ui.text("eje %d" % i, (lev.centerx, lev.bottom + 50), 12, DIM, anchor="midtop")
            x += 130
        if not servos:
            ui.text("Sin palanca de gases asignada → Asistente «Palanca de gases».", (r.x + 18, r.y + 44), 15, WARN)
        # resto de ejes
        ox = max(x + 20, r.x + 300)
        ui.text("OTROS EJES", (ox, r.y + 14), 12, MUTED, True)
        y = r.y + 44
        for i in others[:10]:
            ui.text("Eje %d" % i, (ox, y), 13, MUTED)
            ui.bar_h(pygame.Rect(ox + 56, y + 4, r.right - ox - 76, 10), dev.axes[i], (180, 120, 255), True)
            y += 28
        ui.text("La palanca no mueve el gas directamente: RoSim pulsa ▲/▼ hasta que el gas del juego",
                (r.x + 18, r.bottom - 46), 13, MUTED)
        ui.text("coincide con tu palanca. Si se desincroniza, lleva la palanca a ralentí o pulsa Resincronizar.",
                (r.x + 18, r.bottom - 26), 13, MUTED)

    def live_generic(self, dev, r):
        ui = self.ui
        ui.panel(r)
        ui.text("EJES", (r.x + 18, r.y + 14), 12, MUTED, True)
        y = r.y + 42
        for i in range(dev.n_axes):
            ax = dev.cfg["axes"][str(i)]
            ui.text("Eje %d" % i, (r.x + 18, y), 14, TEXT)
            ui.bar_h(pygame.Rect(r.x + 80, y + 4, r.w - 300, 10), dev.axes[i], ACCENT, True)
            ui.text(dict(MODE_OPTS)[ax["mode"]], (r.right - 18, y), 13, MUTED, anchor="topright")
            y += 30
            if y > r.bottom - 60:
                break
        if dev.type == "gamepad":
            ui.text("Ojo: el mando virtual de RoSim también aparece aquí como «Xbox 360 Controller».",
                    (r.x + 18, r.bottom - 46), 13, WARN)
            ui.text("Déjalo desactivado para no crear un bucle.", (r.x + 18, r.bottom - 26), 13, WARN)

    def live_side(self, dev, r):
        ui = self.ui
        ui.panel(r)
        y = r.y + 14
        roles = ROLES.get(dev.type, [])
        if roles:
            ui.text("ASISTENTE DE CONFIGURACIÓN", (r.x + 16, y), 12, MUTED, True)
            y += 24
            if dev.type == "wheel":
                if ui.button("wizsteer", pygame.Rect(r.x + 16, y, r.w - 32, 32), "Detectar dirección",
                             enabled=self.wiz is None):
                    self.start_wizard(dev, "steer", "Gira el volante a la DERECHA")
                y += 38
                if ui.button("wizpedals", pygame.Rect(r.x + 16, y, r.w - 32, 32), "Detectar pedales (3 pasos)",
                             enabled=self.wiz is None):
                    self.detect_pedals(dev)
                y += 38
            else:
                for role, label, instr in roles:
                    if ui.button("wiz" + role, pygame.Rect(r.x + 16, y, r.w - 32, 32), "Detectar " + label.lower(),
                                 enabled=self.wiz is None):
                        self.start_wizard(dev, role, instr)
                    y += 38
            if dev.type == "wheel":
                busy = self.wiz is not None or self.sync is not None or self.cal is not None or self.gcal is not None
                if ui.button("calbtn", pygame.Rect(r.x + 16, y, r.w - 32, 40), "CALIBRAR VOLANTE",
                             color=ACCENT, bold=True, enabled=not busy):
                    self.start_cal(dev)
                y += 46
                if ui.button("matchbtn", pygame.Rect(r.x + 16, y, r.w - 32, 34), "AJUSTAR GRADOS CON EL JUEGO",
                             color=(0, 92, 120), bold=True, enabled=not busy):
                    self.start_match(dev)
                y += 40
                if ui.button("calsaved", pygame.Rect(r.x + 16, y, r.w - 32, 32), "Calibraciones guardadas"):
                    self.tab = "calibs"
                y += 38


                if ui.button("centerbtn", pygame.Rect(r.x + 16, y, r.w - 32, 32), "Calibrar centro (volante recto)",
                             enabled=self.sync is None):
                    self.calibrate_center(dev)
                y += 38
            if dev.type == "stick":
                if ui.button("easy", pygame.Rect(r.x + 16, y, r.w - 32, 36), "RATÓN FÁCIL (3 pasos guiados)",
                             color=(0, 92, 120), bold=True, enabled=self.wiz is None):
                    self.easy_mouse(dev)
                y += 42
            if dev.type == "throttle":
                if ui.button("resync", pygame.Rect(r.x + 16, y, r.w - 32, 32), "Resincronizar gases",
                             color=(60, 44, 80)):
                    self.resync_all()
                y += 38
            y += 6
        ui.text("BOTONES (se iluminan al pulsar)", (r.x + 16, y), 12, MUTED, True)
        y += 22
        x = r.x + 16
        ids = dev.button_ids()
        col = self.type_color(dev.type)
        for bid in ids:
            if x + 30 > r.right - 10:
                x = r.x + 16
                y += 32
            if y > r.bottom - 30:
                break
            on = dev.pressed(bid)
            cr = pygame.Rect(x, y, 28, 28)
            ui.rect(cr, col if on else PANEL2, 14)
            lab = str(int(bid[1:]) + 1) if bid[0] == "b" else {"u": "↑", "d": "↓", "l": "←", "r": "→"}[bid[-1]]
            ui.text(lab, cr.center, 12, BG if on else MUTED, True, "center")
            x += 32
        if dev.ffb:
            y = r.bottom - 46
            f = dev.cfg["ffb"]
            f["enabled"] = ui.toggle("ffbq", pygame.Rect(r.x + 16, y, r.w - 32, 32), f["enabled"],
                                     "Force feedback", ACCENT)

    # ------------------------------------------------------------ axes tab
    def scroll_area(self, name, c):
        ui = self.ui
        if ui.hit(c) and ui.wheel and not ui.drag:
            self.scroll[name] -= ui.wheel * 60
        maxs = max(0, self.content_h.get(name, 0) - c.h)
        self.scroll[name] = int(core.clamp(self.scroll[name], 0, maxs))
        return self.scroll[name]

    def draw_axes(self, dev, c):
        ui = self.ui
        off = self.scroll_area("axes", c)
        ui.clip = c
        self.screen.set_clip(c)
        y = c.y - off
        for i in range(dev.n_axes):
            h = self.axis_card(dev, i, pygame.Rect(c.x, y, c.w - 14, 0))
            y += h + 10
        if dev.n_axes == 0:
            ui.text("Este dispositivo no tiene ejes.", (c.x + 10, c.y + 10), 15, MUTED)
        self.content_h["axes"] = y + off - c.y
        self.screen.set_clip(None)
        ui.clip = None
        self.draw_scrollbar("axes", c)

    def draw_scrollbar(self, name, c):
        total = self.content_h.get(name, 0)
        if total <= c.h:
            return
        h = max(30, int(c.h * c.h / total))
        y = c.y + int((c.h - h) * self.scroll[name] / max(1, total - c.h))
        self.ui.rect(pygame.Rect(c.right - 6, y, 5, h), LINE, 3)

    def axis_card(self, dev, i, r):
        ui = self.ui
        ax = dev.cfg["axes"][str(i)]
        m = ax["mode"]
        lv = dev.live.get(i, {})
        items = []
        dz_fmt = "{:.0%}"
        if m == "steer":
            items = [("cycle", "out", "Salida", STEER_OUT), ("toggle", "invert", "Invertir dirección"),
                     ("slider", "hw_range", "Grados reales del volante", 180, 2520, "{:.0f}°", 10),
                     ("slider", "game_range", "Tope del volante del juego (lado a lado)", 30, 3600, "{:.0f}°", 10),
                     ("sync",), ("ghub",), ("toggle", "lock_beep", "Pitido al llegar al tope del juego"),
                     ("center",), ("slider", "center_deg", "Margen en el centro", 0.0, 5.0, "{:.1f}°", 0.1),
                     ("toggle", "cam_follow", "Cámara sigue al volante (mueve el ratón)")]
            if ax.get("cam_follow"):
                items += [("slider", "cam_px", "Cámara: cuánto gira (píxeles de ratón)", 20, 2000, "{:.0f} px", 10),
                          ("slider", "cam_full_deg", "Cámara a tope cuando giras", 20, 900, "{:.0f}°", 5),
                          ("slider", "cam_curve", "Cámara: curva (>1 = poco al centro)", 0.5, 3.0, "{:.2f}", 0.05),
                          ("slider", "cam_smooth", "Cámara: suavizado", 0.0, 0.9, "{:.0%}", 0.01),
                          ("toggle", "cam_rmb", "Mantener clic derecho (cámara en 3ª persona)"),
                          ("toggle", "cam_invert", "Invertir cámara")]
            items += [
                     ("slider", "antidz", "Anti-zona muerta (quita la de Roblox)", 0, 0.6, dz_fmt, 0.01),
                     ("slider", "deadzone", "Zona muerta propia (centro)", 0, 0.3, dz_fmt, 0.005),
                     ("slider", "gamma", "Curva (1 = lineal, >1 más fino al centro)", 0.4, 3.0, "{:.2f}", 0.05)]
            if ax["out"] == "TRACK":
                items += [("slider", "t_full", "Juego: tiempo de centro a tope", 0.1, 5.0, "{:.2f} s", 0.05),
                          ("slider", "t_ret", "Juego: vuelta al centro (0 = no vuelve)", 0.0, 5.0, "{:.2f} s", 0.05),
                          ("slider", "track_tol", "Precisión del seguimiento", 0.01, 0.1, "{:.0%}", 0.005)]
            if ax["out"] == "KEYS":
                items += [("key", "key_neg", "Izquierda"), ("key", "key_pos", "Derecha"),
                          ("slider", "pwm_ms", "Periodo de pulsos", 40, 250, "{:.0f} ms", 5)]
        elif m == "pedal":
            items = [("cycle", "out", "Salida", PEDAL_OUT), ("cal",),
                     ("slider", "deadzone", "Zona muerta inicial", 0, 0.3, dz_fmt, 0.005),
                     ("slider", "sat", "Llega al 100% en", 0.5, 1.0, dz_fmt, 0.01),
                     ("slider", "gamma", "Curva", 0.4, 3.0, "{:.2f}", 0.05),
                     ("slider", "antidz", "Anti-zona muerta", 0, 0.5, dz_fmt, 0.01),
                     ("toggle", "invert", "Invertir pedal")]
            if ax["out"] == "KEY":
                items += [("key", "key", "Tecla"), ("toggle", "pwm", "Pulsos proporcionales (PWM)")]
                items += [("slider", "pwm_ms", "Periodo de pulsos", 40, 250, "{:.0f} ms", 5)] if ax["pwm"] else \
                         [("slider", "threshold", "Pulsar a partir de", 0.05, 0.95, dz_fmt, 0.01)]
        elif m == "stick":
            items = [("cycle", "out", "Salida", STICK_OUT), ("toggle", "invert", "Invertir"),
                     ("slider", "antidz", "Anti-zona muerta", 0, 0.6, dz_fmt, 0.01),
                     ("slider", "deadzone", "Zona muerta propia", 0, 0.3, dz_fmt, 0.005),
                     ("slider", "gamma", "Curva", 0.4, 3.0, "{:.2f}", 0.05)]
        elif m in ("mouse_x", "mouse_y"):
            items = [("toggle", "invert", "Invertir"),
                     ("slider", "deadzone", "Zona muerta", 0, 0.3, dz_fmt, 0.005),
                     ("slider", "gamma", "Curva", 0.4, 3.0, "{:.2f}", 0.05),
                     ("info", "Radio, centro y modo del ratón: Ajustes y ratón")]
        elif m == "servo":
            items = [("key", "key_pos", "Tecla SUBIR gas"), ("key", "key_neg", "Tecla BAJAR gas"),
                     ("slider", "full_time", "Tiempo de 0 a 100% en el juego", 0.5, 20, "{:.1f} s", 0.1),
                     ("slider", "tol", "Tolerancia", 0.005, 0.1, dz_fmt, 0.005),
                     ("cal",), ("toggle", "invert", "Invertir palanca"), ("resync",)]
        elif m == "keys":
            items = [("key", "key_neg", "Tecla lado −"), ("key", "key_pos", "Tecla lado +"),
                     ("toggle", "invert", "Invertir"), ("toggle", "pwm", "Pulsos proporcionales (PWM)"),
                     ("slider", "deadzone", "Zona muerta", 0, 0.5, dz_fmt, 0.005)]
            items += [("slider", "pwm_ms", "Periodo de pulsos", 40, 250, "{:.0f} ms", 5)] if ax["pwm"] else \
                     [("slider", "threshold", "Pulsar a partir de", 0.05, 0.95, dz_fmt, 0.01)]

        rows = (len(items) + 1) // 2
        h = 56 + (rows * 52 + 10 if items else 0)
        card = pygame.Rect(r.x, r.y, r.w, h)
        if card.bottom < (ui.clip.y if ui.clip else 0) or card.y > (ui.clip.bottom if ui.clip else H):
            return h  # fuera de la vista
        ui.panel(card, PANEL)
        ui.text("Eje %d" % i, (card.x + 16, card.y + 17), 17, TEXT, True)
        ui.bar_h(pygame.Rect(card.x + 80, card.y + 23, 170, 10), dev.axes[i] if i < dev.n_axes else 0, DIM, True)
        val = ""
        if "deg" in lv:
            val = "%+.1f° → %+d%%" % (lv["deg"], round(lv["out"] * 100))
        elif m == "servo":
            val = "palanca %d%% · juego≈%d%%" % (round(lv.get("v", 0) * 100), round(lv.get("est", 0) * 100))
        elif "out" in lv:
            val = "salida %+d%%" % round(lv["out"] * 100) if m not in ("pedal",) else "salida %d%%" % round(lv["out"] * 100)
        ui.text(val, (card.x + 262, card.y + 19), 14, MUTED)
        nm = ui.cycle("mode%d" % i, pygame.Rect(card.right - 266, card.y + 12, 250, 32), MODE_OPTS, m)
        if nm != m:
            self.change_mode(dev, i, nm)
        if not items:
            return h
        colw = (card.w - 48) // 2
        for n, it in enumerate(items):
            cx = card.x + 16 + (n % 2) * (colw + 16)
            cy = card.y + 58 + (n // 2) * 52
            rr = pygame.Rect(cx, cy, colw, 40)
            wid = "a%d_%d_%d" % (dev.iid, i, n)
            kind = it[0]
            if kind == "slider":
                _, key, label, lo, hi, fmt, step = it
                ax[key] = ui.slider(wid, rr, float(ax[key]), lo, hi, label, fmt, step)
            elif kind == "toggle":
                ax[it[1]] = ui.toggle(wid, pygame.Rect(cx, cy + 4, colw, 32), ax[it[1]], it[2])
            elif kind == "cycle":
                ax[it[1]] = ui.cycle(wid, pygame.Rect(cx, cy + 4, colw, 32), it[3], ax[it[1]], it[2])
            elif kind == "key":
                ax[it[1]] = ui.keybind(wid, pygame.Rect(cx, cy + 4, colw, 32), ax[it[1]], it[2],
                                       winio.pretty, key_name)
            elif kind == "info":
                ui.text(it[1], (cx, cy + 12), 13, MUTED)
            elif kind == "cal":
                br = pygame.Rect(cx, cy + 4, 150, 32)
                if ui.button(wid, br, "Calibrar (5 s)", enabled=self.wiz is None):
                    msg = ("Suelta el pedal y luego písalo a fondo" if m == "pedal"
                           else "Empieza en RALENTÍ y sube la palanca a TOPE")
                    self.start_wizard(dev, "cal", msg, axis=i)
                ui.text("reposo %+.2f → máx %+.2f" % (ax["lo"], ax["hi"]), (br.right + 12, br.centery), 13,
                        MUTED, anchor="midleft")
            elif kind == "sync":
                if ui.button(wid, pygame.Rect(cx, cy + 4, colw, 32),
                             "Sincronizar con el juego" + ("  (hecho)" if ax.get("synced") else ""),
                             color=ACCENT if not ax.get("synced") else PANEL2, bold=not ax.get("synced"),
                             enabled=self.sync is None):
                    self.start_sync(dev)
            elif kind == "center":
                if ui.button(wid, pygame.Rect(cx, cy + 4, colw, 32), "Calibrar centro (deja el volante recto)"):
                    self.calibrate_center(dev)
            elif kind == "ghub":
                if ax["game_range"] < ax["hw_range"] - 5:
                    lab = "Ya puse %.0f° en G HUB" % ax["game_range"]
                    if ui.button(wid, pygame.Rect(cx, cy + 4, colw, 32), lab):
                        ax["hw_range"] = ax["game_range"]
                        self.toast("Listo: tu volante y el del juego topan a la vez.", 5)
                elif ax["game_range"] > ax["hw_range"] + 5:
                    ui.text("1:1 · tu volante llega al %d%% del giro del juego" % round(100 * ax["hw_range"] / ax["game_range"]),
                            (cx, cy + 12), 13, GOOD)
                else:
                    ui.text("Tu volante y el del juego topan a la vez.", (cx, cy + 12), 13, GOOD)
            elif kind == "resync":
                if ui.button(wid, pygame.Rect(cx, cy + 4, colw, 32), "Resincronizar (bajar a ralentí)"):
                    self.resync_all()
        return h

    def change_mode(self, dev, i, mode):
        old = dev.cfg["axes"][str(i)]
        a = core.default_axis(mode)
        a["invert"] = old.get("invert", False)
        if mode == "steer":
            rng = dev.info.get("range", 900)
            a.update(out="LSX", hw_range=rng, game_range=min(rng, 540), antidz=0.2, key_neg="A", key_pos="D")
        elif mode == "pedal":
            a.update(out="RT", lo=old.get("lo", 1.0), hi=old.get("hi", -1.0), key="W")
        elif mode == "stick":
            a.update(out="LSX")
        elif mode == "servo":
            a.update(key_pos="W", key_neg="S", lo=old.get("lo", -1.0), hi=old.get("hi", 1.0))
        elif mode == "keys":
            a.update(deadzone=0.08)
        dev.cfg["axes"][str(i)] = a
        dev.servos.pop(i, None)

    # ------------------------------------------------------------ buttons tab
    def draw_buttons(self, dev, c):
        ui = self.ui
        ui.text("Clic en la casilla de tecla y pulsa la tecla del teclado (Esc cancela, Supr borra, clic derecho borra). "
                "La 2ª casilla: botón de mando o acción.", (c.x, c.y), 13, MUTED)
        c = pygame.Rect(c.x, c.y + 26, c.w, c.h - 26)
        off = self.scroll_area("buttons", c)
        ui.clip = c
        self.screen.set_clip(c)
        ids = dev.button_ids()
        colw = (c.w - 30) // 2
        col = self.type_color(dev.type)
        binds = dev.cfg["buttons"]
        rows = (len(ids) + 1) // 2
        for n, bid in enumerate(ids):
            x = c.x + (n % 2) * (colw + 16)
            y = c.y + (n // 2) * 46 - off
            if y + 40 < c.y or y > c.bottom:
                continue
            row = pygame.Rect(x, y, colw, 40)
            on = dev.pressed(bid)
            ui.rect(row, (44, 36, 34) if on else PANEL, 10)
            pygame.draw.circle(self.screen, col if on else PANEL2, (x + 18, y + 20), 8)
            ui.text(dev.button_label(bid), (x + 34, y + 20), 14, TEXT if on else (200, 204, 214), on, "midleft")
            b = binds.get(bid, {"key": "", "extra": ""})
            kw = min(150, (colw - 140) // 2)
            nk = ui.keybind("bk_%d_%s" % (dev.iid, bid), pygame.Rect(row.right - 2 * kw - 12, y + 4, kw, 32),
                            b.get("key", ""), None, winio.pretty, key_name)
            ne = ui.cycle("bx_%d_%s" % (dev.iid, bid), pygame.Rect(row.right - kw - 6, y + 4, kw, 32),
                          EXTRA_OPTS, b.get("extra", ""))
            if nk or ne:
                binds[bid] = {"key": nk, "extra": ne}
            elif bid in binds:
                del binds[bid]
        self.content_h["buttons"] = rows * 46
        self.screen.set_clip(None)
        ui.clip = None
        self.draw_scrollbar("buttons", c)
        if not ids:
            ui.text("Este dispositivo no tiene botones.", (c.x, c.y + 10), 15, MUTED)

    # ------------------------------------------------------------ ffb tab
    def draw_ffb(self, dev, c):
        ui = self.ui
        f = dev.cfg["ffb"]
        a = pygame.Rect(c.x, c.y, (c.w - 12) // 2, c.h)
        b = pygame.Rect(a.right + 12, c.y, c.w - a.w - 12, c.h)
        ui.panel(a)
        ui.panel(b)
        x, w = a.x + 20, a.w - 40
        y = a.y + 18
        ui.text("FORCE FEEDBACK", (x, y), 12, MUTED, True)
        y += 26
        f["enabled"] = ui.toggle("ffb_en", pygame.Rect(x, y, w, 36), f["enabled"],
                                 "Force feedback " + ("ACTIVADO" if f["enabled"] else "DESACTIVADO"))
        y += 52
        dis = not f["enabled"]
        for key, label in (("gain", "Fuerza global"), ("spring", "Muelle de centrado"),
                           ("damper", "Amortiguación (peso)"), ("friction", "Fricción")):
            f[key] = ui.slider("ffb_" + key, pygame.Rect(x, y, w, 40), f[key], 0, 1, label, "{:.0%}", 0.01,
                               DIM if dis else ACCENT)
            y += 54
        y += 4
        f["rumble"] = ui.toggle("ffb_rum", pygame.Rect(x, y, w, 32), f["rumble"],
                                "Vibración del juego → volante")
        y += 44
        f["rumble_gain"] = ui.slider("ffb_rg", pygame.Rect(x, y, w, 40), f["rumble_gain"], 0, 1,
                                     "Intensidad de la vibración", "{:.0%}", 0.01)
        y += 56
        if ui.button("ffb_test", pygame.Rect(x, y, 200, 34), "Probar vibración", enabled=f["enabled"]):
            self.test_rumble_until = time.time() + 1.0

        x, w, y = b.x + 20, b.w - 40, b.y + 18
        ui.text("CÓMO FUNCIONA", (x, y), 12, MUTED, True)
        y += 28
        lines = [
            "Roblox no envía force feedback a los volantes.",
            "RoSim crea los efectos él mismo:",
            "",
            "• Muelle: el volante vuelve solo al centro.",
            "• Amortiguación: da peso, evita oscilaciones.",
            "• Fricción: sensación de neumático en el asfalto.",
            "• Vibración: cuando el juego hace vibrar el",
            "  mando (choques, pianos…) vibra el volante.",
            "",
            "Desactivado = volante totalmente suelto.",
            "",
            "Logitech G HUB: deja «Fuerza del muelle de",
            "centrado» desactivada para que no se sume.",
        ]
        for ln in lines:
            ui.text(ln, (x, y), 14, TEXT if ln.startswith("•") else MUTED)
            y += 21
        y += 14
        ui.text("Efectos que soporta este volante:", (x, y), 13, MUTED, True)
        y += 20
        caps = dev.ffb.caps_text()
        line = ""
        for word in caps.split(", "):
            t = (line + ", " + word) if line else word
            if ui.text_w(t, 13) > w:
                ui.text(line, (x, y), 13, TEXT)
                y += 18
                line = word
            else:
                line = t
        if line:
            ui.text(line, (x, y), 13, TEXT)

    # ------------------------------------------------------------ settings
    def draw_settings(self, area):
        ui = self.ui
        g = self.g
        a = pygame.Rect(area.x, area.y, (area.w - 12) // 2, area.h)
        b = pygame.Rect(a.right + 12, area.y, area.w - a.w - 12, area.h)
        ui.panel(a)
        ui.panel(b)
        x, w, y = a.x + 20, a.w - 40, a.y + 18
        ui.text("RATÓN CON SIDESTICK / JOYSTICK", (x, y), 12, MUTED, True)
        y += 26
        g["mouse_enabled"] = ui.toggle("s_men", pygame.Rect(x, y, w, 30), g["mouse_enabled"],
                                       "Controlar el ratón con el stick", ACCENT2)
        y += 38
        g["mouse_mode"] = ui.cycle("s_mmode", pygame.Rect(x, y, w, 32),
                                   [("abs", "Sigue al stick (absoluto) — recomendado"),
                                    ("rel", "Velocidad (relativo, como antes)")], g["mouse_mode"], "Modo")
        y += 44
        if g["mouse_mode"] == "abs":
            g["mouse_rx"] = ui.slider("s_rx", pygame.Rect(x, y, w, 40), g["mouse_rx"], 0.05, 0.5,
                                      "Radio horizontal (stick a tope)", "{:.0%} de la pantalla", 0.01, ACCENT2)
            y += 52
            g["mouse_ry"] = ui.slider("s_ry", pygame.Rect(x, y, w, 40), g["mouse_ry"], 0.05, 0.5,
                                      "Radio vertical (stick a tope)", "{:.0%} de la pantalla", 0.01, ACCENT2)
            y += 52
            g["mouse_smooth"] = ui.slider("s_sm", pygame.Rect(x, y, w, 40), g["mouse_smooth"], 0, 0.9,
                                          "Suavizado", "{:.0%}", 0.01, ACCENT2)
            y += 52
            g["mouse_only_on_move"] = ui.toggle("s_oom", pygame.Rect(x, y, w, 30), g["mouse_only_on_move"],
                                                "Solo mover si el stick se mueve", ACCENT2)
            y += 40
            bw = (w - 10) // 2
            if ui.button("s_cc", pygame.Rect(x, y, bw, 32), "Centro = centro pantalla"):
                g["mouse_cx"], g["mouse_cy"] = 0.5, 0.5
                self.follower.reset()
            if ui.button("s_ch", pygame.Rect(x + bw + 10, y, bw, 32), "Fijar centro en cursor (3 s)"):
                self.center_capture_at = time.time() + 3.0
                self.toast("Pon el ratón donde quieras el centro… 3 s")
            y += 42
        else:
            g["mouse_speed"] = ui.slider("s_spd", pygame.Rect(x, y, w, 40), g["mouse_speed"], 100, 4000,
                                         "Velocidad máxima", "{:.0f} px/s", 50, ACCENT2)
            y += 52
        g["mouse_invert_y"] = ui.toggle("s_inv", pygame.Rect(x, y, w, 30), g["mouse_invert_y"],
                                        "Estilo avión: tirar del stick = morro arriba", ACCENT2)
        y += 40
        g["mouse_deadzone"] = ui.slider("s_mdz", pygame.Rect(x, y, w, 40), g["mouse_deadzone"], 0, 0.2,
                                        "Zona muerta del ratón", "{:.0%}", 0.005, ACCENT2)
        y += 52
        g["mouse_gamma"] = ui.slider("s_mg", pygame.Rect(x, y, w, 40), g["mouse_gamma"], 0.4, 3,
                                     "Curva (>1 = más precisión en el centro)", "{:.2f}", 0.05, ACCENT2)

        x, w, y = b.x + 20, b.w - 40, b.y + 18
        ui.text("SALIDA", (x, y), 12, MUTED, True)
        y += 26
        g["output_on"] = ui.toggle("s_out", pygame.Rect(x, y, w, 30), g["output_on"], "Salida activa")
        y += 38
        g["only_roblox"] = ui.toggle("s_rbx", pygame.Rect(x, y, w, 30), g["only_roblox"],
                                     "Solo cuando Roblox / Roblox Studio está delante")
        y += 34
        ui.text("Así el stick no te mueve el ratón en el escritorio.", (x, y), 13, MUTED)
        y += 34
        ui.text("ESTADO", (x, y), 12, MUTED, True)
        y += 24
        if self.pad.pad is not None:
            st, col = "Mando virtual Xbox 360 conectado", GOOD
        elif self.pad.available:
            st, col = "Mando virtual listo (se crea al usarlo)", GOOD
        else:
            st, col = "ViGEmBus / vgamepad no instalado", BAD
        ui.text(st, (x, y), 14, col)
        y += 22
        if self.pad.error and not self.pad.pad:
            ui.text(ui.fit(self.pad.error, w, 12), (x, y), 12, DIM)
            y += 18
        ui.text("Force feedback: " + ("disponible" if self.haptics.lib else self.haptics.error or "no disponible"),
                (x, y), 14, GOOD if self.haptics.lib else WARN)
        y += 30
        ui.text("Configuración guardada en:", (x, y), 13, MUTED)
        y += 18
        ui.text(ui.fit(self.cfg_file, w, 12), (x, y), 12, DIM)
        y += 34
        if ui.button("s_save", pygame.Rect(x, y, 160, 34), "Guardar ahora", color=(60, 44, 40)):
            self.save(force=True)
            self.toast("Guardado (OK)")
        y += 50
        ui.text("RoSim %s" % VERSION, (x, b.bottom - 30), 12, DIM)

    def draw_update(self, area):
        ui = self.ui
        a = pygame.Rect(area.x, area.y, (area.w - 12) // 2, area.h)
        b = pygame.Rect(a.right + 12, area.y, area.w - a.w - 12, area.h)
        ui.panel(a)
        ui.panel(b)
        x, w, y = a.x + 22, a.w - 44, a.y + 20
        ui.text("ACTUALIZAR ROSIM", (x, y), 12, MUTED, True)
        y += 26
        ui.text("Versión instalada", (x, y), 15, MUTED)
        ui.text(VERSION, (x + w, y - 6), 30, TEXT, True, "topright")
        y += 48
        if self.upd_done:
            ui.text(ui.fit(self.upd_msg, w, 15), (x, y), 15, GOOD, True)
            y += 32
            if ui.button("upd_restart", pygame.Rect(x, y, w, 46), "REINICIAR ROSIM AHORA", color=ACCENT, bold=True, size=17):
                self.restart_after = True
                self.quit_now = True
            return self.draw_update_side(b)
        if self.online:
            v = self.online["version"]
            ui.text("Nueva versión %s disponible en internet" % v, (x, y), 15, GOOD, True)
            y += 22
            notes = str(self.online.get("notas", ""))
            if notes:
                ui.text(ui.fit(notes, w, 13), (x, y), 13, MUTED)
                y += 20
            y += 6
            if ui.button("upd_dl", pygame.Rect(x, y, w, 46), "ACTUALIZAR A LA %s (1 clic)" % v, color=ACCENT,
                         bold=True, size=17):
                self.install_online()
            y += 58
        elif self.upd_found:
            v, p = self.upd_found[0]
            ui.text("Nueva versión %s encontrada:" % v, (x, y), 15, GOOD, True)
            y += 22
            ui.text(ui.fit(p, w, 12), (x, y), 12, DIM)
            y += 26
            if ui.button("upd_install", pygame.Rect(x, y, w, 46), "INSTALAR VERSIÓN %s" % v, color=ACCENT,
                         bold=True, size=17):
                self.install_update(p)
            y += 58
        else:
            ui.text("Tienes la última versión." if self.online_checked else "Buscando actualizaciones…",
                    (x, y), 15, TEXT)
            y += 34
        bw = (w - 10) // 2
        if ui.button("upd_pick", pygame.Rect(x, y, bw, 36), "Elegir un .zip…"):
            self.kb.release_all()
            p = system.pick_zip()
            if p:
                self.install_update(p)
        if ui.button("upd_scan", pygame.Rect(x + bw + 10, y, bw, 36), "Buscar de nuevo"):
            self.scan_updates()
            self.upd_msg = "" if self.upd_found else "Descarga el RoSim.zip nuevo desde la web y vuelve aquí."
        y += 46
        if self.g.get("update_url"):
            if ui.button("upd_online", pygame.Rect(x, y, w, 36), "Comprobar ahora en internet"):
                self.check_online()
            y += 46
        if self.upd_msg:
            ui.text(ui.fit(self.upd_msg, w, 14), (x, y), 14, WARN)
            y += 30
        y = max(y + 10, a.bottom - 150)
        ui.text("CÓMO SE ACTUALIZA", (x, y), 12, MUTED, True)
        y += 24
        for ln in ("1. RoSim mira solo si hay versión nueva al abrirse.",
                   "2. Si la hay, este botón se pone naranja.",
                   "3. Pulsa Descargar e instalar y luego Reiniciar.",
                   "Tu configuración y tus teclas se conservan."):
            ui.text(ln, (x, y), 14, TEXT if ln[0].isdigit() else GOOD)
            y += 22
        self.draw_update_side(b)

    def draw_update_side(self, b):
        ui = self.ui
        x, w, y = b.x + 22, b.w - 44, b.y + 20
        ui.text("ACCESO DIRECTO", (x, y), 12, MUTED, True)
        y += 30
        # icono grande
        if self.logo:
            big = pygame.transform.smoothscale(self.logo, (88, 88))
            self.screen.blit(big, (x, y))
        ui.text("RoSim", (x + 108, y + 16), 30, TEXT, True)
        ui.text("en tu escritorio y en el menú Inicio", (x + 108, y + 54), 14, MUTED)
        y += 112
        if ui.button("shortcut", pygame.Rect(x, y, w, 46), "CREAR ACCESO DIRECTO EN EL ESCRITORIO",
                     color=(0, 92, 120), bold=True, size=16):
            self.toast(system.create_shortcuts(), 5)
        y += 60
        for ln in ("Abre RoSim con doble clic, sin consola y con su icono.",
                   "Si mueves la carpeta de RoSim, vuelve a pulsar el botón.",
                   "INSTALAR.bat también lo crea al instalar."):
            ui.text(ln, (x, y), 14, MUTED)
            y += 22

    def draw_help(self, area):
        ui = self.ui
        ui.panel(area)
        x, y = area.x + 24, area.y + 20
        blocks = [
            ("VOLANTE (Logitech G29 / G920 / G923 / G27 / G PRO y cualquier otro)", [
                "RoSim crea un mando de Xbox virtual: el volante va al stick izquierdo y los pedales a RT/LT.",
                "Roblox aplica una zona muerta de ~20% al stick: por eso el coche no gira hasta que giras bastante.",
                "La «Anti-zona muerta» salta esa zona: 1° de volante = el coche ya gira. Si aún notas hueco, súbela;",
                "si el coche tiembla en recto, bájala un poco. «Giro completo en el juego» = cuántos grados de tu",
                "volante hacen el giro máximo del coche (540° va bien; 900° es más realista).",
                "En Logitech G HUB pon el rango de giro a 900° (o 1080° en el G PRO) para que los grados cuadren.",
            ]),
            ("SIDESTICK AIRBUS (Thrustmaster TCA) → RATÓN", [
                "En modo «Sigue al stick» la posición del stick ES la posición del cursor: stick en neutro = cursor",
                "en el centro, así el avión vuelve a volar recto. Usa «Fijar centro en cursor» si tu juego no centra.",
                "Para usar el ratón normal: pon un botón del stick en «Ratón ON/OFF» (pestaña Botones).",
            ]),
            ("PALANCA DE GASES (TCA Quadrant)", [
                "Roblox usa teclas para el gas (normalmente W/S o Shift/Ctrl). RoSim pulsa subir/bajar hasta que el gas",
                "del juego coincide con tu palanca. Ajusta «Tiempo de 0 a 100%» midiendo cuánto tarda el gas del juego",
                "en subir entero manteniendo la tecla. Ralentí o tope siempre resincronizan.",
            ]),
            ("TECLAS", [
                "Cualquier botón (y la cruceta) puede pulsar una tecla, un botón del mando o una acción.",
                "Cualquier eje puede pulsar teclas (con pulsos proporcionales PWM para que sea casi analógico).",
            ]),
        ]
        for title, lines in blocks:
            ui.text(title, (x, y), 15, ACCENT, True)
            y += 26
            for ln in lines:
                ui.text(ln, (x, y), 14, TEXT)
                y += 21
            y += 14

    def draw_wizard(self):
        ui = self.ui
        w = self.wiz
        left = max(0.0, w["dur"] - (time.time() - w["t0"]))
        s = pygame.Surface((W, H), pygame.SRCALPHA)
        s.fill((0, 0, 0, 150))
        self.screen.blit(s, (0, 0))
        r = pygame.Rect(0, 0, 560, 190)
        r.center = (W // 2 + 120, H // 2)
        ui.panel(r, PANEL, 16, ACCENT)
        ui.text("ASISTENTE" + ("  ·  " + w["step"].upper() if w.get("step") else ""), (r.centerx, r.y + 22), 12, MUTED, True, "midtop")
        ui.text(ui.fit(w["text"], r.w - 30, 22, True), (r.centerx, r.y + 50), 22, TEXT, True, "midtop")
        ui.text("%.1f s" % left, (r.centerx, r.y + 96), 34, ACCENT, True, "midtop")
        bar = pygame.Rect(r.x + 30, r.bottom - 34, r.w - 60, 8)
        ui.bar_h(bar, 1 - left / w["dur"], ACCENT)

    # ============================================================ LOOP
    def run(self):
        while self.step() and not self.quit_now:
            self.clock.tick(250)
        self.shutdown()
        if self.restart_after:
            system.restart()

    def step(self):
        events = pygame.event.get()
        for e in events:
            if e.type == pygame.QUIT:
                return False
            elif e.type == pygame.JOYDEVICEADDED:
                self.add_device(e.device_index)
            elif e.type == pygame.JOYDEVICEREMOVED:
                self.remove_device(e.instance_id)
        now = time.time()
        tp = time.perf_counter()
        dt = min(0.1, tp - self.last_t)
        self.last_t = tp

        if now >= self.next_fg_check:
            self.roblox_fg = winio.roblox_in_front()
            self.next_fg_check = now + 0.25
        if now >= self.next_online_check:
            self.next_online_check = now + 1800
            threading.Thread(target=self._bg_check, daemon=True).start()
        if self.center_capture_at and now >= self.center_capture_at:
            self.center_capture_at = 0
            self.set_mouse_center_here()

        keys, st, uses_pad, mouse = self.compute(now, dt)
        if self.wiz:
            self.run_wizard()
        self.output(keys, st, uses_pad, mouse, dt)
        if self.sync:
            self.sync_tick(now)
        if self.cal:
            self.cal_tick(now)
        if self.gcal:
            self.gcal_tick(now)
        self.update_ffb(now)

        # la entrada/salida va a ~250 Hz; la interfaz se dibuja a 60 FPS
        self.pending.extend(e for e in events if e.type in UI_EVENTS)
        if tp - self.last_draw >= 1 / 60:
            self.last_draw = tp
            self.ui.begin(self.pending)
            self.pending = []
            self.draw()

        if now - self.last_save_check > 1.0:
            self.last_save_check = now
            self.save()
        return True

    def shutdown(self):
        self.save(force=True)
        self.kb.release_all()
        for dev in list(self.devices.values()):
            dev.close()
        self.pad.close()
        pygame.quit()


def main():
    App().run()
