"""
RoSim - Force Feedback usando la API de hápticos de SDL2 (la misma SDL2.dll que
trae pygame-ce). Roblox no envía force feedback a volantes, así que RoSim genera
sus propios efectos: muelle de centrado, amortiguación, fricción y convierte la
vibración que Roblox manda al mando virtual en vibración del volante.
"""
import os
import sys
import ctypes

SDL_INIT_HAPTIC = 0x00001000
SDL_HAPTIC_INFINITY = 4294967295
H_CONSTANT, H_SINE = 1 << 0, 1 << 1
H_SPRING, H_DAMPER, H_INERTIA, H_FRICTION = 1 << 7, 1 << 8, 1 << 9, 1 << 10
H_GAIN, H_AUTOCENTER = 1 << 12, 1 << 13
SDL_HAPTIC_CARTESIAN = 1

U8, U16, S16, U32, S32 = ctypes.c_uint8, ctypes.c_uint16, ctypes.c_int16, ctypes.c_uint32, ctypes.c_int32


class Direction(ctypes.Structure):
    _fields_ = [("type", U8), ("dir", S32 * 3)]


class Condition(ctypes.Structure):
    _fields_ = [("type", U16), ("direction", Direction), ("length", U32), ("delay", U16),
                ("button", U16), ("interval", U16),
                ("right_sat", U16 * 3), ("left_sat", U16 * 3),
                ("right_coeff", S16 * 3), ("left_coeff", S16 * 3),
                ("deadband", U16 * 3), ("center", S16 * 3)]


class Periodic(ctypes.Structure):
    _fields_ = [("type", U16), ("direction", Direction), ("length", U32), ("delay", U16),
                ("button", U16), ("interval", U16), ("period", U16), ("magnitude", S16),
                ("offset", S16), ("phase", U16), ("attack_length", U16), ("attack_level", U16),
                ("fade_length", U16), ("fade_level", U16)]


class Effect(ctypes.Union):
    _fields_ = [("type", U16), ("condition", Condition), ("periodic", Periodic),
                ("_pad", ctypes.c_uint8 * 128)]


def _find_sdl():
    try:
        import pygame
        base = os.path.dirname(pygame.__file__)
    except Exception:
        return None
    names = ["SDL2.dll"] if sys.platform == "win32" else ["libSDL2-2.0.so.0", "libSDL2.dylib"]
    for n in names:
        p = os.path.join(base, n)
        if os.path.exists(p):
            return p
    libs = os.path.join(os.path.dirname(base), "pygame_ce.libs")
    if os.path.isdir(libs):
        for f in os.listdir(libs):
            if f.lower().startswith("libsdl2"):
                return os.path.join(libs, f)
    return None


class SDLHaptics:
    def __init__(self):
        self.lib = None
        self.error = ""
        path = _find_sdl()
        if not path:
            self.error = "No se encontró SDL2 de pygame"
            return
        try:
            lib = ctypes.CDLL(path)
            lib.SDL_InitSubSystem.argtypes = [U32]
            lib.SDL_JoystickFromInstanceID.argtypes = [S32]
            lib.SDL_JoystickFromInstanceID.restype = ctypes.c_void_p
            lib.SDL_JoystickIsHaptic.argtypes = [ctypes.c_void_p]
            lib.SDL_HapticOpenFromJoystick.argtypes = [ctypes.c_void_p]
            lib.SDL_HapticOpenFromJoystick.restype = ctypes.c_void_p
            lib.SDL_HapticQuery.argtypes = [ctypes.c_void_p]
            lib.SDL_HapticQuery.restype = ctypes.c_uint
            lib.SDL_HapticNewEffect.argtypes = [ctypes.c_void_p, ctypes.POINTER(Effect)]
            lib.SDL_HapticUpdateEffect.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(Effect)]
            lib.SDL_HapticRunEffect.argtypes = [ctypes.c_void_p, ctypes.c_int, U32]
            lib.SDL_HapticStopEffect.argtypes = [ctypes.c_void_p, ctypes.c_int]
            lib.SDL_HapticDestroyEffect.argtypes = [ctypes.c_void_p, ctypes.c_int]
            lib.SDL_HapticSetGain.argtypes = [ctypes.c_void_p, ctypes.c_int]
            lib.SDL_HapticSetAutocenter.argtypes = [ctypes.c_void_p, ctypes.c_int]
            lib.SDL_HapticStopAll.argtypes = [ctypes.c_void_p]
            lib.SDL_HapticClose.argtypes = [ctypes.c_void_p]
            lib.SDL_GetError.restype = ctypes.c_char_p
            if lib.SDL_InitSubSystem(SDL_INIT_HAPTIC) != 0:
                self.error = "SDL haptic: " + (lib.SDL_GetError() or b"").decode(errors="ignore")
                return
            self.lib = lib
        except Exception as e:
            self.error = "Force feedback no disponible: %s" % e

    def open(self, instance_id):
        if not self.lib:
            return None
        try:
            js = self.lib.SDL_JoystickFromInstanceID(instance_id)
            if not js or self.lib.SDL_JoystickIsHaptic(js) != 1:
                return None
            h = self.lib.SDL_HapticOpenFromJoystick(js)
            if not h:
                return None
            return WheelFFB(self.lib, h)
        except Exception:
            return None


class WheelFFB:
    def __init__(self, lib, handle):
        self.lib = lib
        self.h = handle
        self.caps = lib.SDL_HapticQuery(handle)
        self.ids = {}
        self.params = None
        self.rumble_level = -1
        self.active = False

    def caps_text(self):
        names = [(H_CONSTANT, "Fuerza constante"), (H_SINE, "Vibración"), (H_SPRING, "Muelle"),
                 (H_DAMPER, "Amortiguación"), (H_FRICTION, "Fricción"), (H_INERTIA, "Inercia"),
                 (H_GAIN, "Ganancia"), (H_AUTOCENTER, "Autocentrado")]
        return ", ".join(n for f, n in names if self.caps & f) or "ninguno"

    def _condition(self, kind, strength):
        e = Effect()
        c = e.condition
        c.type = kind
        c.direction.type = SDL_HAPTIC_CARTESIAN
        c.direction.dir[0] = 1
        c.length = SDL_HAPTIC_INFINITY
        v = int(max(0.0, min(1.0, strength)) * 32767)
        for i in range(3):
            c.right_sat[i] = c.left_sat[i] = 0xFFFF
            c.right_coeff[i] = c.left_coeff[i] = v
            c.deadband[i] = 0
            c.center[i] = 0
        return e

    def _periodic(self, level):
        e = Effect()
        p = e.periodic
        p.type = H_SINE
        p.direction.type = SDL_HAPTIC_CARTESIAN
        p.direction.dir[0] = 1
        p.length = SDL_HAPTIC_INFINITY
        p.period = 45
        p.magnitude = int(max(0.0, min(1.0, level)) * 32767)
        return e

    def _set(self, name, effect, run=True):
        if name in self.ids:
            self.lib.SDL_HapticUpdateEffect(self.h, self.ids[name], ctypes.byref(effect))
        else:
            eid = self.lib.SDL_HapticNewEffect(self.h, ctypes.byref(effect))
            if eid < 0:
                return
            self.ids[name] = eid
            if run:
                self.lib.SDL_HapticRunEffect(self.h, eid, SDL_HAPTIC_INFINITY)

    def apply(self, cfg, rumble=0.0):
        """Llamar cada frame. Solo toca el hardware cuando algo cambia."""
        if not cfg.get("enabled"):
            if self.active or self.params is None:
                self.stop()
                self.params = ("off",)
            return
        p = (round(cfg["gain"], 3), round(cfg["spring"], 3), round(cfg["damper"], 3),
             round(cfg["friction"], 3))
        if p != self.params:
            self.params = p
            self.active = True
            if self.caps & H_GAIN:
                self.lib.SDL_HapticSetGain(self.h, int(cfg["gain"] * 100))
            if self.caps & H_AUTOCENTER:
                self.lib.SDL_HapticSetAutocenter(self.h, 0)  # usamos nuestro muelle
            if self.caps & H_SPRING:
                self._set("spring", self._condition(H_SPRING, cfg["spring"]))
            if self.caps & H_DAMPER:
                self._set("damper", self._condition(H_DAMPER, cfg["damper"]))
            if self.caps & H_FRICTION:
                self._set("friction", self._condition(H_FRICTION, cfg["friction"]))
        level = rumble * cfg.get("rumble_gain", 0.6) if cfg.get("rumble") else 0.0
        level = round(level, 2)
        if level != self.rumble_level and self.caps & H_SINE:
            self.rumble_level = level
            if level <= 0.01:
                if "rumble" in self.ids:
                    self.lib.SDL_HapticStopEffect(self.h, self.ids["rumble"])
            else:
                fresh = "rumble" not in self.ids
                self._set("rumble", self._periodic(level), run=fresh)
                if not fresh:
                    self.lib.SDL_HapticRunEffect(self.h, self.ids["rumble"], SDL_HAPTIC_INFINITY)

    def stop(self):
        try:
            self.lib.SDL_HapticStopAll(self.h)
            for eid in self.ids.values():
                self.lib.SDL_HapticDestroyEffect(self.h, eid)
            if self.caps & H_AUTOCENTER:
                self.lib.SDL_HapticSetAutocenter(self.h, 0)
        except Exception:
            pass
        self.ids = {}
        self.active = False
        self.rumble_level = -1

    def close(self):
        self.stop()
        try:
            self.lib.SDL_HapticClose(self.h)
        except Exception:
            pass
