"""
RoSim - salida de teclado y ratón en Windows (SendInput con scancodes, que es
lo que Roblox lee bien). En otros sistemas todo es un no-op para poder probar.
"""
import sys
import ctypes

IS_WIN = sys.platform == "win32"

# Nombre de tecla -> (virtual key, extendida)
VK = {}
for _c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
    VK[_c] = (ord(_c), False)
for _d in "0123456789":
    VK[_d] = (ord(_d), False)
for _i in range(1, 13):
    VK["F%d" % _i] = (0x6F + _i, False)
for _i in range(10):
    VK["NUM%d" % _i] = (0x60 + _i, False)
VK.update({
    "SPACE": (0x20, False), "ENTER": (0x0D, False), "TAB": (0x09, False),
    "ESC": (0x1B, False), "BACKSPACE": (0x08, False), "CAPSLOCK": (0x14, False),
    "LSHIFT": (0xA0, False), "RSHIFT": (0xA1, False),
    "LCTRL": (0xA2, False), "RCTRL": (0xA3, True),
    "LALT": (0xA4, False), "RALT": (0xA5, True),
    "UP": (0x26, True), "DOWN": (0x28, True), "LEFT": (0x25, True), "RIGHT": (0x27, True),
    "INSERT": (0x2D, True), "DELETE": (0x2E, True), "HOME": (0x24, True), "END": (0x23, True),
    "PAGEUP": (0x21, True), "PAGEDOWN": (0x22, True),
    "MINUS": (0xBD, False), "PLUS": (0xBB, False), "COMMA": (0xBC, False),
    "PERIOD": (0xBE, False), "NUM+": (0x6B, False), "NUM-": (0x6D, False),
    "NUM*": (0x6A, False), "NUM/": (0x6F, True), "NUMENTER": (0x0D, True),
})
MOUSE_BUTTONS = {"MOUSE1": (0x0002, 0x0004), "MOUSE2": (0x0008, 0x0010), "MOUSE3": (0x0020, 0x0040)}

PRETTY = {"SPACE": "Espacio", "LSHIFT": "Shift", "RSHIFT": "Shift Der", "LCTRL": "Ctrl",
          "RCTRL": "Ctrl Der", "LALT": "Alt", "RALT": "AltGr", "UP": "↑", "DOWN": "↓",
          "LEFT": "←", "RIGHT": "→", "ENTER": "Intro", "BACKSPACE": "Retroceso",
          "DELETE": "Supr", "PAGEUP": "RePág", "PAGEDOWN": "AvPág", "HOME": "Inicio",
          "END": "Fin", "INSERT": "Insert", "MOUSE1": "Clic izq", "MOUSE2": "Clic der",
          "MOUSE3": "Clic rueda", "CAPSLOCK": "Bloq Mayús", "ESC": "Esc", "TAB": "Tab"}


def pretty(name):
    if not name:
        return "—"
    return PRETTY.get(name, name)


if IS_WIN:
    from ctypes import wintypes
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    ULONG_PTR = ctypes.c_size_t

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                    ("dwExtraInfo", ULONG_PTR)]

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                    ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class HARDWAREINPUT(ctypes.Structure):
        _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD),
                    ("wParamH", wintypes.WORD)]

    class _U(ctypes.Union):
        _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT), ("hi", HARDWAREINPUT)]

    class INPUT(ctypes.Structure):
        _anonymous_ = ("u",)
        _fields_ = [("type", wintypes.DWORD), ("u", _U)]

    user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
    user32.SendInput.restype = wintypes.UINT
    user32.MapVirtualKeyW.argtypes = (wintypes.UINT, wintypes.UINT)
    user32.MapVirtualKeyW.restype = wintypes.UINT
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetWindowTextW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
    user32.GetSystemMetrics.argtypes = (ctypes.c_int,)
    user32.GetCursorPos.argtypes = (ctypes.POINTER(wintypes.POINT),)

    try:  # que Windows muestre el icono de RoSim en la barra de tareas (y no el de Python)
        ctypes.WinDLL("shell32").SetCurrentProcessExplicitAppUserModelID("RoSim.ControlHub")
    except Exception:
        pass

    try:  # coordenadas reales aunque Windows tenga escalado (125%, 150%...)
        ctypes.WinDLL("shcore").SetProcessDpiAwareness(2)
    except Exception:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass

    def _send(*inputs):
        arr = (INPUT * len(inputs))(*inputs)
        user32.SendInput(len(inputs), arr, ctypes.sizeof(INPUT))

    def key_event(name, down):
        if name in MOUSE_BUTTONS:
            flag = MOUSE_BUTTONS[name][0 if down else 1]
            _send(INPUT(type=0, mi=MOUSEINPUT(0, 0, 0, flag, 0, 0)))
            return
        if name not in VK:
            return
        vk, ext = VK[name]
        scan = user32.MapVirtualKeyW(vk, 0)
        flags = 0x0008  # KEYEVENTF_SCANCODE
        if ext:
            flags |= 0x0001
        if not down:
            flags |= 0x0002
        _send(INPUT(type=1, ki=KEYBDINPUT(0, scan, flags, 0, 0)))

    def screen_size():
        return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

    def mouse_move_abs(x, y):
        w, h = screen_size()
        nx = int(x * 65535 / max(1, w - 1))
        ny = int(y * 65535 / max(1, h - 1))
        _send(INPUT(type=0, mi=MOUSEINPUT(nx, ny, 0, 0x0001 | 0x8000, 0, 0)))

    def mouse_move_rel(dx, dy):
        _send(INPUT(type=0, mi=MOUSEINPUT(int(dx), int(dy), 0, 0x0001, 0, 0)))

    def cursor_pos():
        p = wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(p))
        return p.x, p.y

    def foreground_title():
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return ""
        buf = ctypes.create_unicode_buffer(256)
        user32.GetWindowTextW(hwnd, buf, 256)
        return buf.value
else:
    def key_event(name, down):
        pass

    def screen_size():
        return 1920, 1080

    def mouse_move_abs(x, y):
        pass

    def mouse_move_rel(dx, dy):
        pass

    def cursor_pos():
        return 960, 540

    def foreground_title():
        return ""


def roblox_in_front():
    t = foreground_title().lower()
    return "roblox" in t


class KeyBoard:
    """Mantiene el conjunto de teclas pulsadas y solo envía los cambios."""

    def __init__(self):
        self.held = set()

    def sync(self, wanted):
        for k in list(self.held - wanted):
            key_event(k, False)
            self.held.discard(k)
        for k in wanted - self.held:
            key_event(k, True)
            self.held.add(k)

    def release_all(self):
        self.sync(set())
