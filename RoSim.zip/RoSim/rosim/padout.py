"""
RoSim - mando virtual de Xbox 360 (ViGEmBus + vgamepad). Roblox lo ve como un
mando normal: el volante va al stick izquierdo y los pedales a los gatillos.
"""

try:
    import vgamepad as vg
    _ERR = ""
except Exception as e:  # ViGEmBus no instalado, o no es Windows
    vg = None
    _ERR = str(e) or "vgamepad no disponible"

PAD_BUTTONS = ["A", "B", "X", "Y", "LB", "RB", "START", "BACK", "LS", "RS",
               "UP", "DOWN", "LEFT", "RIGHT"]


def _btn(name):
    B = vg.XUSB_BUTTON
    return {
        "A": B.XUSB_GAMEPAD_A, "B": B.XUSB_GAMEPAD_B, "X": B.XUSB_GAMEPAD_X,
        "Y": B.XUSB_GAMEPAD_Y, "LB": B.XUSB_GAMEPAD_LEFT_SHOULDER,
        "RB": B.XUSB_GAMEPAD_RIGHT_SHOULDER, "START": B.XUSB_GAMEPAD_START,
        "BACK": B.XUSB_GAMEPAD_BACK, "LS": B.XUSB_GAMEPAD_LEFT_THUMB,
        "RS": B.XUSB_GAMEPAD_RIGHT_THUMB, "UP": B.XUSB_GAMEPAD_DPAD_UP,
        "DOWN": B.XUSB_GAMEPAD_DPAD_DOWN, "LEFT": B.XUSB_GAMEPAD_DPAD_LEFT,
        "RIGHT": B.XUSB_GAMEPAD_DPAD_RIGHT,
    }[name]


class PadState:
    __slots__ = ("lx", "ly", "rx", "ry", "lt", "rt", "buttons")

    def __init__(self):
        self.lx = self.ly = self.rx = self.ry = 0.0
        self.lt = self.rt = 0.0
        self.buttons = set()

    def key(self):
        r = lambda v: round(v, 4)
        return (r(self.lx), r(self.ly), r(self.rx), r(self.ry), r(self.lt), r(self.rt),
                frozenset(self.buttons))


class VirtualPad:
    def __init__(self):
        self.pad = None
        self.error = _ERR
        self.last = None
        self.rumble = 0.0   # 0..1, lo que Roblox manda vibrar

    @property
    def available(self):
        return vg is not None

    def ensure(self):
        if self.pad is not None or vg is None:
            return self.pad is not None
        try:
            self.pad = vg.VX360Gamepad()
            try:
                self.pad.register_notification(self._on_rumble)
            except Exception:
                pass
            self.error = ""
        except Exception as e:
            self.pad = None
            self.error = str(e) or "No se pudo crear el mando virtual (¿ViGEmBus instalado?)"
        return self.pad is not None

    def _on_rumble(self, client, target, large_motor, small_motor, led_number, user_data):
        self.rumble = max(large_motor, small_motor) / 255.0

    def send(self, st):
        if not self.ensure():
            return
        k = st.key()
        if k == self.last:
            return
        self.last = k
        p = self.pad
        p.left_joystick_float(x_value_float=st.lx, y_value_float=st.ly)
        p.right_joystick_float(x_value_float=st.rx, y_value_float=st.ry)
        p.left_trigger_float(value_float=st.lt)
        p.right_trigger_float(value_float=st.rt)
        old = self.last_buttons if hasattr(self, "last_buttons") else set()
        for b in old - st.buttons:
            p.release_button(button=_btn(b))
        for b in st.buttons - old:
            p.press_button(button=_btn(b))
        self.last_buttons = set(st.buttons)
        p.update()

    def neutral(self):
        if self.pad is not None:
            self.send(PadState())

    def close(self):
        if self.pad is not None:
            try:
                self.neutral()
                self.pad.reset()
                self.pad.update()
            except Exception:
                pass
        self.pad = None
