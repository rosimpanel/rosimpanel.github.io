"""
RoSim - lógica pura (sin pygame ni Windows): detección de dispositivos,
perfiles por defecto y procesado de ejes. Se puede probar en cualquier SO.
"""
import math
import copy

# ---------------------------------------------------------------------------
#  Base de datos de dispositivos conocidos
# ---------------------------------------------------------------------------
VID_LOGITECH = 0x046D
VID_THRUSTMASTER = 0x044F

# PID -> (modelo, grados máximos de giro)
LOGITECH_WHEELS = {
    0xC24F: ("Logitech G29", 900),
    0xC260: ("Logitech G29 (modo PS4)", 900),
    0xC262: ("Logitech G920", 900),
    0xC266: ("Logitech G923 (PlayStation)", 900),
    0xC267: ("Logitech G923 (PlayStation)", 900),
    0xC26D: ("Logitech G923 (Xbox)", 900),
    0xC26E: ("Logitech G923 (Xbox)", 900),
    0xC268: ("Logitech G PRO (PlayStation)", 1080),
    0xC272: ("Logitech G PRO (Xbox)", 1080),
    0xC29B: ("Logitech G27", 900),
    0xC299: ("Logitech G25", 900),
    0xC29A: ("Logitech Driving Force GT", 900),
    0xC298: ("Logitech Driving Force Pro", 900),
    0xC294: ("Logitech Driving Force / Formula EX", 200),
    0xC295: ("Logitech MOMO Force", 240),
    0xC29C: ("Logitech Speed Force Wireless", 270),
}

THRUSTMASTER_WHEELS = {
    0xB66E: ("Thrustmaster T300 RS", 1080),
    0xB66F: ("Thrustmaster T300 RS", 1080),
    0xB66D: ("Thrustmaster T300 RS", 1080),
    0xB677: ("Thrustmaster T150", 1080),
    0xB67F: ("Thrustmaster TMX", 900),
    0xB696: ("Thrustmaster T248", 900),
    0xB65E: ("Thrustmaster T500 RS", 1080),
    0xB664: ("Thrustmaster TX", 900),
    0xB669: ("Thrustmaster TX", 900),
    0xB65D: ("Thrustmaster T-GT", 1080),
    0xB692: ("Thrustmaster TS-XW", 1080),
    0xB689: ("Thrustmaster TS-PC", 1080),
}

WHEEL_WORDS = ("wheel", "racing", "volante", "g29", "g920", "g923", "g27", "g25",
               "driving force", "momo", "t300", "t150", "t248", "t128", "tmx",
               "t500", "t-gt", "fanatec", "csl", "clubsport", "podium", "moza",
               "simucube", "simagic", "cammus", "logitech g pro", "ts-pc", "ts-xw")
THROTTLE_WORDS = ("throttle", "quadrant", "q-eng", "tqs", "gases", "twcs",
                  "x56 throttle", "x52 throttle")
STICK_WORDS = ("sidestick", "joystick", "stick", "yoke", "hotas", "airbus",
               "t.16000", "t.flight", "warthog", "x56", "x52", "gladiator")
GAMEPAD_WORDS = ("xbox", "controller", "gamepad", "dualsense", "dualshock",
                 "wireless controller", "pro controller", "ps4", "ps5")

TYPE_LABELS = {
    "wheel": "Volante",
    "stick": "Sidestick / Joystick",
    "throttle": "Palanca de gases",
    "gamepad": "Mando",
    "generic": "Dispositivo",
}


def parse_guid(guid):
    """Saca VID/PID de un GUID de SDL2. Devuelve (vid, pid) o (0, 0)."""
    g = (guid or "").lower()
    if len(g) != 32:
        return 0, 0
    try:
        if g.endswith("504944564944"):          # GUID antiguo de DirectInput "PIDVID"
            return int(g[2:4] + g[0:2], 16), int(g[6:8] + g[4:6], 16)
        vid = int(g[10:12] + g[8:10], 16)
        pid = int(g[18:20] + g[16:18], 16)
        return vid, pid
    except ValueError:
        return 0, 0


def classify(name, guid, n_axes, n_buttons):
    """Devuelve dict con type, model, range (grados), brand."""
    n = (name or "").lower()
    vid, pid = parse_guid(guid)
    info = {"type": "generic", "model": name or "Dispositivo", "range": 900,
            "vid": vid, "pid": pid, "brand": ""}

    if vid == VID_LOGITECH and pid in LOGITECH_WHEELS:
        info.update(type="wheel", model=LOGITECH_WHEELS[pid][0],
                    range=LOGITECH_WHEELS[pid][1], brand="logitech")
        return info
    if vid == VID_THRUSTMASTER and pid in THRUSTMASTER_WHEELS:
        info.update(type="wheel", model=THRUSTMASTER_WHEELS[pid][0],
                    range=THRUSTMASTER_WHEELS[pid][1], brand="thrustmaster")
        return info

    # Thrustmaster TCA (Airbus / Boeing)
    if "tca" in n or vid == VID_THRUSTMASTER:
        if any(w in n for w in ("q-eng", "quadrant", "throttle")):
            info.update(type="throttle", brand="thrustmaster")
            return info
        if any(w in n for w in ("sidestick", "airbus", "yoke", "stick")):
            info.update(type="stick", brand="thrustmaster")
            return info

    if any(w in n for w in THROTTLE_WORDS):
        info["type"] = "throttle"
    elif any(w in n for w in WHEEL_WORDS):
        info["type"] = "wheel"
        if "g pro" in n or "1080" in n:
            info["range"] = 1080
        if "logitech" in n:
            info["brand"] = "logitech"
    elif any(w in n for w in STICK_WORDS):
        info["type"] = "stick"
    elif any(w in n for w in GAMEPAD_WORDS):
        info["type"] = "gamepad"
    return info


# ---------------------------------------------------------------------------
#  Configuración por defecto
# ---------------------------------------------------------------------------
def default_axis(mode="none"):
    return {
        "mode": mode,          # none | steer | pedal | stick | mouse_x | mouse_y | servo | keys
        "out": "",             # destino (depende del modo)
        "invert": False,
        "deadzone": 0.0,       # zona muerta del propio dispositivo
        "antidz": 0.0,         # anti-zona-muerta (compensa la de Roblox)
        "gamma": 1.0,          # curva (1 = lineal)
        "sat": 1.0,            # saturación (pedales: llegar al 100% antes)
        "lo": -1.0, "hi": 1.0, # calibración (reposo / máximo)
        "hw_range": 900,       # grados reales del volante
        "game_range": 900,     # grados que equivalen a giro completo en el juego
        "key_neg": "", "key_pos": "",
        "key": "",
        "threshold": 0.5,
        "pwm": True,
        "pwm_ms": 100,
        "full_time": 4.0,      # servo: segundos que tarda el juego de 0 a 100%
        "tol": 0.02,
        "t_full": 1.0,         # seguimiento: s que tarda el volante del juego de centro a tope
        "t_ret": 1.0,          # seguimiento: s que tarda en volver al centro al soltar (0 = no vuelve)
        "track_tol": 0.03,
        "lock_beep": True,
        "center": 0.0,         # valor del eje con el volante recto (Calibrar centro)
        "center_deg": 1.0,     # grados de margen en el centro
        "cam_follow": False,   # la cámara del juego gira hacia donde giras el volante
        "cam_px": 400,         # píxeles de ratón con la cámara a tope
        "cam_full_deg": 180,   # grados de volante para llegar a ese tope
        "cam_curve": 1.3,
        "cam_smooth": 0.4,
        "cam_rmb": False,      # mantener clic derecho al mover (cámara en 3ª persona de Roblox)
        "cam_invert": False,     # pitido cuando tu volante llega al tope del volante del juego
    }


def make_axis(mode, **kw):
    a = default_axis(mode)
    a.update(kw)
    return a


def default_device_config(info, n_axes, n_buttons):
    t = info["type"]
    axes = {}
    for i in range(n_axes):
        axes[str(i)] = default_axis()

    def put(i, ax):
        if i < n_axes:
            axes[str(i)] = ax

    if t == "wheel":
        rng = info.get("range", 900)
        # Giro completo del juego a 540° (270° por lado). Anti-zona-muerta 20% para
        # anular la zona muerta de mando que aplica Roblox.
        put(0, make_axis("steer", out="LSX", hw_range=rng, game_range=min(rng, 540),
                         antidz=0.20, key_neg="A", key_pos="D"))
        # Pedales Logitech: reposo = +1, pisado a fondo = -1
        put(1, make_axis("pedal", out="RT", lo=1.0, hi=-1.0, key="W"))
        put(2, make_axis("pedal", out="LT", lo=1.0, hi=-1.0, key="S"))
        put(3, make_axis("pedal", out="NONE", lo=1.0, hi=-1.0))
    elif t == "stick":
        put(0, make_axis("mouse_x"))
        put(1, make_axis("mouse_y"))
    elif t == "throttle":
        put(0, make_axis("servo", key_pos="W", key_neg="S", lo=-1.0, hi=1.0))
    elif t == "gamepad":
        pass

    return {
        "enabled": t != "gamepad",   # los mandos (y el mando virtual) se ignoran por defecto
        "type": t,
        "axes": axes,
        "buttons": {},               # "b3" / "h0u" -> {"kind": "key"/"pad"/"action", "value": ...}
        "ffb": {
            "enabled": True, "gain": 0.8, "spring": 0.35, "damper": 0.15,
            "friction": 0.05, "rumble": True, "rumble_gain": 0.6,
        },
    }


DEFAULT_GLOBAL = {
    "output_on": True,
    "only_roblox": True,           # solo enviar cuando Roblox está en primer plano
    "mouse_enabled": True,
    "mouse_mode": "abs",           # abs = el ratón sigue al mando | rel = velocidad
    "mouse_rx": 0.30,              # radio horizontal (fracción del ancho de pantalla)
    "mouse_ry": 0.30,              # radio vertical (fracción del alto)
    "mouse_cx": 0.5, "mouse_cy": 0.5,  # centro (fracción de pantalla)
    "mouse_smooth": 0.35,
    "mouse_speed": 1200,           # px/s en modo relativo
    "mouse_invert_y": False,       # False: stick arriba = cursor arriba
    "cfg_version": 4,
    "update_url": "https://rosimpanel.github.io/version.json",              # opcional: URL a un version.json para buscar en internet
    "mouse_only_on_move": True,    # no pelearse con tu ratón cuando el stick está quieto
    "mouse_deadzone": 0.02,
    "mouse_gamma": 1.0,
}


def merge_defaults(cfg, defaults):
    """Rellena claves que falten (para configs de versiones antiguas)."""
    out = copy.deepcopy(defaults)
    for k, v in (cfg or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict) and k not in ("axes", "buttons"):
            out[k] = merge_defaults(v, out[k])
        else:
            out[k] = v
    return out


# ---------------------------------------------------------------------------
#  Procesado de ejes
# ---------------------------------------------------------------------------
def clamp(x, lo, hi):
    return lo if x < lo else hi if x > hi else x


def shape_signed(x, deadzone=0.0, gamma=1.0, antidz=0.0):
    """Zona muerta interna -> curva -> anti-zona-muerta. Entrada/salida en [-1, 1]."""
    a = abs(x)
    if a <= deadzone or a < 1e-4:
        return 0.0
    a = (a - deadzone) / max(1e-6, 1.0 - deadzone)
    a = clamp(a, 0.0, 1.0) ** max(0.05, gamma)
    if antidz > 0:
        a = antidz + (1.0 - antidz) * a
    return math.copysign(clamp(a, 0.0, 1.0), x)


def shape_unsigned(v, deadzone=0.0, sat=1.0, gamma=1.0, antidz=0.0):
    """Para pedales/palancas: [0,1] -> [0,1]."""
    if v <= deadzone or v < 1e-4:
        return 0.0
    top = max(deadzone + 0.01, sat)
    v = clamp((v - deadzone) / (top - deadzone), 0.0, 1.0)
    v = v ** max(0.05, gamma)
    if antidz > 0:
        v = antidz + (1.0 - antidz) * v
    return clamp(v, 0.0, 1.0)


def calibrate01(raw, lo, hi):
    if abs(hi - lo) < 1e-6:
        return 0.0
    return clamp((raw - lo) / (hi - lo), 0.0, 1.0)


def steer_values(raw, ax):
    """Devuelve (grados_reales, valor_sin_antidz, salida_final) para el eje de dirección."""
    x = raw - float(ax.get("center", 0.0))        # centro calibrado (volante recto = 0)
    x = -x if ax.get("invert") else x
    hw = max(1.0, float(ax.get("hw_range", 900)))
    deg = x * hw / 2.0
    lock = max(1.0, float(ax.get("game_range", hw))) / 2.0
    cdz = float(ax.get("center_deg", 1.0))         # margen en el centro: el ruido no gira el coche
    if abs(deg) <= cdz:
        s = 0.0
    else:
        s = clamp(math.copysign(abs(deg) - cdz, deg) / max(1.0, lock - cdz), -1.0, 1.0)
    plain = shape_signed(s, ax.get("deadzone", 0.0), ax.get("gamma", 1.0), 0.0)
    out = shape_signed(s, ax.get("deadzone", 0.0), ax.get("gamma", 1.0), ax.get("antidz", 0.0))
    return deg, plain, out


def pedal_value(raw, ax):
    v = calibrate01(raw, ax.get("lo", -1.0), ax.get("hi", 1.0))
    if ax.get("invert"):
        v = 1.0 - v
    return v, shape_unsigned(v, ax.get("deadzone", 0.0), ax.get("sat", 1.0),
                             ax.get("gamma", 1.0), ax.get("antidz", 0.0))


def signed_value(raw, ax):
    x = -raw if ax.get("invert") else raw
    return shape_signed(x, ax.get("deadzone", 0.0), ax.get("gamma", 1.0), ax.get("antidz", 0.0))


def pwm_on(value, now, period_ms):
    """Pulsa una tecla una fracción `value` de cada periodo (mitad analógico con teclas)."""
    if value <= 0.02:
        return False
    if value >= 0.95:
        return True
    period = max(0.03, period_ms / 1000.0)
    phase = (now % period) / period
    return phase < value


class Servo:
    """
    Convierte una palanca ABSOLUTA (gases) en pulsaciones de teclas que suben/bajan
    el acelerador del juego. Lleva una estimación de dónde está el gas del juego y
    pulsa subir/bajar hasta que coincide con la palanca. En los extremos (ralentí o
    TOGA) mantiene la tecla, lo que vuelve a sincronizar el juego.
    """

    def __init__(self):
        self.est = 0.0
        self.dir = 0
        self.sync_until = 0.0

    def resync(self, now, full_time):
        self.sync_until = now + full_time * 1.15 + 0.2
        self.est = 0.0

    def update(self, target, dt, now, full_time, tol):
        if now < self.sync_until:            # forzando a ralentí
            self.est = 0.0
            self.dir = -1
            return self.dir
        rate = 1.0 / max(0.1, full_time)
        if target >= 0.985:
            self.dir = 1
            self.est = min(1.0, self.est + rate * dt)
        elif target <= 0.015:
            self.dir = -1
            self.est = max(0.0, self.est - rate * dt)
        else:
            err = target - self.est
            # histéresis: empieza a moverse si el error > tol, para cuando cruza el objetivo
            if self.dir == 0 and abs(err) > tol:
                self.dir = 1 if err > 0 else -1
            if self.dir == 1:
                self.est = min(target, self.est + rate * dt)
                if self.est >= target:
                    self.dir = 0
            elif self.dir == -1:
                self.est = max(target, self.est - rate * dt)
                if self.est <= target:
                    self.dir = 0
        return self.dir


class Tracker:
    """
    Para juegos que no leen CUÁNTO giras, solo hacia dónde: mientras el stick está a un
    lado, su volante sigue girando hasta el tope. Tracker estima dónde está el volante
    del juego (est, de -1 a 1) y da toques a tope (-1 / 0 / +1) para dejarlo donde
    pide tu volante (target). Si al soltar el juego vuelve al centro, también lo usa.
    """
    MIN_PULSE = 0.0     # el juego lee la entrada ~60 veces/s: cada decisión dura al menos 1 fotograma
    TICK = 1.0 / 60

    def __init__(self, est=0.0):
        self.est = est
        self.u = 0
        self.hold_until = 0.0
        self.next_tick = 0.0

    def update(self, target, dt, now, t_full, t_ret, tol):
        v_in = 1.0 / max(0.05, t_full)
        v_ret = 1.0 / t_ret if t_ret and t_ret > 0 else 0.0
        if self.u != 0:
            self.est = clamp(self.est + self.u * v_in * dt, -1.0, 1.0)
        elif v_ret:
            step = v_ret * dt
            self.est = 0.0 if abs(self.est) <= step else self.est - math.copysign(step, self.est)
        if now < self.hold_until:
            return self.u
        # decidir solo en una rejilla fija de 1/60 s: así cada pulso dura un número exacto de
        # fotogramas del juego y el error no se acumula al mantener el volante quieto
        if now < self.next_tick:
            return self.u
        self.next_tick = (self.next_tick + self.TICK) if now - self.next_tick < self.TICK else now + self.TICK
        target = clamp(target, -1.0, 1.0)
        err = target - self.est
        if abs(err) <= tol:
            nu = 0
        else:
            d = 1 if err > 0 else -1
            # volver solo hacia el centro es más rápido que empujar: suelta en vez de empujar
            towards_center = self.est != 0 and (d > 0) == (self.est < 0)
            if towards_center and v_ret > v_in and abs(target) < abs(self.est) and (target == 0 or (target > 0) == (self.est > 0)):
                nu = 0
            else:
                nu = d
        if nu != self.u:
            self.u = nu
            self.hold_until = now + self.MIN_PULSE
        return self.u


class MouseFollower:
    """El cursor SIGUE la posición del stick: stick en neutro = cursor en el centro."""

    def __init__(self):
        self.cur = None
        self.last_target = None

    def reset(self):
        self.cur = None
        self.last_target = None

    def update(self, sx, sy, g, scr_w, scr_h, dt):
        """sx, sy en [-1,1]. Devuelve (x, y) en píxeles o None si no hay que mover."""
        cx = g["mouse_cx"] * scr_w
        cy = g["mouse_cy"] * scr_h
        tx = cx + sx * g["mouse_rx"] * scr_w
        ty = cy + sy * g["mouse_ry"] * scr_h
        tx = clamp(tx, 0, scr_w - 1)
        ty = clamp(ty, 0, scr_h - 1)
        sm = clamp(g.get("mouse_smooth", 0.0), 0.0, 0.95)
        if self.cur is None:
            self.cur = [tx, ty]
        else:
            # suavizado exponencial independiente de los FPS
            k = 1.0 - (sm ** (dt * 60.0)) if sm > 0 else 1.0
            self.cur[0] += (tx - self.cur[0]) * k
            self.cur[1] += (ty - self.cur[1]) * k
        moving = (self.last_target is None or
                  abs(tx - self.last_target[0]) > 0.5 or abs(ty - self.last_target[1]) > 0.5)
        settling = abs(self.cur[0] - tx) > 0.5 or abs(self.cur[1] - ty) > 0.5
        self.last_target = (tx, ty)
        if g.get("mouse_only_on_move", True) and not moving and not settling:
            return None
        return int(round(self.cur[0])), int(round(self.cur[1]))
