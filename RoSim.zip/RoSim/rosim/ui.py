"""
RoSim - mini toolkit de interfaz (modo inmediato) dibujado con pygame.
"""
import pygame

# Paleta: carbono + naranja carreras + cian aviación
BG = (14, 15, 19)
PANEL = (22, 24, 30)
PANEL2 = (30, 33, 41)
LINE = (44, 48, 60)
TEXT = (232, 234, 240)
MUTED = (140, 146, 162)
DIM = (88, 94, 110)
ACCENT = (255, 92, 46)
ACCENT2 = (0, 196, 255)
GOOD = (64, 214, 120)
WARN = (255, 196, 64)
BAD = (255, 72, 88)


class Fonts:
    def __init__(self):
        self.cache = {}
        self.text_cache = {}
        self.family = "segoeui,arial"

    def get(self, size, bold=False):
        k = (size, bold)
        if k not in self.cache:
            self.cache[k] = pygame.font.SysFont(self.family, size, bold=bold)
        return self.cache[k]

    def render(self, text, size, color, bold=False):
        k = (text, size, color, bold)
        s = self.text_cache.get(k)
        if s is None:
            if len(self.text_cache) > 3000:
                self.text_cache.clear()
            s = self.get(size, bold).render(text, True, color)
            self.text_cache[k] = s
        return s


class UI:
    def __init__(self, screen):
        self.screen = screen
        self.fonts = Fonts()
        self.mouse = (0, 0)
        self.clicked = False
        self.rclicked = False
        self.down = False
        self.wheel = 0
        self.keys = []          # eventos KEYDOWN de este frame
        self.mouse_btn_events = []
        self.drag = None
        self.capture = None     # id del campo que está esperando una tecla
        self.typed = ""
        self.focus = None       # campo de texto activo
        self.captured = None    # (id, valor) resultado de la captura
        self.clip = None
        self.hover_id = None
        self.tooltip = None

    # ---------------------------------------------------------------- frame
    def begin(self, events):
        self.clicked = self.rclicked = False
        self.wheel = 0
        self.keys = []
        self.typed = ""
        self.mouse_btn_events = []
        self.tooltip = None
        for e in events:
            if e.type == pygame.MOUSEBUTTONDOWN:
                if e.button == 1:
                    self.clicked = True
                    self.down = True
                elif e.button == 3:
                    self.rclicked = True
                if e.button in (1, 2, 3):
                    self.mouse_btn_events.append(e.button)
            elif e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                self.down = False
                self.drag = None
            elif e.type == pygame.MOUSEWHEEL:
                self.wheel += e.y
            elif e.type == pygame.KEYDOWN:
                self.keys.append(e)
            elif e.type == getattr(pygame, "TEXTINPUT", -1):
                self.typed += getattr(e, "text", "")
        self.mouse = pygame.mouse.get_pos()

    def hit(self, rect):
        if self.clip is not None and not self.clip.collidepoint(self.mouse):
            return False
        return rect.collidepoint(self.mouse)

    # -------------------------------------------------------------- drawing
    def text(self, s, pos, size=16, color=TEXT, bold=False, anchor="topleft"):
        surf = self.fonts.render(str(s), size, color, bold)
        r = surf.get_rect(**{anchor: pos})
        self.screen.blit(surf, r)
        return r

    def text_w(self, s, size=16, bold=False):
        return self.fonts.get(size, bold).size(str(s))[0]

    def fit(self, s, width, size=16, bold=False):
        s = str(s)
        if self.text_w(s, size, bold) <= width:
            return s
        while s and self.text_w(s + "…", size, bold) > width:
            s = s[:-1]
        return s + "…"

    def rect(self, r, color, radius=8, width=0):
        pygame.draw.rect(self.screen, color, r, width, border_radius=radius)

    def panel(self, r, color=PANEL, radius=12, border=LINE):
        self.rect(r, color, radius)
        if border:
            self.rect(r, border, radius, 1)

    def bar_h(self, r, frac, color, signed=False, back=PANEL2):
        """Barra horizontal. frac en [0,1] o en [-1,1] si signed."""
        self.rect(r, back, 5)
        if signed:
            mid = r.x + r.w // 2
            w = int(abs(frac) * r.w / 2)
            rr = pygame.Rect(mid, r.y, w, r.h) if frac >= 0 else pygame.Rect(mid - w, r.y, w, r.h)
            if w > 0:
                self.rect(rr, color, 5)
            pygame.draw.line(self.screen, DIM, (mid, r.y - 2), (mid, r.bottom + 1), 1)
        else:
            w = int(max(0.0, min(1.0, frac)) * r.w)
            if w > 0:
                self.rect(pygame.Rect(r.x, r.y, w, r.h), color, 5)

    def bar_v(self, r, frac, color, back=PANEL2):
        self.rect(r, back, 6)
        h = int(max(0.0, min(1.0, frac)) * r.h)
        if h > 0:
            self.rect(pygame.Rect(r.x, r.bottom - h, r.w, h), color, 6)

    # -------------------------------------------------------------- widgets
    def button(self, wid, r, label, color=PANEL2, fg=TEXT, size=15, bold=False, enabled=True):
        hov = enabled and self.hit(r)
        c = color
        if hov:
            c = tuple(min(255, v + 18) for v in color)
        if not enabled:
            fg = DIM
        self.rect(r, c, 8)
        self.text(self.fit(label, r.w - 10, size, bold), r.center, size, fg, bold, "center")
        return hov and self.clicked and enabled

    def tab(self, wid, r, label, active):
        hov = self.hit(r)
        if active:
            self.rect(r, PANEL2, 8)
            pygame.draw.line(self.screen, ACCENT, (r.x + 10, r.bottom - 2), (r.right - 10, r.bottom - 2), 3)
        elif hov:
            self.rect(r, PANEL, 8)
        self.text(label, r.center, 15, TEXT if active else MUTED, active, "center")
        return hov and self.clicked

    def toggle(self, wid, r, value, label=None, color=ACCENT):
        """r = rect de toda la fila; el interruptor va a la derecha."""
        sw = pygame.Rect(r.right - 46, r.centery - 12, 46, 24)
        hov = self.hit(r)
        self.rect(sw, color if value else PANEL2, 12)
        if not value:
            self.rect(sw, LINE, 12, 1)
        kx = sw.right - 12 if value else sw.x + 12
        pygame.draw.circle(self.screen, TEXT if value else MUTED, (kx, sw.centery), 9)
        if label:
            self.text(self.fit(label, r.w - 56, 15), (r.x, r.centery), 15,
                      TEXT if hov else (205, 208, 218), anchor="midleft")
        if hov and self.clicked:
            return not value
        return value

    def slider(self, wid, r, value, lo, hi, label, fmt="{:.2f}", step=0.0, color=ACCENT):
        """r = fila completa. Etiqueta arriba-izq, valor arriba-der, pista abajo."""
        self.text(label, (r.x, r.y), 14, MUTED)
        self.text(fmt.format(value), (r.right, r.y), 14, TEXT, True, "topright")
        track = pygame.Rect(r.x, r.y + 24, r.w, 6)
        hit = track.inflate(0, 18)
        if self.hit(hit) and self.clicked:
            self.drag = wid
        if self.hit(hit) and self.wheel:
            st = step if step else (hi - lo) / 100.0
            value = max(lo, min(hi, value + st * self.wheel))
        if self.drag == wid:
            if self.down:
                f = (self.mouse[0] - track.x) / max(1, track.w)
                value = lo + max(0.0, min(1.0, f)) * (hi - lo)
                if step:
                    value = round(round((value - lo) / step) * step + lo, 6)
            else:
                self.drag = None
        f = (value - lo) / (hi - lo) if hi != lo else 0
        self.rect(track, PANEL2, 3)
        fw = int(max(0, min(1, f)) * track.w)
        if fw:
            self.rect(pygame.Rect(track.x, track.y, fw, track.h), color, 3)
        pygame.draw.circle(self.screen, TEXT, (track.x + fw, track.centery), 8)
        return value

    def cycle(self, wid, r, options, current, label=None):
        """options = [(valor, texto)]. Clic izq = siguiente, clic der = anterior."""
        vals = [o[0] for o in options]
        idx = vals.index(current) if current in vals else 0
        box = r
        if label:
            self.text(label, (r.x, r.centery), 14, MUTED, anchor="midleft")
            lw = 0 if not label else min(r.w // 2, self.text_w(label, 14) + 12)
            box = pygame.Rect(r.x + lw, r.y, r.w - lw, r.h)
        hov = self.hit(box)
        self.rect(box, (40, 44, 55) if hov else PANEL2, 8)
        self.text("‹", (box.x + 10, box.centery), 18, MUTED, anchor="midleft")
        self.text("›", (box.right - 10, box.centery), 18, MUTED, anchor="midright")
        self.text(self.fit(options[idx][1], box.w - 44, 15), box.center, 15, TEXT, anchor="center")
        if hov and self.clicked:
            idx = (idx + 1) % len(options)
        elif hov and self.rclicked:
            idx = (idx - 1) % len(options)
        return options[idx][0]

    def keybind(self, wid, r, current, label=None, pretty=str, keymap=None):
        """Clic -> 'Pulsa una tecla'. Esc cancela, Supr borra."""
        box = r
        if label:
            self.text(label, (r.x, r.centery), 14, MUTED, anchor="midleft")
            lw = min(r.w // 2, self.text_w(label, 14) + 12)
            box = pygame.Rect(r.x + lw, r.y, r.w - lw, r.h)
        capturing = self.capture == wid
        hov = self.hit(box)
        col = ACCENT if capturing else ((40, 44, 55) if hov else PANEL2)
        self.rect(box, col, 8)
        txt = "Pulsa una tecla…" if capturing else (pretty(current) if current else "Sin tecla")
        self.text(self.fit(txt, box.w - 12, 15), box.center, 15,
                  TEXT if (current or capturing) else DIM, capturing, "center")
        if capturing:
            for e in self.keys:
                if e.key == pygame.K_ESCAPE:
                    self.capture = None
                    return current
                if e.key == pygame.K_DELETE:
                    self.capture = None
                    return ""
                name = keymap(e) if keymap else None
                if name:
                    self.capture = None
                    return name
            for b in self.mouse_btn_events:
                self.capture = None
                if hov:   # clic dentro del campo = asignar ese botón del ratón
                    return {1: "MOUSE1", 2: "MOUSE3", 3: "MOUSE2"}[b]
                return current   # clic fuera = cancelar
        elif hov and self.clicked:
            self.capture = wid
            self.clicked = False   # que este clic no lo use otro widget
            self.mouse_btn_events = []
        elif hov and self.rclicked:
            return ""
        return current

    def textfield(self, wid, r, value, placeholder=""):
        """Campo de texto sencillo: clic para escribir, Intro o clic fuera para terminar."""
        hov = self.hit(r)
        active = self.focus == wid
        if self.clicked:
            if hov:
                self.focus = wid
                active = True
            elif active:
                self.focus = None
                active = False
        if active:
            value += self.typed
            for e in self.keys:
                if e.key == pygame.K_BACKSPACE:
                    value = value[:-1]
                elif e.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                    self.focus = None
            value = value[:40]
        self.rect(r, (40, 44, 55) if (hov or active) else PANEL2, 8)
        if active:
            self.rect(r, ACCENT, 8, 1)
        txt = value if value else ("" if active else placeholder)
        col = TEXT if value else DIM
        shown = self.fit(txt + ("|" if active and int(pygame.time.get_ticks() / 500) % 2 == 0 else ""), r.w - 16, 15)
        self.text(shown, (r.x + 8, r.centery), 15, col, anchor="midleft")
        return value
