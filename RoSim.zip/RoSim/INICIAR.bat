@echo off
where pyw >nul 2>nul && (start "" pyw "%~dp0RoSim.pyw" & exit /b)
where pythonw >nul 2>nul && (start "" pythonw "%~dp0RoSim.pyw" & exit /b)
python "%~dp0RoSim.pyw"
pause
