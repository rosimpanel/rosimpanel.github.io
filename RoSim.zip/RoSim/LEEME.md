# RoSim — volantes, sidestick y gases para Roblox (Windows)

Web y descargas: https://rosimpanel.github.io

## Instalar (una vez)
1. Descomprime el zip en una carpeta fija (por ejemplo Documentos\RoSim).
2. Doble clic en **INSTALAR.bat**. Instala solo Python (si no lo tienes), las librerías y el driver
   **ViGEmBus** (Windows pedirá permiso de administrador una vez), y crea el **acceso directo en el escritorio**.
3. Abre RoSim desde el icono del escritorio.

## Actualizar
RoSim mira solo si hay versión nueva al abrirse. Si la hay, el botón **Actualizar** se pone naranja:
pulsa **Descargar e instalar** → **Reiniciar**. Tu configuración se conserva.

## Volante (G29 / G920 / G923 / G27 / G PRO y cualquier otro)
- Se detecta solo, con modelo y grados. El volante va al stick izquierdo de un mando Xbox virtual; pedales a RT/LT.
- **Anti-zona muerta (20% por defecto)**: Roblox ignora el primer ~20% del stick; RoSim lo salta y el coche gira desde el primer grado.
- **SINCRONIZAR CON EL JUEGO** (pestaña *En vivo*): mide el tope y la zona muerta del volante del juego
  para que tu volante y el del coche giren exactamente igual. Hazlo una vez en cada juego.
- En G HUB pon el rango a 900° (1080° en el G PRO) y desactiva el «muelle de centrado» de G HUB.
- Si los pedales no van bien: pestaña *En vivo* → **Asistente** → Detectar acelerador / freno.

## Sidestick Airbus TCA → ratón
- Pulsa **RATÓN FÁCIL** (pestaña *En vivo*): todos los ejes siguen al ratón menos la palanca de velocidad, que va a W/S.
- Modo **«Sigue al stick»**: la posición del stick ES la del cursor. Stick en neutro = cursor al centro = el avión vuelve recto.
- Ajusta radio, centro y suavizado en **Ajustes y ratón**. Pon un botón en «Ratón ON/OFF» para recuperar tu ratón.

## Palanca de gases TCA Quadrant
- RoSim pulsa W/S (o las teclas que elijas) hasta que el gas del juego coincide con tu palanca.
- Ajusta **«Tiempo de 0 a 100%»** a lo que tarda el gas del juego manteniendo la tecla. Ralentí o tope resincronizan.

## Teclas
- Pestaña **Botones y teclas**: cualquier botón → tecla, botón de mando o acción. Cualquier eje → teclas (con pulsos PWM).

Por defecto solo envía cuando la ventana de Roblox está delante. La configuración se guarda en `%APPDATA%\RoSim\config.json`.
