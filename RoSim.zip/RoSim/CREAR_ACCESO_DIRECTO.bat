@echo off
title RoSim - Acceso directo
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1" -SoloAcceso
pause
